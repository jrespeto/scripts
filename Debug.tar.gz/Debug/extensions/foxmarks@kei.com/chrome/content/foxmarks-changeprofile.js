/* 
 Copyright 2008-2010 Xmarks Inc.

 foxmarks-changeprofile.js: Implements actions for change profile dialog.

 */

function ChangeProfileLoad() {
    var menuPopup = document.getElementById("profileMenuPopup");
    
    if (Xmarks.gSettings.viewId) {
        menuPopup.childNodes[Xmarks.gSettings.viewId].label = 
            Xmarks.gSettings.viewName;
        menuPopup.childNodes[Xmarks.gSettings.viewId].hidden = false;
    }

    document.getElementById("profileMenuList").value = Xmarks.gSettings.viewId;
    LoadProfileNames();
}

function LoadProfileNames() {
    Xmarks.FetchProfileNames(null, document.getElementById("profileSpinner"),
        document.getElementById("profileMenuPopup"), NamesLoaded);
    document.getElementById("profileMenuList").value = String(Xmarks.gSettings.viewId);
}

function NamesLoaded(response) {
    if (response.count) {
        document.getElementById("profileMenuList").disabled = false;
        document.getElementById("profileMenuList").focus();
    }
}

function ChangeProfileOK() {
    window.arguments[0].newProfileId = 
        document.getElementById("profileMenuList").value;
    window.arguments[0].newProfileName =
        document.getElementById("profileMenuList").label;
    return true;
}

