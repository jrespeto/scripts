 /*
 Copyright 2007-2010 Xmarks Inc.

 foxmarks-core.js: implements core sync & merge algorithms. 

 */

const { Cc, Ci, Cr, Cu } = require("chrome");

if (typeof(exports.plugin) == "undefined") {
    // when running from test cases...
    var Xmarks = {};
    Xmarks.cs = require("./foxmarks-command.js");
    Xmarks.LogWrite = function(x) { console.log(x); }
    Xmarks.LogError = function(x, e) { console.log(x + " " + e); }
} else {
    Xmarks = exports.plugin;
}

var Command = Xmarks.cs.Command;

function EnumerateDeletedNodes(cs, baseline, current) {
    // Given a delete command, determine which of its desecendant nodes
    // were actually deleted, and attach that list of nids.
    // Some children may have been moved prior to the delete, so they
    // would survive in the curernt nodeset. Those survivors are not
    // included in the attached list.

    
    var deleted = null;

    function EnumerateInternal(nid) {
        if (!current.Node(nid, false, true)) {
            deleted.push(nid);
        }
        var node = baseline.Node(nid);
        if (node.children) {
            node.children.forEach(function(nid) { EnumerateInternal(nid) } );
        }
    }

    cs.set.forEach(function(command) {
        if (command.action == 'delete') {
            command.deleted = [];
            deleted = command.deleted;
            EnumerateInternal(command.nid);
        }
    } );
}

function CleanDeletedNodes(cs) {
    cs.set.forEach(function(cmd) { 
        if (cmd.action == 'delete') {
            delete cmd.deleted;
        }
        delete cmd.fixed;
    } );
}

// Syncd is a bit protective of its semantics. If we generated a move that
// doesn't actually change the node's parent, downgrade it to a reorder.

function CleanServerMoves(cs, ns) {
    cs.set.forEach(function(cmd) {
        if (cmd.action == 'move' && cmd.args.pnid == ns.Node(cmd.nid).pnid) {
            cmd.action = 'reorder';
            delete cmd.args.pnid;
        }
    })
}

function CombinePrePost(cs) {
    cs.set = cs.pre.concat(cs.set).concat(cs.post);
    delete cs.pre;
    delete cs.post;
}

function CleanDupes(cs)
{
    var hash = {};

    cs.set = cs.set.filter(function isnew(cmd) {
        var cmdstr = JSON.stringify(cmd);
        var is_dupe = hash[cmdstr];
        hash[cmdstr] = 1;
        if (is_dupe)
            Xmarks.LogWrite("Dropping duplicate cmd " + cmdstr);
        return !is_dupe;
    });
}

// Handle conflicts between item A on client and item B on server
var DETECTORS = {

    // Format for naming of these detectors is localaction_serveraction.

    insert_insert: function(local, server, localNS, serverNS) {
        if (local.nid == server.nid) {  // items created with same nid. Scary!
            var conflict = [];

            Object.keys(local.args).forEach(function(attr) {
                var value = local.args[attr];
                if (server.args[attr] && !DETECTORS.HARMLESS_ATTRS[attr] &&
                        value != server.args[attr] && (attr != 'tags' ||
                        !Xmarks.utils.tagEquals(server.args[attr], value))) {
                    conflict.push(attr + ":" + value);
                }
            } );

            Object.keys(server.args).forEach(function(attr) {
                var value = server.args[attr];
                if (local.args[attr] && !DETECTORS.HARMLESS_ATTRS[attr] &&
                        value != local.args[attr] && (attr != 'tags' ||
                        !Xmarks.utils.tagEquals(local.args[attr], value))) {
                    conflict.push(attr + ":" + value);
                }
            } );

            if (conflict.length) {
                var lnode = localNS.Node(local.nid);
                var snode = serverNS.Node(server.nid);
                var rv = localNS.handleNidConflict(lnode, snode, conflict);

                showedUI = true;

                if (rv == "local") {
                    return ["overwrite", "local"];
                } else if (rv == "server") {
                    return ["overwrite", "server"];
                } else if (rv == "same") {
                    return ["drop", "both"];
                } else {
                    throw 2;
                }
            } else {
                return ["drop", "both"];
            }
        }
        // Inserted A and B into the same place.  Insanely common.
        // Put B before A.
        if (local.args.pnid == server.args.pnid &&
                local.args.bnid == server.args.bnid &&
                !local.fixed && !server.fixed) {
            return ["transit", "server"];
        }
        return null;
    },

    insert_move: function(local, server) {
        // Inserted A before B, but B was moved into a different folder
        // Put A before B's next sibling
        if (local.args.pnid != server.args.pnid &&
            local.args.bnid == server.nid) {
            return ["nextsib", "left"];
        }
        // Inserted A and moved B to same place.
        // Put B before A.
        if (local.nid != server.nid &&
                local.args.pnid == server.args.pnid &&
                local.args.bnid == server.args.bnid) {
                return ["transit", "server"];
        }
        return null;
    },

    insert_reorder: function(local, server, lns, sns) {
        // Inserted A and moved B to same place.
        // Put B before A.
        if (local.args.pnid == sns.Node(server.nid).pnid &&
                local.args.bnid == server.args.bnid && !server.fixed) {
            return ["transit", "server"]; 
        }
        // Inserted A before B, and moved B.
        // Put A before B's next sibling.
        if (local.args.pnid == sns.Node(server.nid).pnid &&
                local.args.bnid == server.nid && !server.fixed &&
                !local.fixed) {
            return ["nextsib", "left"];
        }
        return null;
    },

    insert_update: function(local, server) {
        // No conflicts between insert/update
        return null;
    },

    delete_insert: function(local, server) {
        // Deleted A and inserted B as child of A.
        // Keep B in A's ancestor.
        if (local.deleted.indexOf(server.args.pnid) >= 0) {
            return ["delinsert", "left"];
        }
        // Deleted A and inserted B before A.
        // Put B before A's next sibling.
        if (local.deleted.indexOf(server.args.bnid) >= 0) {
            return ["nextsib", "right"];
        }
        if (local.nid == server.nid) {
            return ["drop", "local"];
        }
        return null;
    },
            
    delete_delete: function(local, server) {
        // Deleted same A and B
        // Remove both
        if (local.nid == server.nid) {
            return ["drop", "both"];
        }
        // Deleted some ancestor of B, and B.
        // Remove B.
        if (local.deleted.indexOf(server.nid) >= 0) {
            return ["drop", "right"];
        }

        // Deleted some ancestor of A, and A.
        // Remove A.
        if (server.deleted.indexOf(local.nid) >= 0) {
            return ["drop", "left"];
        }

        return null;
    },

    delete_move: function(local, server) {
        // Deleted some node A, and B was moved before A
        // Put B after A's next sibling
        if (local.deleted.indexOf(server.args.bnid) >= 0) {
            return ["nextsib", "right"];
        }
        // Deleted some ancestor A of B, and B was moved to a different folder
        // Keep B in the ancestor of A
        if (local.deleted.indexOf(server.nid) >= 0) {
            return ["delmoveout", "left"];
        }
        // Deleted some node A, and B was added as a predecessor of A
        // Keep B in the ancestor of A
        if (local.deleted.indexOf(server.args.pnid) >= 0) {
            return ["delmovein", "left"];
        }
        return null;
    },

    delete_reorder: function(local, server) {
        // Deleted some ancestor A of B, and B was moved in the same folder
        // Remove B also
        if (local.deleted.indexOf(server.nid) >= 0) {
            return ["drop", "right"];
        }
        // Deleted some node A, and B was moved before A
        // Put B before A's sibling
        if (local.nid == server.args.bnid) {
            return ["nextsib", "right"];
        }
        return null;
    },

    delete_update: function(local, server) {
        if (local.deleted.indexOf(server.nid) >= 0) {
            // Keep the delete, drop the update
            return ["drop", "right"];
        }
        return null;
    },

    move_move: function(local, server, localNS, serverNS) {
        if (local.args.pnid == server.args.pnid) {
            if (local.nid == server.nid) {
                if (local.args.bnid == server.args.bnid) {
                    // Moved A and same node B to the same position
                    // Ignore since correct in both places
                    return ["drop", "both"];
                } else {
                    // Moved A and same node B to different positions
                    // Ignore B's movement
                    return ["drop", "server"];
                }
            } else {
                // Moved node A and B to the same position
                // Put B before A
                if (local.args.bnid == server.args.bnid) {
                    return ["transit", "server"];
                }
            }
        } else {
            if (local.nid == server.nid) {
                // Moved node A and same node B to different folders
                // Ask the user which to keep
                var input = { item: localNS.Node(local.nid),
                    local: localNS.Node(local.args.pnid),
                    server: serverNS.Node(server.args.pnid) };
                var rv = OpenConflictDialog(
                    "chrome://foxmarks/content/foxmarks-parentconflict.xul",
                    input);
                showedUI = true;

                if (rv == "local") {
                    return ["drop", "server"];
                } else if (rv == "server") {
                    return ["drop", "local"];
                } else {
                    throw 2;
                }
            } else {
                if (local.nid == server.args.bnid) {
                    // Moved node A to before B, and moved B
                    // Put A before B's sibling
                    return ["nextsib", "right"];
                } else if (local.args.bnid == server.nid) {
                    // Moved node A, and moved B to before A
                    // Put B before A's sibling
                    return ["nextsib", "left"];
                }
            }
        }

        return null;
    },

    move_reorder: function(local, server, lns, sns) {
        // Moved node A to different folder, and moved B
        // Ignore B's movement
        if (local.nid == server.nid) {
            return ["drop", "right"];
        }
        // Moved node A to different folder, and moved B to before A
        // Put B before A's sibling
        if (local.nid == server.args.bnid &&
                local.args.pnid != sns.Node(server.nid).pnid &&
                !server.fixed) {
            return ["nextsib", "right"];
        }
        // Moved A to the same position as B
        // Put B before A.
        if (local.args.pnid == sns.Node(server.nid).pnid &&
                local.args.bnid == server.args.bnid &&
                !server.fixed) {
            return ["transit", "server"];
        }
        return null;
    },

    move_update: function() {
        // No conflicts between move/update
        return null;
    },

    reorder_reorder: function(local, server, lns, sns) {
        // No conflicts if different folders
        if (lns.Node(local.nid).pnid != sns.Node(server.nid).pnid) {
            return null;
        }
        if (local.nid == server.nid) {
            if (local.args.bnid == server.args.bnid) {
                // Moved node A and same node B to same position
                // Ignore both since no change needed
                if (!local.fixed) {
                    return ["drop", "both"];
                } else {
                    return null;
                }
            } else {
                // Moved node A and same node B to different positions
                // Client move takes precedence.
                // XXX: Must retarget in this case
                return ["drop", "server"];
            }
        } else { // local.nid != server.nid
            if (local.nid == server.args.bnid && !server.fixed) {
                // Moved node A, and moved node B before A
                return ["commutereorder", "left"];
            } else if (local.args.bnid == server.nid && !local.fixed) {
                // Moved node B, and moved A before B
                return ["commutereorder", "right"];
            } else if (local.args.bnid == server.args.bnid) {
                // Moved node A and B to same position
                // Put A before B.
                return ["transit", "local"];
            } else {
                return null;
            }
        }
    },

    reorder_update: function() {
        // No conflicts for reorder vs update
        return null;
    },

    HARMLESS_ATTRS: { created: true, visited: true, modified: true, 'private': true, 
        icon: true },

    update_update: function(local, server, localNS, serverNS) {
        // No conflicts for different updates
        if (local.nid != server.nid)
            return;

        var conflicts = [];

        Object.keys(local.args).forEach(function(attr) {
            var value = local.args[attr];
            if (server.args[attr] && !DETECTORS.HARMLESS_ATTRS[attr] &&
                    value != server.args[attr] && (attr != 'tags' ||
                    !Xmarks.utils.tagEquals(value, server.args[attr])) &&
                    (attr != 'url' || server.args[attr] != null &&
                    server.args[attr].length > 0)) {
                conflicts.push(attr);
            }
        } );

        // Special case: tag-only conflict
        if (conflicts.length == 1 && conflicts[0] == 'tags') {
            return ["drop", "server"];
        }

        // Special case: conflict on (hidden attributes of) ROOT
        if (local.nid == 'ROOT') {
            return ["drop", "server"];
        }

        if (conflicts.length) {
            var lnode = localNS.Node(local.nid);
            var snode = serverNS.Node(server.nid);
            var rv = localNS.handleNidConflict(lnode, snode, conflicts);

            showedUI = true;
            if (rv == "local") {
                return ["drop", "server"];
            } else if (rv == "server") {
                return ["drop", "local"];
            } else if (rv == "same") {
                return ["drop", "both"];
            } else {
                throw 2;
            }
        } 
        return null;
    }
}

// Given a baseline nodeset, a local nodeset, and a server nodeset,
// generate two commandsets, one to be applied to the local nodeset,
// another to be applied to the server nodeset. Applying each commandset
// to the respective nodeset will result in the two nodsets becoming
// synchronized.
//
// Note that the routine operates asynchronously; the client-provided
// callback will be called with two parameters: localCS (the commandset
// to be applied to the server, and serverCS (the commandset to be applied
// to the local nodeset).

function _Synchronize(baseline, localCS, serverCS, local, server, callback) {
    EnumerateDeletedNodes(localCS, baseline, local);
    EnumerateDeletedNodes(serverCS, baseline, server);

    localCS.pre = [];
    localCS.post = [];
    serverCS.pre = [];
    serverCS.post = [];

    // Iterate over each local commmand, comparing it with each
    // server command. Detect and resolve conflicts.

    var iterations = 0;
    var conflicts = {};
    var showedUI = false;

    // First pass: transform any commands with same
    // pnid/bnid pair (same position) such that the server comes
    // before the client.  This means we shouldn't have any
    // transit conflicts except for move_reorder conflicts.
    //
    // 1. build a hash on target pnid_bnid (can have duplicates)
    // 2. for each client node, probe server set for target pnid/bnid;
    //    set bnid for each match to client nid
    // 3. remove updated items from hash
    //
    //  XXX Record where we moved to for insert/move conflicts?
    Xmarks.LogWrite("Synchronize: Processing movement conflicts");
    var hash = {};
    for (var s = 0; s < serverCS.set.length; ++s) {
        var sc = serverCS.set[s];
        if (!sc.args || !sc.args.bnid)
            continue;

        var key = sc.args.pnid + "_" + sc.args.bnid;
        if (!hash[key])
            hash[key] = [];

        hash[key].push(sc);
    }
    Xmarks.LogWrite("Synchronize: Adjusting positions");
    for (var l = 0; l < localCS.set.length; ++l) {
        var lc = localCS.set[l];
        if (!lc.args || !lc.args.bnid)
            continue;

        var key = lc.args.pnid + "_" + lc.args.bnid;

        if (!hash[key])
            continue;

        hash[key].forEach(
            function(sc) {
                if (lc.nid != sc.nid)
                    do_transit2(lc, sc);
            });
        hash[key] = null;
    }

    Xmarks.LogWrite("Synchronize: Performing conflict resolution");
    for (var l = 0; l < localCS.set.length; ++l) {
        var lc = localCS.set[l];
        var result = null;
        var breakOut = false;

        for (var s = 0; s < serverCS.set.length; ++s) {

            sc = serverCS.set[s];

            var method = DETECTORS[lc.action + "_" + sc.action];
            if (method) {
                try {
                    result = method(lc, sc, local, server, false);
                } catch (e) {
                    Xmarks.LogWrite("Synchronize: failed processing " +
                        lc.toSource() + ", " + sc.toSource());
                    Xmarks.LogWrite("Error is " + e.toSource());
                    throw e;
                }
                if (!result)
                    continue;
                if (result[1] == 'left') result[1] = 'local';
                else if (result[1] == 'right') result[1] = 'server';
            } else {
                method = DETECTORS[sc.action + "_" + lc.action];
                if (!method) {
                    throw Error("Couldn't find conflict detector for " +
                            lc.action + " : " + sc.action);
                }

                try {
                    result = method(sc, lc, server, local, true);
                } catch (e) {
                    Xmarks.LogWrite("Synchronize: failed processing (reversed) " +
                        sc.toSource() + ", " + lc.toSource());
                    Xmarks.LogWrite("Error is " + e.toSource());
                    throw e;
                }
                if (!result)
                    continue;
                if (result[1] == 'left') result[1] = 'server';
                else if (result[1] == 'right') result[1] = 'local';
            }
           
            conflicts[result[0]] = (conflicts[result[0]] || 0) + 1;

            Xmarks.LogWrite(">>> Sync: Executing " + result[0] + "(" + result[1] + 
                    ") on " + lc.toSource() + " vs. " + sc.toSource());

            switch (result[0]) {
            case 'drop': do_drop(result[1]); break;
            case 'overwrite': do_overwrite(result[1]); break;
            case 'transit': do_transit(result[1]); break;
            case 'nextsib': do_nextsib(result[1]); break;
            case 'delinsert': do_delinsert(result[1]); break;
            case 'delmovein': do_delmovein(result[1]); break;
            case 'delmoveout': do_delmoveout(result[1]); break;
            case 'delupdate': do_delupdate(result[1]); break;
            case 'commutereorder': do_commutereorder(result[1]); break;
            default: throw Error("Unknown sync operator " + result[0]);
            }

            if (breakOut) {
                iterations += 1;
                if (iterations >= 1000) {
                    throw 1013;
                }
                break;
            }
        }
    }

    // We have resolved all conflicts in commands
    CleanDeletedNodes(localCS);
    CleanDeletedNodes(serverCS);
    CombinePrePost(localCS);
    CombinePrePost(serverCS);
    CleanServerMoves(localCS, server);
    CleanDupes(localCS);
    CleanDupes(serverCS);

    callback(localCS, serverCS, conflicts, showedUI);
    return;

    function do_overwrite(arg) {
        switch (arg) {
        case 'local': 
            serverCS.drop(s); 
            s = s - 1;
            localCS.set[l].action = "update";
            localCS.set[l].args.bnid = undefined;
            localCS.set[l].args.pnid = undefined;
            break;
        case 'server': 
            localCS.drop(l); 
            l = l - 1;
            serverCS.set[s].action = "update";
            serverCS.set[s].args.bnid = undefined;
            serverCS.set[s].args.pnid = undefined;
            break;
        default: 
            throw Error("Unknown sync parameter " + result[1]);
        }
        return;
    }
    function do_drop(arg) {
        switch (arg) {
        case 'both': 
            localCS.drop(l);
            serverCS.drop(s);
            l = l - 1;
            breakOut = true;
            // bust out of inner loop; decrement l and start there
            break;
        case 'local': 
            localCS.drop(l); 
            l = l - 1;
            breakOut = true;
            // bust out of inner loop; decrement l and start there
            break;
        case 'server': 
            serverCS.drop(s); 
            s = s - 1;
            // decrement s and continue inner loop
            break;
        default: 
            throw Error("Unknown sync parameter " + result[1]);
        }
        return;
    }

    function do_transit2(orig, moved) {
        moved.args.bnid = orig.nid;
        moved.fixed = true;
    }

    function do_transit(arg) {
        // A command specifies a bnid that is the target of another command.
        // So we take the bnid specified by the local or server command 
        // (depending on arg) and replace it with the nid of the other command.
        switch (arg) {
        case 'local': 
            lc.args.bnid = sc.nid; 
            lc.fixed = true;
            l = l - 1;
            breakOut = true;
            // restart inner loop
            break;
        case 'server': 
            sc.args.bnid = lc.nid; 
            sc.fixed = true;
            l = -1;
            breakOut = true;
            // restart outer loop
            break;
        default: 
            throw Error("Uknown sync parameter " + result[1]);
        }
        return;
    }

    function do_nextsib(arg) {
        switch (result[1]) {
        case 'local': 
            lc.args.bnid = local.NextSibling(lc.args.bnid, baseline); 
            l = l - 1;
            breakOut = true;
            // restart inner loop
            break;
        case 'server': 
            sc.args.bnid = server.NextSibling(sc.args.bnid, baseline);
            l = -1;
            breakOut = true;
            // restart outer loop
            break;
        default:
            throw Error("Unknown sync parameter " + result[1]);
        }
        return;
    }

    function do_delinsert(arg) {
        // arg is local or server, determining which side
        // originated the delete. The other side originated a
        // conflicting insert. The desired end result is for the inserted
        // node to be inserted into the nearest remaining ancestor of the
        // original pnid. This is accomplished by modifying the existing
        // insert command, changing its parent, and inserting a move command
        // to the side that originated the delete which moves the already
        // inserted node into the correct parent before performing the delete.
        // Finally, we add reorders to the post-sequence to make sure that
        // the inserted item ends up at the bottom of the folder.

        var del = null;
        var ins = null;
        var delCS = null;

        if (arg == "server") {
            del = sc;
            ins = lc;
            delCS = serverCS;
        } else {
            del = lc;
            ins = sc;
            delCS = localCS;
        }

        // What's the ultimate destination for the insert?
        var pnid = NearestAncestor(ins.args.pnid, baseline, local, server);

        // Alter the insert command so that it winds up in a safe home.
        ins.args.pnid = pnid;
        ins.args.bnid = null;
        ins.fixed = true;

        // Move the inserted node aside before the delete
        delCS.pre.push(new Command("move", ins.nid, { pnid: pnid } ));

        // And now make sure it's add the end of the folder on both sides.
        var cmd = new Command("reorder", ins.nid, { bnid: null } );
        localCS.post.push(cmd);
        serverCS.post.push(cmd);

        // We've modified both commandsets; restart processing from the top.
        l = -1;
        breakOut = true;
        return;
    }

    function do_delmovein(arg) {
        // arg is local or server, determining which side
        // originated the delete. The other side originated a
        // conflicting move into the deleted subtree.
        // The desired end result is for the moved
        // node to be inserted into the nearest remaining ancestor of the
        // original pnid. This is accomplished by modifying the existing
        // move command, changing its parent, and inserting a move command
        // to the side that originated the delete which moves the already
        // inserted node into the correct parent before performing the delete.

        var del = null;
        var ins = null;
        var delCS = null;

        if (arg == "server") {
            del = sc;
            ins = lc;
            delCS = serverCS;
        } else {
            del = lc;
            ins = sc;
            delCS = localCS;
        }

        // What's the ultimate destination for the move?
        var pnid = NearestAncestor(ins.args.pnid, baseline, local, server);

        // Alter the move command so that it winds up in a safe home.
        ins.args.pnid = pnid;
        ins.args.bnid = null;

        // Move the inserted node aside before the delete
        delCS.pre.push(new Command("move", ins.nid, { pnid: pnid } ));

        // And now make sure it's add the end of the folder on both sides.
        var cmd = new Command("reorder", ins.nid, { bnid: null } );
        localCS.post.push(cmd);
        serverCS.post.push(cmd);

        // We've modified both commandsets; restart processing from the top.
        l = -1;
        breakOut = true;
        return;
    }

    function do_delupdate(arg) {
        // arg is local or server, determining which side
        // originated the delete. The other side originated a
        // conflicting update within the deleted subtree.
        // The desired end result is for the updated node and its
        // descendants to survive at the nearest remaining ancestor of the
        // original destination. This is accomplished by resurrecting the
        // modified node and its descendants and adding a move to the side
        // from which the delete originated which moves the item to its new
        // location.

        var update = null;
        var updateCS = null;
        var updateNS = null;
        var moveNS = null;
        var del = null;
        var delNS = null
        var delCS = null
        var delIndex = 0;
        var updateIndex = 0;

        if (arg == "server") {
            update = lc;
            updateCS = localCS;
            updateNS = local;
            del = sc;
            delNS = server;
            delCS = serverCS;
            delIndex = s;
            updateIndex = l;
        } else {
            update = sc;
            updateCS = serverCS;
            updateNS = server;
            del = lc;
            delNS = local;
            delCS = localCS;
            delIndex = l;
            updateIndex = s;
        }
        // Resurrect the deleted nodes
        ResurrectNodes(update, updateNS, updateCS, delNS, delCS);

        // We've modified both commandsets; restart processing from the top.
        l = -1;
        breakOut = true;
        return;
    }

    function do_delmoveout(arg) {
        // arg is local or server, determining which side
        // originated the delete. The other side originated a
        // conflicting move out of the deleted subtree.
        // The desired end result is for the moved
        // node to survive at the nearest remaining ancestor of the
        // original destination. This is accomplished by replacing the existing
        // move command with a (series of) insert(s) that resurrect the deleted
        // nodes(s) in their correct position. We let delinsert deal with the
        // case where the destination folder has also been deleted.

        var move = null;
        var moveCS = null;
        var moveIndex = null;
        var moveNS = null;
        var del = null;
        var delNS = null
        var delCS = null;
        var delIndex = 0;

        if (arg == "server") {
            move = lc;
            moveCS = localCS;
            moveIndex = l;
            moveNS = local;
            del = sc;
            delNS = server;
            delCS = serverCS;
            delIndex = s;
        } else {
            move = sc;
            moveCS = serverCS;
            moveIndex = s;
            moveNS = server;
            del = lc;
            delNS = local;
            delCS = localCS;
            delIndex = l;
        }

        // Resurrect the deleted nodes
        ResurrectNodes(move, moveNS, moveCS, delNS, delCS);

        // We've modified both commandsets; restart processing from the top.
        l = -1;
        breakOut = true;
        return;
    }

    function do_commutereorder(arg) {
        // We've encountered R(x,y) vs. R(y,z).
        // arg determines the side receiving the additional command R(x,y).
        // The resolution is to add R(x,y) as a simulated command
        // after R(y,z). We also mark the original R(x,y) as fixed
        // so we don't trigger again and so we don't drop it believing
        // that it's redundant. It would be nice to handle this in
        // the post-sequence, but, unfortunately, we need to get the
        // order straightened out before further moves and inserts happen.

        var c = arg == "local" ? sc : lc;
        var set = arg == "local" ? localCS.set : serverCS.set;
        var i = arg == "local" ? l : s;
        c.fixed = true;

        // Before we duplicate the command, we must ensure
        // that x (as above) still exists on the side which is to
        // receive the duplicate command.  If it's been deleted, 
        // we can drop the R(x,y), as x's position is irrelevant.
        // See #7379.
        var nodeset = arg == "local" ? local : server;
        if (nodeset.Node(c.nid, false, true) ==  null) {
            return do_drop(arg == "local" ? "server" : "local");
        }

        Xmarks.LogWrite("Duplicating command from " + arg + ": " + c.toSource());

        // This bit is tricky. Insert our copy of the command c in
        // the appropriate place in set. The appropriate place is the first
        // non-fixed spot after the current command.

        for ( i++; i < set.length; ++i) {
            if (!set[i].fixed)
                break;
        }

        set.splice(i, 0, c);
        l = -1;
        breakOut = true;
        return;
    }
}


function NearestAncestor(nid, baseline, ns1, ns2) {
    while (nid) {
        var node = baseline.Node(nid, false, true);
        if (!node) {
            throw Error("NearestAncestor failed accessing " + nid);
        }

        if (ns1.Node(nid, false, true) && ns2.Node(nid, false, true)) {
            return nid;
        }

        nid = node.pnid;
    }
    throw "Couldn't find a common ancestor!";
}

function NextSibling(nid, ns) {
    // Return the next sibling of nid within ns. Returns null if
    // the node in question can't be found, or if it has no next sibling.
    var node = ns.Node(nid, false, true);
    if (!node) return null;

    var parent = ns.Node(node.pnid, false, true);
    if (!parent) return null;

    var siblings = parent.children;
    if (!siblings) return null;

    var index = siblings.indexOf(nid);
    if (index < 0) return null;
    
    if (++index >= siblings.length) return null;

    return siblings[index];
}

function NextSafeSibling(nid, ns, them) {
    // Return the next sibling after nid within ns that
    // *also* exists within them and is in the same parent.
    var node = ns.Node(nid, false, true);
    if (!node) return null;

    var pnid = node.pnid;

    do {
        nid = NextSibling(nid, ns);
    } while (nid && 
        (!them.Node(nid, false, true) || them.Node(nid).pnid != pnid));
    return nid;
}

function ResurrectNodes(sourceCommand, source, sourceCS, target, targetCS) {

    // Parameters we need:
    //  The source command, source, soureCS.
    //  The target command (the delete), the target nodeset, and the targetCS.


    // We're going to reanimate the dead, as it were. Our intention here
    // is to recreate the subtree from source rooted at nid. We accomplish
    // this by adding one or more inserts/moves into source's command set.
    //
    // We traverse the subtree, trying to find each node in the target nodeset.
    // If we find the node, we generate a move; if we don't find the node,
    // we generate an insert.
    //
    // If we generated an insert, we try to find an already-existing insert
    // in the source CS and drop it; failing that, we try to find a delete
    // within the targetCS that deleted the node and remove it from the list
    // of nids deleted by that node. In this last case, we also look for
    // and drop an update or reorder of this node, as these are now redundant.
    //
    // If we generated a move, then presumably the node still exists,
    // though within some other parent. The move that we generate here may
    // cause its own conflict, but that's okay -- the standard mechanisms
    // will resolve it.
    //
    // Finally, we want to build the commands that we insert locally,
    // inserting them all at the end to avoid the list moving around on us.

    Xmarks.LogWrite("Bring out 'cha dead: resurrecting " + 
            source.NodeName(sourceCommand.nid));
    
    var nids = [sourceCommand.nid];
    var commands = [];
    var sourceDrop = [];
    var targetDrop = [];
    var bnid = NextSafeSibling(sourceCommand.nid, source, target);
    var first = bnid; // Starts as bnid or null, 
                      // gets set to null after first use.

    while (nids.length) {
        var nid = nids.shift();
        var sourceNode = source.Node(nid);

        // Does the node in question exist in the target?
        if (target.Node(nid, false, true)) {
            // Node still exists; move it into position.
            var attrs = { pnid: sourceNode.pnid };
            if (first) attrs.bnid = first;
            first = null;
            commands.push(new Command("move", nid, attrs));
        } else {
            // Node doesn't exist.
            var c = sourceCS.find("insert", nid);
            // Was node inserted by source?
            if (c) {
                // Yes: drop the insert (we'll recreate it later).
                sourceDrop.push(c);
            } else {
                // No: node must have been deleted in target.
                var c = targetCS.findDelete(nid);
                if (c) {
                    if (c.nid == nid) {
                        targetDrop.push(c);
                        // reanimate all children
                        Array.prototype.push.apply(nids, c.deleted.slice(1));
                    } else {
                        var i = c.deleted.indexOf(nid);
                        if (i >= 0) {
                            c.deleted.splice(i, 1);
                        }
                    }
                }

                // We're going to get rid of updates, reorders, and moves
                // that might have happened on this node, as our insert
                // obviates the need for these changes: we insert into
                // the right parent, in the right position, with the correct
                // attributes.
                sourceDrop.push(sourceCS.find("update", nid));
                sourceDrop.push(sourceCS.find("reorder", nid));
                sourceDrop.push(sourceCS.find("move", nid));
            }

            var attrs = sourceNode.GetSafeAttrs();
            if (first) attrs.bnid = first;
            first = null;
            commands.push(new Command("insert", nid, attrs));
        }
    }

    // Now remove commands from each side that are superfluous.
    sourceDrop.forEach(function(c) {
            if (c) sourceCS.drop(c);
        });
    targetDrop.forEach(function(c) {
            if (c) targetCS.drop(c);
        });
    
    // Append our new commands at the end (but not the post-sequence,
    // as we may need to handle additional conflict resolution).
    commands.forEach(function(c) {
            sourceCS.append(c);
            Xmarks.LogWrite("Resurrect: Appending " + c.toSource());
        });

    // As a final cleanup, since our resurrection happens in the "right" folder
    // but not necessarily in the right position (we may not have found a bnid),
    // tack on a reorder of the root node to the target's post sequence.
    if (!bnid) {
        targetCS.post.push(
            new Command("reorder", sourceCommand.nid, { bnid: null }));
        Xmarks.LogWrite("Resurrect: Appended reorder of " + sourceCommand.nid);
    }
}

function cleanup_old_js_files(next)
{
    var backups_to_keep = 4;
    try {
        var profdir = Cc['@mozilla.org/file/directory_service;1']
            .getService(Ci.nsIProperties)
            .get('ProfD', Ci.nsIFile);

        var children = profdir.directoryEntries;

        var filesets = [
            {'pat': /baseline-[a-zA-Z0-9]+.js$/, 'matches': []},
            {'pat': /local-[a-zA-Z0-9]+.js$/, 'matches': []},
            {'pat': /server-[a-zA-Z0-9]+.js$/, 'matches': []},
        ];

        // collect all files matching the js backup patterns
        while (children.hasMoreElements()) {
            var file = children.getNext().QueryInterface(Ci.nsIFile);
            if (!file.isFile())
                continue;
            for (var i=0; i < filesets.length; i++) {
                if (filesets[i].pat.test(file.path)) {
                    filesets[i].matches.push(file);
                }
            }
        }

        // and delete any above 'backups_to_keep'
        for (var i=0; i < filesets.length; i++) {
            filesets[i].matches.sort(function(a, b) {
                // youngest (largest lastModifiedTime) comes first 
                return b.lastModifiedTime - a.lastModifiedTime;
            });

            var matches = filesets[i].matches;
            for (var j=backups_to_keep; j < matches.length; j++) {
                Xmarks.LogWrite("cleaning up " + matches[j].path);
                matches[j].remove(true);
            }
        }
    } catch (e) {
        Xmarks.LogError("cleaning up js files", e);
    }

    next();
}

function get_profd_file(filename)
{
    var profdir = Cc['@mozilla.org/file/directory_service;1']
        .getService(Ci.nsIProperties)
        .get('ProfD', Ci.nsIFile);

    profdir.append(filename);
    return profdir;
}

function sync_log_nodesets(baseline, localCS, serverCS, local, server, callback)
{
    /* by default, don't log any files */
    if (!Xmarks.gSettings || !Xmarks.gSettings.getDebugOption("preserve"))
        return _Synchronize(baseline, localCS, serverCS, local, server, callback);

    var profdir = Cc['@mozilla.org/file/directory_service;1']
        .getService(Ci.nsIProperties)
        .get('ProfD', Ci.nsIFile).path;

    var cookie = "";
    var alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    for (var i=0; i < 10; i++ )
        cookie += alpha.charAt(Math.floor(Math.random() * alpha.length));
    Xmarks.LogWrite("cookie = " + cookie);

    baseline.SaveToFile(function() {
        local.SaveToFile(function() {
            server.SaveToFile(function() {
                cleanup_old_js_files(function() {
                    _Synchronize(baseline, localCS, serverCS, local, server, callback);
                });
            }, get_profd_file("xmarks-server-" + cookie + ".js"));
        }, get_profd_file("xmarks-local-" + cookie + ".js"));
    }, get_profd_file("xmarks-baseline-" + cookie + ".js"));
}

function Synchronize(baseline, localCS, serverCS, local, server, callback)
{
    sync_log_nodesets(baseline, localCS, serverCS, local, server, callback);
}

exports.Synchronize = Synchronize;
