/* 
 Copyright 2005-2010 Xmarks Inc.

 foxmarks-overlay.js: implement the foxmarks overlay into the main browser
 window
 */

Xmarks.tabs = {};

Components.utils['import']('resource://xmarks/tabsync.jsm', Xmarks.tabs);

(function() {
var xm = Xmarks;
var Ci = Components.interfaces;
var Cc = Components.classes;


var foxmarksObserver = {
    observe: function(subject, topic, data) {
        var result = JSON.parse(data);

        if(!result.msg)
            return;

        var status = result.status;
        var msg = result.msg || "";
        var complete = status != 1;

        window.XULBrowserWindow.setJSStatus("Xmarks: " + msg);

        if (complete) {
            setTimeout(function() { foxmarksObserver.clearStatus(); },
                       status != 0 ? 5000: 1000);
        }
    },
    clearStatus: function() {
        window.XULBrowserWindow.setJSStatus("");
     }
}

var foxmarksPopupObserver = {
    observe: function(subject, topic, data) {
        xm.NewUserPopup(JSON.parse(data));
    }
}
xm.SetKeyboardShortcut = function(id, key) {
    var element = document.getElementById(id);
    element.setAttribute("key", key);
    element.setAttribute("disabled", key ? false : true);
};

xm.SetChecked = function(id, val) {
    var elem = document.getElementById(id);
    if (val) {
        elem.setAttribute("checked", true);
    } else {
        elem.removeAttribute("checked");
    }
}

xm.OnPopupShowing = function() {
    xm.SetChecked("foxmarks-showstatusicon", !xm.gSettings.hideStatusIcon);
    xm.SetChecked("foxmarks-showstars", !xm.gSettings.hideSBS);
    return true;
}

xm.ToggleIcon = function(event) {
    xm.gSettings.hideStatusIcon = !xm.gSettings.hideStatusIcon;
}

xm.ToggleStars = function() {
    xm.gSettings.hideSBS = !xm.gSettings.hideSBS;
}

function FoxmarksBrowserLoadDelayed() {
    var os = Cc["@mozilla.org/observer-service;1"].
        getService(Ci.nsIObserverService);
    os.addObserver(foxmarksObserver, "foxmarks-service", false);
    os.addObserver(foxmarksPopupObserver, "foxmarks-newpopup", false);

    xm.SetKeyboardShortcut("XmarksSyncNow", xm.gSettings.syncShortcutKey);
    xm.SetKeyboardShortcut("OpenFoxmarksDialog",
        xm.gSettings.openSettingsDialogShortcutKey);
    xm.SetKeyboardShortcut("FoxmarksSimSiteKey",
        xm.gSettings.siteinfoDialogShortcutKey);
    xm.SetKeyboardShortcut("XmarksOpenTabs", xm.gSettings.openTabsShortcutKey);

    // Load SERP
    xm.SERP.init();

    // Load similiar sites
    xm.SimSites.init();

    // Hook up tab observer for window activity
    var container = gBrowser.tabContainer;
    gBrowser.addEventListener("load", xm.tabs.Changed, false);
    container.addEventListener("TabOpen", xm.tabs.Changed, false);
    container.addEventListener("TabMove", xm.tabs.Changed, false);
    container.addEventListener("TabClose", xm.tabs.Changed, false);

    // ... and notify of a new window opened.
    xm.tabs.Changed();
}

function FoxmarksBrowserLoad() {
  //In an attempt to have less impact on ff load time, run this
  //in 2 seconds.
  setTimeout(function(){FoxmarksBrowserLoadDelayed()}, 2000);
}


function FoxmarksBrowserUnload() {
    var os = Cc["@mozilla.org/observer-service;1"].
        getService(Ci.nsIObserverService);

    try {
        os.removeObserver(foxmarksObserver, "foxmarks-service");
        Xmarks.tabs.Changed();
        var container = gBrowser.tabContainer;
        gBrowser.removeEventListener("load", Xmarks.tabs.Changed, false);
        container.removeEventListener("TabOpen", Xmarks.tabs.Changed, false);
        container.removeEventListener("TabMove", Xmarks.tabs.Changed, false);
        container.removeEventListener("TabClose", Xmarks.tabs.Changed, false);
    } catch(e) {}
}

window.addEventListener("load", FoxmarksBrowserLoad, false);
window.addEventListener("unload", FoxmarksBrowserUnload, false);
})();
