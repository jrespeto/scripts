/* 
 Copyright 2010 Xmarks Inc.

 foxmarks-discover.js: Classes related to SERP and sim sites

 */

(function() {
var xm = Xmarks;
var Cu = Components.utils;
var Cc = Components.classes;
var Ci = Components.interfaces;

Cu['import']('resource://xmarks/reviews.jsm', Xmarks);
Cu['import']('resource://xmarks/base64.jsm', Xmarks);

xm.SimSites = {
    DRIFTSITE: "/site/?cid=xmfx&url=",
    SIMSITE: "/internal/visitsite?cid=xmfx&id=",
    TOPICSITE: "/topic/",
    WRITEREVIEW: "/review/edit/?cid=xmfx&url=",
    _iconLoaded: false,
    observe: function(subject, topic, data) {
        var shouldShow;
        if (topic == "foxmarks-settingschange") {
            shouldShow = this.settings.simsiteEnabled && 
                !this.settings.privateBrowsing;
        } else if (topic == "private-browsing") {
            if (data == "enter") {
                shouldShow = false;
            } else if (data == "exit") {
                shouldShow = this.settings.simsiteEnabled;
            }
        }
        if (shouldShow && !this._iconLoaded) {
            this.addIcon();
        } else if (!shouldShow && this._iconLoaded) {
            this.removeIcon();
        }
    },
    addIcon: function(){
        var staricon = this.doc.getElementById("star-button");
        var pnode = null;
        if (staricon) {
            pnode = staricon.parentNode;
        } else {
            // Since FF 29, star button is no longer in the
            // nav bar, so let's try this other random thing
            // from browser.xul
            pnode = this.doc.getElementById('urlbar-icons');
        }
        if (pnode != null && !this._iconLoaded){
            var img = this.doc.createElement('image');
            img.setAttribute('id', "foxmarks-ss-button");
            img.setAttribute('tooltiptext',
                    xm.Bundle().GetStringFromName("similarsite.getsiteinfo"));
            img.setAttribute('src', 
                    xm.gSettings.httpProtocol + xm.gSettings.staticHost +
                    xm.gSettings.bibBug);
            img.addEventListener(
                "mousedown",
                function(e){
                    xm.SimSites.showSimSites();
                },
                true
            );

            pnode.appendChild(img);
            this._iconLoaded = true;
        }
    },
    removeIcon: function() {
        var image = this.doc.getElementById("foxmarks-ss-button");
        image.parentNode.removeChild(image);
        this._iconLoaded = false;
    },
    openLink: function(link, addTab){
        var callback= {
            notify: function(){
                if(addTab){
                    gBrowser.selectedTab = gBrowser.addTab(link);
                } else {
                    gBrowser.selectedBrowser.contentDocument.location.href =
                        link;
                }
            }
        };
        var timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        timer.initWithCallback(callback, 100,
            Ci.nsITimer.TYPE_ONE_SHOT);
    },
    init: function(){
        this.settings = xm.gSettings;
        this.doc = document;
        if(this.settings.simsiteEnabled && !this.settings.privateBrowsing){
            this.addIcon();
        }
        var os = Cc["@mozilla.org/observer-service;1"].
            getService(Ci.nsIObserverService);
        os.addObserver(this, "foxmarks-settingschange", false);
        os.addObserver(this, "private-browsing", false);
        /*
         * FYI this doesn't work so well in linux so using our own 
         * messaging system
        var prefs = Components.classes["@mozilla.org/preferences-service;1"]
                .getService(Components.interfaces.nsIPrefBranch2);
        prefs.addObserver("extensions.xmarks.", this, false);
        */
        var iframe = document.getElementById("foxmarks-bib");
        var self = this;
        var unloadFunc = function(event){
            iframe.removeEventListener(
                "unload",
                unloadFunc,
                true
            );
            var doc = event.target;
            var biblink = doc.getElementById("biblink");
            var link = biblink ? biblink.getAttribute("value") : null;

            if(link){
                var panel = document.getElementById("foxmarks-similarsites");
                if(panel){
                    panel.hidePopup();
                }
                var bibkeys = doc.getElementById("bibkeys");
                var keys = bibkeys.getAttribute("value");
                if(keys.indexOf("M") != -1 || keys.indexOf("C") != -1){
                    self.openLink(link, true);
                } else {
                    self.openLink(link, false);
                }
            }
        };
        iframe.addEventListener(
            "DOMContentLoaded", 
            function(event){
                if(event.target.location.href != "about:blank"){
                    self.handleBibLoad(event.target);
                    iframe.addEventListener(
                        "unload",
                        unloadFunc,
                        true
                    );
                }

            }, 
            true
        );
    },
    handleBibLoad: function(doc){
       var iframe = this.doc.getElementById("foxmarks-bib");
       var win = doc.defaultView;
       var pageHeight = win.innerHeight + win.scrollMaxY
       iframe.setAttribute("height",pageHeight);
       iframe.style.overflow = "hidden";
       this.doc.getElementById("foxmarks-ss-body").
            setAttribute("height", pageHeight);
       //iframe.style.height = "500px;";

    },
    clearPanel: function(){
        this.doc.getElementById("foxmarks-ss-progtitle").
            setAttribute("hidden", "true");
        this.doc.getElementById("foxmarks-ss-progress").
            setAttribute("hidden", "false");
        this.doc.getElementById("foxmarks-ss-body").
            setAttribute("hidden", "true");
        var iframe = this.doc.getElementById("foxmarks-bib");
        iframe.setAttribute("src", "about:blank");
        iframe.setAttribute("height","32");
        iframe.style.overflow = "hidden";
        this.doc.getElementById("foxmarks-ss-body").
            setAttribute("height", "32");
        this.doc.getElementById("xmarks-ss-vbox").
            setAttribute("height", "32");
        this.doc.getElementById("xmarks-ss-vbox").
            setAttribute("width", "500");
        this.doc.getElementById("foxmarks-similarsites").
            setAttribute("height", "32");
    },
    onPopupHiding: function(){
        if(this._inflight){
            this._inflight = false;
            Xmarks.SimilarSitesCancel();
        }
        xm.SimSites.detachKeyListener();
        return true;
    },
    _handleKeyListener: function(e){
        // static member; this is undefined
        if(e.metaKey){
           return;
        }
        var panel = this.doc.getElementById("foxmarks-similarsites");
        if(panel){
            panel.hidePopup();
        }
    },
    detachKeyListener: function(){
        var urlbar = this.doc.getElementById("urlbar");
        if(!urlbar){
            return;
        }
        urlbar.removeEventListener("keydown", this._handleKeyListener, true);
    },
    attachKeyListener: function(){
        var urlbar = this.doc.getElementById("urlbar");
        if(!urlbar){
            return;
        }
        urlbar.addEventListener("keydown", this._handleKeyListener, true);
    },
    showSimSites: function(){
        if (this.settings.privateBrowsing) {
            return;
        }
        var panel = this.doc.getElementById("foxmarks-similarsites");
        if(panel){

            //BUGFIX for Windows  where popup would close randomly
            var content = this.doc.getElementById("content");
            content.focus();

            this.attachKeyListener();
            panel.openPopup(
                this.doc.getElementById("urlbar"),
                "after_end",
                0,
                0,
                false,
                false
            );
            var url = gBrowser.selectedBrowser.contentDocument.location.href;
            this.clearPanel();
            this._inflight = true;

            var self = this;
            Xmarks.FetchSimilarSites(
                url, 
                this.doc.getElementById("foxmarks-ss-progtitle"), 
                this.doc.getElementById("foxmarks-ss-throbber"), 
                function(data){
                    self._inflight = false;
                    xm.SimSites.loadData(data);
                }
            );
        }
    },
    loadData: function(data){
        if(data && data.status == 0){
            var iframe = this.doc.getElementById("foxmarks-bib");
            iframe.setAttribute("src", "data:text/html;base64," +
                Xmarks.Base64.encode(data.txt, false));
            this.doc.getElementById("foxmarks-ss-progress").
                setAttribute("hidden", "true");
            this.doc.getElementById("foxmarks-ss-body").
                setAttribute("hidden", "false");
        } else {
            var errbox = this.doc.getElementById("foxmarks-ss-progtitle");

            errbox.setAttribute("value",
                "Xmarks: " + xm.Bundle().GetStringFromName(
                    data.status == 0 || data.status == 400 ?
                    "similarsite.nositeinfo" :
                    "similarsite.busy"
                )
            );

            errbox.setAttribute("hidden", "false");
        }
    }

};

xm.SERP = {
    init: function(){
    },
    buildScriptURL: function(prefix){
    },
    onPageLoad: function(e){
    },
    injectScript: function(prefix, doc){
    },
    handleOpenSettings: function(e, doc){
    }
};
})();
