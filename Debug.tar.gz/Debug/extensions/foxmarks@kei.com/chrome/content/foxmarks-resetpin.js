/* 
 Copyright 2008 Foxmarks Inc.
 
 foxmarks-resetpin.js: handles the UI for the ResetPIN dialog. 
  
 */

function onResetPINOK()
{
    var pin = document.getElementById("newpin").value;
    var pin2 = document.getElementById("newpin2").value;

    if(!pin || pin.length < 4 || pin.length > 255){
        Xmarks.Alert(Xmarks.Bundle().GetStringFromName("error.pinWrongSize"));
        return false;
    }

    if(!pin2 || pin != pin2){
        Xmarks.Alert(Xmarks.Bundle().GetStringFromName("error.pinNoMatch"));
        return false;
    }
    if(pin == Xmarks.gSettings.password){
        Xmarks.Alert(Xmarks.Bundle().GetStringFromName("error.pinEqualsPassword"));
        return false;
    }

    Xmarks.gSettings.pin = pin;
    Xmarks.gSettings.rememberPin = document.getElementById("rememberPin").checked;
    Xmarks.gSettings.setMustUpload("passwords", true);
    window.arguments[0].doSync = true;
    return true;
}

