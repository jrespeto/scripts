/* 
 Copyright 2007 Foxmarks Inc.
 
 foxmarks-clobber.js: handles the UI for the Clobber dialog. 
  
 */

function onClobberLoad()
{
    if(typeof(window.arguments)=="undefined")
      return false;

    window.arguments[0].action = 'cancel';
    
    if(window.arguments[1]==-1 && window.arguments[2]==-1){
      //Tell the user that they should download.
      //doc.buttons = "cancel,accept1";
      document.documentElement.getButton("extra2").setAttribute("hidden", "true");
      document.documentElement.getButton("accept").setAttribute("hidden", "true");
      document.getElementById("descerror").style.display='';
      document.getElementById("desc2").style.display='none';
      document.getElementById("html").style.display='none';
      document.getElementById("details").style.display='none';
    }else{
      document.getElementById("lastset").setAttribute("value",
        window.arguments[2]);
      document.getElementById("currset").setAttribute("value",
        window.arguments[1]);
    }
    return true;
}

function onClobberSync()
{
    window.arguments[0].action = 'sync';
    return true;
}

function onClobberCancel()
{
    window.arguments[0].action = 'cancel';
    return true;
}

function onClobberDownload() {
    window.arguments[0].action = 'download';
    window.close();
    return true;
}

function onClobberHelp(url)
{
    window.openDialog("chrome://browser/content/browser.xul",
	    "_blank", "chrome,all,dialog=no", url);
    return false;
}

 
