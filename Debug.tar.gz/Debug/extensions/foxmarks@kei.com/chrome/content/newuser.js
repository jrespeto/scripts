(function() {
var xm = Xmarks;

xm._popupCloseState = false;
xm.ClickNewUserPopup = function(){
    xm._popupCloseState = true;
    var panel = document.getElementById("foxmarks-newuserwiz");
    if(panel){
        panel.hidePopup();
    }
    Xmarks.OpenWizard(false, false);
};
xm.NewUserPopupHiding = function(){
    if(xm._popupCloseState){
        return true;
    }
    var panel = document.getElementById("foxmarks-newuserwiz");
    if(panel){
        var TOTALTIME = 1000;
        var  NUMSTEPS = 20;
        var ctr = 0;
        var func = function() {
            var opac = Number(panel.style.opacity);
            if(opac > 0 && ctr < NUMSTEPS){
                panel.style.opacity = Math.max(opac - (1 / NUMSTEPS), 0);
                ctr++;
                window.setTimeout(function() { func(); },
                                  Math.floor(TOTALTIME / NUMSTEPS));
            } else {
                xm._popupCloseState = true;
                panel.hidePopup();
            }

        };
        window.setTimeout(func, 2000);
        xm._popupCloseState = true;
    }
    return false;
};
xm.CloseNewUserPopup = function(){
    var panel = document.getElementById("foxmarks-newuserwiz");
    if(panel){
        var os = Cc["@mozilla.org/observer-service;1"].
            getService(Ci.nsIObserverService);
        os.notifyObservers(null, "foxmarks-tr","closebubble"); 
        xm._popupCloseState = true;
        panel.hidePopup();
    }
};
xm.NewUserPopup = function(data){
    if(!data || data.status !== 0 || !data.use_bib){
        Xmarks.OpenWizard(false, false);
    } else {
        xm._popupCloseState = false;
        xm.gSettings.wizardRetriesLeft = xm.gSettings.wizardRetriesLeft - 1;
        var panel = document.getElementById("foxmarks-newuserwiz");
        if(panel){
            panel.setAttribute("style", data.popup_style);
            var box = document.getElementById("foxmarks-bubblebox");
            box.setAttribute("style", data.box_style);

            box = document.getElementById("foxmarks-bubblecontainer");
            box.setAttribute("style", data.container_style);

            box = document.getElementById("foxmarks-bubbletextbox");
            box.setAttribute("style", data.text_style);

            box = document.getElementById("foxmarks-bubbletitle");
            box.setAttribute("style", data.title_style);

            if(xm.gSettings.is_english){
                box.setAttribute("value", data.title_english);
            }

            box = document.getElementById("foxmarks-bubbleclose");
            box.setAttribute("style", data.close_style);

            box = document.getElementById("foxmarks-bubbledesc");
            box.setAttribute("style", data.desc_style);
            if(xm.gSettings.is_english){
                box.removeChild(box.firstChild);
                var desc = document.createTextNode(
                    data.desc_english
                );
                box.appendChild(desc);
            }

            panel.openPopup(
                document.getElementById(data.anchor),
                data.position,
                data.posx,
                data.posy,
                false,
                false
            );
            setTimeout(function(){
                panel.style.opacity = 1.0;
            }, 100);

            document.getElementById("foxmarks-bubbleclose").addEventListener(
                "click",
                function(e){
                    e.stopPropagation();
                    xm.CloseNewUserPopup();
                }, 
                true
            );
        }
    }
};
})()
