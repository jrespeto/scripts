/* function atob is:
 *
 * Copyright (c) 2007, David Lindquist <david.lindquist@gmail.com>
 * Released under the MIT license
 */


function My_atob(str) {
    var chars = 
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    var invalid = {
        strlen: (str.length % 4 != 0),
        chars:  new RegExp('[^' + chars + ']').test(str),
        equals: (/=/.test(str) && (/=[^=]/.test(str) || /={3}/.test(str)))
    };
    if (invalid.strlen || invalid.chars || invalid.equals)
        throw new Error('Invalid base64 data');
    var decoded = [];
    var c = 0;
    while (c < str.length) {
        var i0 = chars.indexOf(str.charAt(c++));
        var i1 = chars.indexOf(str.charAt(c++));
        var i2 = chars.indexOf(str.charAt(c++));
        var i3 = chars.indexOf(str.charAt(c++));
        var buf = (i0 << 18) + (i1 << 12) + ((i2 & 63) << 6) + (i3 & 63);
        var b0 = (buf & (255 << 16)) >> 16;
        var b1 = (i2 == 64) ? -1 : (buf & (255 << 8)) >> 8;
        var b2 = (i3 == 64) ? -1 : (buf & 255);
        decoded.push(b0);
        if (b1 >= 0) decoded.push(b1);
        if (b2 >= 0) decoded.push(b2);
    }
    return decoded;
}

function equals(a, b) {
    if (typeof a != typeof b)
        return false;
    if (typeof a != 'object')
        return a == b;
    if (a == b)
        return true;
    if (a.length != undefined && b.length != undefined) {
        if (a.length != b.length)
            return false;
        for (var i = 0; i < a.length; ++i) {
            if (a[i] != b[i])
                return false;
        }
        return true;
    } else {
        throw Error("can't compare non-Array objects");
    }
}


function tagEquals(a, b) {
    // Normalize two lists of tags and decide whether they are
    // "equivalent."

    if (!a && !b)
        return true;

    if (!a || !b)
        return false;

    if (a.length != b.length)
        return false;   // Quick exit.
 
    if (equals(a, b))
        return true;    // Less quick exit.

    // Slow path. Copy the originals.
    var x = a.slice();
    var y = b.slice();

    x.sort();
    y.sort();

    return equals(x, y);
}

exports.equals = equals;
exports.tagEquals = tagEquals;
exports.My_atob = My_atob;
