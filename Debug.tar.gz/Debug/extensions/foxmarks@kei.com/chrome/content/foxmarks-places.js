/*
 Copyright 2008-2010 Xmarks Inc.

 foxmarks-places.js: implements class BookmarkDatasource, encapsulating
 the Firefox Places datasource.

 */

const { Cc, Ci, Cr, Cu } = require("chrome");

var FoxmarksBookmarks = require("./foxmarks-bookmark.js");
var utils = require("./foxmarks-utils.js");
var b64 = require("./b64.js").Base64;

Cu['import']("resource://gre/modules/FileUtils.jsm");
Cu['import']("resource://gre/modules/Services.jsm");

if (typeof(exports.plugin) == "undefined") {
    // when running from test cases...
    var Xmarks = {};
    Xmarks.ns = require("./foxmarks-nodes.js");
    Xmarks.LogWrite = function(x) { console.log(x); }
    Xmarks.LogError = function(x, e) { console.log(x + ": " + e.name + " " + e.message); }
} else {
    Xmarks = exports.plugin;
}

var MAP_NATIVE_TO_NID = /folder=(\d+)/g
var MAP_NID_TO_NATIVE = /folder=nid-([\w\-]+)/g
var MAP_TAG_TO_NATIVE = /folder=tag-([^&]+)/g
var MAP_NATIVE_TO_TAG = /folder=([^&]+)/g

// Comment out this line and uncomment block below to enable
// collection and reporting of timing info.

var collectTimingInfo = false;

/*

var collectTimingInfo = true;

function StartTimes(activity) {
    StartTimes.activity = activity;
    StartTimes.start = Date.now();
    ResetTimes();
    Xmarks.LogWrite("Starting " + activity + "...");
}

function AddTime(f, t) {
    if (!AddTime.times) {
        AddTime.times = {};
    }
    if (!AddTime.times[f]) {
        AddTime.times[f] = [];
    }
    AddTime.times[f].push(t);
}

function ReportTimes() {
    Xmarks.LogWrite("Total time for " + String(StartTimes.activity) + ": " + 
        String(Date.now() -  StartTimes.start));

    function min(a) {
        var m;
        forEach(a, function(v) {
            if (!m || v < m) {
                m = v;
            }
        });
        return m;
    }

    function max(a) {
        var m;
        forEach(a, function(v) {
            if (!m || v > m) {
                m = v;
            }
        });
        return m;
    }

    function avg(a) {
        return (tot(a) / a.length).toPrecision(3);
    }

    function tot(a) {
        var m = 0;
        forEach(a, function(v) {
            m += v;
        });
        return m;
    }

    forEach(AddTime.times, function(v, k) {
            Xmarks.LogWrite("Time: " + k + ": " + String(v.length) + " times, " +
                String(tot(v)) + "ms total (" + 
                String(min(v)) + "/" + String(max(v)) + "/" + String(avg(v)) +
                ")");
    });
}

function ResetTimes() {
    AddTime.times = {};
}

*/

function Call(o, f) {
    var functionRE = /function (\w+)\(\)/;
    var args = [];
    if (arguments.length > 2) {
        args = Array.prototype.slice.call(arguments, 2);
    }

    try {
        if (collectTimingInfo) {
            var start = Date.now();
        }
        var returnVal =  f.apply(o, args);
        if (collectTimingInfo) {
            var end = Date.now();
            AddTime(f.toSource().match(functionRE)[1], end - start);
        }
        return returnVal;
    } catch (e) {
        // Detect specific errors and map them to our own
        switch (e.result) {
        case Cr.NS_ERROR_FILE_CORRUPTED:
            throw 5;
        default:
            var errmsg = "Places error calling " + f + " with args " +
                args.toSource() + " Original error: " +
                e.name + ": " + e.message;
            if (e.result != Cr.NS_ERROR_NOT_AVAILABLE) {
                Xmarks.reportErrorServer(errmsg);
            }
            throw Error(errmsg);
        }
    }
}

function ParseIconString(s) {
    var exp = /^data:(.*);base64,(.*)$/;
    var match = exp.exec(s);

    if (match) {
        try {
            var data = utils.My_atob(match[2]);
        } catch (e) {
            return null;
        }
        return [match[1] /* mime type */, data /* b64-encoded data */];
    } else {
        return null;
    }
}

// Node's representation of dates is seconds since 1/1/1970.
// Mozilla's representation of dates is microseconds since 1/1/1970.
// Use these utility functions to convert between the two formats
// while minimizing rounding error.

function DatePlacesToNode(v) {
    return Math.round(v / 1000000);
}

function DateNodeToPlaces(v) {
    return (v || 0) * 1000000;
}

// Bare-bones version of promises.  Feel free to replace with
// MDN version when generally available.
function XmPromise() {
    this.todo = function(){};
}
// p.resolve(v) is called to set value when known.
// calling resolve will call todo(value).
XmPromise.prototype.resolve = function(value) {
    this.todo(value);
};
// p.then(t) registers t to be called when v is known.
XmPromise.prototype.then = function(t) {
    this.todo = t;
};

function BookmarkDatasource() {
    this.InitServices();

    if (!BookmarkDatasource._mapNidToNative) {
        this._InitNidNativeMaps();
    }

    if (!BookmarkDatasource._locationMap) {
        this._InitLocationMap();
    }

    // defined in foxmarks-sync.js
    FoxmarksBookmarks.applyCommonBookmarkFunctions(this);

    // check for APIs that were removed in FF14
    if (this.bmsvc.getItemIdForGUID) {
        Xmarks.LogWrite("Host browser is FF<14");

        try {
            if (this.CreateXmarksTable()) {
                // migrate DB while we still can
                this.MigrateXmarksDB();
            }

            // use our private DB from now on, even for FF<14
            // this ensures nid mapping is up-to-date when user upgrades
            this.UsePrivateDB = true;
        } catch (e) {
            Xmarks.LogWrite("Exception; Could not migrate DB");
        }
    } else {
        if (!this.lmsvc) {
            Xmarks.LogWrite("Host browser is FF22+, use private DB, use async favicon and livemarks functions");

            // figure out which version of mialm we have
            var lmi = {
                id: 1
            };
            var promise = null;
            try {
                promise = this.mialm.getLivemark(lmi);
                Xmarks.LogWrite("Host browser is FF29+, use promises for livemarks");
                promise.then(function(){}, function(){});
            } catch (e) {
                Xmarks.LogWrite("Host browser is < FF29, use callback for livemarks (e=" + e.result + ")");
            }
            this.UseLMPromises = promise != null;
        }
        else
            Xmarks.LogWrite("Host browser is FF14+, use private DB");

        // make sure the mapping table exists
        this.CreateXmarksTable();

        this.UsePrivateDB = true;
    } 
}

BookmarkDatasource.syncType = "bookmarks";

BookmarkDatasource.SERVICES = [
    ["bmsvc", "@mozilla.org/browser/nav-bookmarks-service;1", 
        Ci.nsINavBookmarksService],
    ["hsvc", "@mozilla.org/browser/nav-history-service;1", 
        Ci.nsINavHistoryService],
    ["asvc", "@mozilla.org/browser/annotation-service;1", 
        Ci.nsIAnnotationService],
    ["lmsvc", "@mozilla.org/browser/livemark-service;2",
        Ci.nsILivemarkService],
    ["mialm", "@mozilla.org/browser/livemark-service;2",
        Ci.mozIAsyncLivemarks],
    ["tsvc", "@mozilla.org/browser/tagging-service;1",
        Ci.nsITaggingService],
    ["fisvc", "@mozilla.org/browser/favicon-service;1",
        Ci.nsIFaviconService],
    ["afisvc"],
    ["mssvc", "@mozilla.org/microsummary/service;1",
        Ci.nsIMicrosummaryService],
    ["fusvc", "@mozilla.org/docshell/urifixup;1",
        Ci.nsIURIFixup]
];


BookmarkDatasource.STORAGE_ENGINE = "/Places";
BookmarkDatasource.startupTime = Date.now();
BookmarkDatasource.sessionId = BookmarkDatasource.startupTime.toString(36);
BookmarkDatasource.nidIndex = 0;
BookmarkDatasource.MAX_NID_LENGTH = 32;
BookmarkDatasource.LOCATION_MAP_ANNO_NAME = "foxmarks/locationMap";
BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE = 
    { 0 : "bookmark", 5: "query", 6: "folder", 7: "separator", 9: "query" };
BookmarkDatasource.MAP_NTYPE_TO_PLACE_TYPE = { 
    "bookmark": [0, 5, 9], 
    "microsummary": [0], 
    "query": [0, 5, 9], 
    "folder": [6], 
    "feed": [6], 
    "separator": [7]};

BookmarkDatasource.MAP_ANNO_TO_NODE = {
    "bookmarkProperties/description"    : ["description"],
    "bookmarkProperties/POSTData"       : ["formdata"],
    "bookmarkProperties/loadInSidebar"  : ["sidebar", 
                                            function(x) { return true; }],
    "livemark/feedURI"                  : ["feedurl"],
    "livemark/siteURI"                  : ["url"],
    "microsummary/generatorURI"         : ["generateduri"],
    "bookmarks/contentType"             : ["contenttype"]
};

BookmarkDatasource.MAP_NODE_TO_ANNO = {
    "description"   : "bookmarkProperties/description",
    "formdata"      : "bookmarkProperties/POSTData",
    "sidebar"       : "bookmarkProperties/loadInSidebar",
    "feedurl"       : "livemark/feedURI",
    "generateduri"  : "microsummary/generatorURI",
    "contentType"   : "bookmarks/contentType"
};

BookmarkDatasource.INTERESTING_PROPERTIES = {
    "title"         : true,
    "keyword"       : true,
    "uri"           : true
};

BookmarkDatasource.KNOWN_ATTRS = {
    "ntype"         : true,
    "description"   : true,
    "formdata"      : true,
    "sidebar"       : true,
    "feedurl"       : true,
    "generateduri"  : true,
    "contentType"   : true,
    "name"          : true,
    "created"       : true,
    "modified"      : true,
    "visited"       : true,
    "shortcuturl"   : true,
    "nid"           : true,
    "pnid"          : true,
    "children"      : true,
    "url"           : true,
    "icon"          : true,
    "tags"          : true,
    "tnid"          : true,
    "unid"          : true
};

BookmarkDatasource.MapPlacesToNode = function(place, pnid, children) {
    var self = this;

    if (!(place instanceof Ci.nsINavHistoryResultNode)) {
        throw Error("Unknown object type " + place);
    }

    if (!(place.type in BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE)) {
        Xmarks.LogWrite("Warning: Unhandled result type " + place.type);
        return 0;
    }

    var node = new Xmarks.ns.Node(this.MapNative(place.itemId));
    node.pnid = pnid;
    node.ntype = BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE[place.type];
    if (node.ntype == 'folder' && this.IsLivemark(place.itemId)) {
        node.ntype = 'feed';
    } else if (node.ntype == 'bookmark' && this.mssvc &&
            Call(this.mssvc, this.mssvc.hasMicrosummary, place.itemId)) {
        node.ntype = 'microsummary';
    }

    if (place.title && place.title.length) {
        node.name = place.title;
    }
    if (node.ntype == 'bookmark' || node.ntype == 'query' || 
            node.ntype == 'microsummary') {
        node.url = place.uri;
        if (node.ntype == 'query') {
            try {
                // Test to see if it's a tag query.
                if (place.QueryInterface(Ci.nsINavHistoryQueryResultNode).
                        queryOptions.resultType == 
                        Ci.nsINavHistoryQueryOptions.RESULTS_AS_TAG_CONTENTS) {
                    node.url = node.url.replace(
                            MAP_NATIVE_TO_TAG, function(x,y) {
                            return "folder=tag-" + 
                                encodeURIComponent(node.name);
                    });
                } else {
                    node.url = node.url.replace(
                            MAP_NATIVE_TO_NID, function(x, y) {
                        var nid;
                        try {
                            nid = self.MapNative(y, true);
                        } catch(e) {
                            Xmarks.LogWrite("Warning: failed mapping item" + 
                                    y + " within node " + 
                                    node.toSource() + ". Error is " + 
                                    e.toSource());
                            return "";  // Disappear the failed item reference.
                        }
                        return "folder=nid-" + nid;
                    });
                }
            } catch (e) {
                Xmarks.LogWrite("Warning: Failed mapping " + node.toSource() +
                    ". Error is " + e.toSource());
            }
        } 
    }
    if (place.dateAdded) 
        node.created = DatePlacesToNode(place.dateAdded);
    if (place.lastModified)
        node.modified = DatePlacesToNode(place.lastModified);
    if (place.time)
        node.visited = DatePlacesToNode(place.time);
    var keyword = null;
    try {
        keyword = Call(self.bmsvc, self.bmsvc.getKeywordForBookmark, place.itemId);
    } catch(e) {
        Xmarks.LogWrite("Warning: getKeywordForBookmark exception, place.itemId=" + place.itemId);
    }
    if (keyword) {
        node.shortcuturl = keyword;
    }
    if (node.ntype == 'folder' && children) {
        node.children = children;
    }

    if (node.ntype == 'bookmark' && node.url) {
        var uri = self.NewURI(node.url);
        var iconUri = null;
        try {
            if (uri != null && self.fisvc.getFaviconForPage) {
               iconUri = Call(self.fisvc, self.fisvc.getFaviconForPage, uri);
            }
        } catch(e) {}
        if (iconUri) {
            var mimeType = {};
            var iconData = null;
            try {
                iconData = Call(self.fisvc, self.fisvc.getFaviconData, iconUri, 
                    mimeType, {});
            } catch(e) {}
            if (iconData && iconData.length > 0) {
                node.icon = "data:" + mimeType.value + ";base64," + 
                    b64.encode(iconData, true);
            }
        }
    }

    Object.keys(BookmarkDatasource.MAP_ANNO_TO_NODE).forEach(function(k) {
        var attr = BookmarkDatasource.MAP_ANNO_TO_NODE[k];
        var value = GetAnnotation(place.itemId, k);
        if (value) {
            node[attr[0]] = attr[1] ? attr[1](value) : value;
        }
    } );

    if (place.uri) {
        var uri = self.NewURI(place.uri);
        var tags = uri ? Call(this.tsvc, this.tsvc.getTagsForURI, uri, {}) : [];
        if (tags.length) {
            node.tags = tags.slice().filter(function(x) { 
                    return x && x.length; });
        }
    }

    this.pn.AddNode.apply(this.pn.Caller, [node]);
    return 0;

    function GetAnnotation(itemId, anno) {
        try {
            return Call(self.asvc, self.asvc.getItemAnnotation, itemId, anno);
        } catch (e) {
            return null;
        }
    }
}

BookmarkDatasource.MapPlacesToNodeAsync = function(place, pnid, children, callback) {
    var self = this;

    if (!(place instanceof Ci.nsINavHistoryResultNode)) {
        Xmarks.LogWrite("Warning: Unknown object type " + place);
        throw Error("Unknown object type " + place);
    }

    if (!(place.type in BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE)) {
        Xmarks.LogWrite("Warning: Unhandled result type " + place.type);
        callback(0);
        return;
    }

    //Xmarks.LogWrite("in MapPlacesToNodeAsync()");

    var node = new Xmarks.ns.Node(this.MapNative(place.itemId));
    node.pnid = pnid;
    node.ntype = BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE[place.type];

    self.IsFeedAsync(node, place, function(isfeed) {

        if (isfeed) {
            node.ntype = 'feed';
        } else if (node.ntype == 'bookmark' && this.mssvc &&
                Call(this.mssvc, this.mssvc.hasMicrosummary, place.itemId)) {
            node.ntype = 'microsummary';
        }

        if (place.title && place.title.length) {
            node.name = place.title;
        }

        Xmarks.LogWrite("in MapPlacesToNodeAsync() nid=" + node.nid + " node.name=" + node.name + " node.ntype=" + node.ntype + " uri=" + place.uri);

        if (node.ntype == 'bookmark' || node.ntype == 'query' || 
                node.ntype == 'microsummary') {
            node.url = place.uri;
            if (node.ntype == 'query') {
                try {
                    // Test to see if it's a tag query.
                    if (place.QueryInterface(Ci.nsINavHistoryQueryResultNode).
                            queryOptions.resultType == 
                            Ci.nsINavHistoryQueryOptions.RESULTS_AS_TAG_CONTENTS) {
                        node.url = node.url.replace(
                                MAP_NATIVE_TO_TAG, function(x,y) {
                                return "folder=tag-" + 
                                    encodeURIComponent(node.name);
                        });
                    } else {
                        node.url = node.url.replace(
                                MAP_NATIVE_TO_NID, function(x, y) {
                            var nid;
                            var error = false;
                            try {
                                nid = self.MapNative(y, true);
                            } catch(e) {
                                Xmarks.LogWrite("Warning: failed mapping item" + 
                                        y + " within node " + 
                                        node.toSource() + ". Error is " + 
                                        e.toSource());
                                error = true// Disappear the failed item reference.
                            }
                            return "folder=nid-" + nid;
                        });
                    }
                } catch (e) {
                    Xmarks.LogWrite("Warning: Failed mapping " + node.toSource() +
                        ". Error is " + e.toSource());
                }
            } 
        }
        if (place.dateAdded) 
            node.created = DatePlacesToNode(place.dateAdded);
        if (place.lastModified)
            node.modified = DatePlacesToNode(place.lastModified);
        if (place.time)
            node.visited = DatePlacesToNode(place.time);
        var keyword = null;
        try {
            keyword = Call(self.bmsvc, self.bmsvc.getKeywordForBookmark, place.itemId);
        } catch(e) {
            Xmarks.LogWrite("Warning: getKeywordForBookmark exception, place.itemId=" + place.itemId);
        }
        if (keyword) {
            node.shortcuturl = keyword;
        }
        if (node.ntype == 'folder' && children) {
            node.children = children;
        }

        if (node.ntype == 'bookmark' && node.url) {
            var uri = self.NewURI(node.url);

            self.GetIconDataAsync(uri, function(encodeddata) {
                if (encodeddata) {
                    node.icon = encodeddata;
                }

                MapPlacesToNodeAsync_continuation(self, node, place, callback);

            });
        } else {
            MapPlacesToNodeAsync_continuation(self, node, place, callback);
        }
    });


    function MapPlacesToNodeAsync_continuation(self, node, place, callback) {
        //Xmarks.LogWrite("in MapPlacesToNodeAsync_continuation()");

        Object.keys(BookmarkDatasource.MAP_ANNO_TO_NODE).forEach(function(k) {
            var attr = BookmarkDatasource.MAP_ANNO_TO_NODE[k];
            var value = GetAnnotation(place.itemId, k);
            if (value) {
                node[attr[0]] = attr[1] ? attr[1](value) : value;
            }
        } );

        if (place.uri) {
            var uri = self.NewURI(place.uri);
            var tags = uri ? Call(self.tsvc, self.tsvc.getTagsForURI, uri, {}) : [];
            if (tags.length) {
                node.tags = tags.slice().filter(function(x) { 
                        return x && x.length; });
            }
        }

        self.pn.AddNode.apply(self.pn.Caller, [node]);

        callback(0);
    }
    

    function GetAnnotation(itemId, anno) {
        try {
            return Call(self.asvc, self.asvc.getItemAnnotation, itemId, anno);
        } catch (e) {
            return null;
        }
    }
}

BookmarkDatasource.ProvideNodesDone = function(status) {
    if (!status) {
        // Order is significant here; apply in reverse order
        // from that in which these were accepted.
        this._ApplyLocationMap(this.pn.Caller, 
            this.bmsvc.unfiledBookmarksFolder);
        this._ApplyLocationMap(this.pn.Caller,
            this.bmsvc.toolbarFolder);
        this.pn.Caller.Node(Xmarks.ns.NODE_ROOT, true).tnid =
            this.MapNative(this.bmsvc.toolbarFolder);
        this.pn.Caller.Node(Xmarks.ns.NODE_ROOT, true).unid =
            this.MapNative(this.bmsvc.unfiledBookmarksFolder);
    }
    this.pn.Caller.placesSource = true;
    this.pn.Complete.apply(this.pn.Caller, [status]);
    this.pn = null;
    if (collectTimingInfo)
        ReportTimes();
    Xmarks.LogWrite("ProvideNodes() end");
    return;
}

// ot is the static object that maintains state for OnTree,
// the tree-walker.

var ot = {}

BookmarkDatasource.prototype = {

    lastModified: null,

    get dirty() { return BookmarkDatasource.dirty; },
    set dirty(val) { return BookmarkDatasource.dirty = val; },

    InitServices: function() {
        this.initialized = true;
        for (var i = 0; i < BookmarkDatasource.SERVICES.length; ++i) {
            var service = BookmarkDatasource.SERVICES[i];
            try {
                if ([service[0]] == "afisvc") {
                   this[service[0]] = this.fisvc.QueryInterface(Ci.mozIAsyncFavicons);
                } else {
                   this[service[0]] = Cc[service[1]].getService(service[2]);
                }
            } catch (e) {
                if ('mssvc' == service[0]) {
                  this['mssvc'] = null;
                } else if ('lmsvc' == service[0]) {
                  this['lmsvc'] = null;
                } else if ('afisvc' == service[0]) {
                  this['afisvc'] = null;
                } else if ('mialm' == service[0]) {
                  this['mialm'] = null;
                } else {
                  Xmarks.LogWrite("Failed to initialize " + service.toSource() + 
                          ": error is " + e.toString());
                  Xmarks.LogWrite("Error name: " + e.name);
                  Xmarks.LogWrite("Error message: " + e.message);
                  this.initialized = false;
                }
            }
        }
    },

    //
    // Nid <-> Native maps
    //

    // We use Places' GUID as our nids. These functions
    // provide mapping services between GUID/nid and the
    // native itemid.

    _InitNidNativeMaps: function() {
        BookmarkDatasource._mapNidToNative = {};
        BookmarkDatasource._mapNativeToNid = {};
        this.AddToMap(this.bmsvc.bookmarksMenuFolder, Xmarks.ns.NODE_ROOT);
    },

    GetPlacesDBConnection: function() {
        if (!BookmarkDatasource.dbConnPlaces) {
            BookmarkDatasource.dbConnPlaces = Components.classes["@mozilla.org/browser/nav-history-service;1"].getService(Components.interfaces.nsPIPlacesDatabase).DBConnection;
        }
        return BookmarkDatasource.dbConnPlaces;
    },

    GetXmarksDBConnection: function() {
        if (!BookmarkDatasource.dbConnXmarks) {
            var file = FileUtils.getFile("ProfD", ["xmarks.sqlite"]);
            BookmarkDatasource.dbConnXmarks = Services.storage.openDatabase(file);
        }
        return BookmarkDatasource.dbConnXmarks;
    },

    // Create nid mapping table to replace the GUID APIs removed in FF14+
    CreateXmarksTable: function() {
        var dbConn = this.GetXmarksDBConnection();
        if (dbConn) {
            if (!dbConn.tableExists("nid_map")) {
                try {
                    dbConn.createTable("nid_map", "item_id INTEGER NOT NULL PRIMARY KEY, nid LONGVARCHAR NOT NULL");
                    Xmarks.LogWrite("Created nid_map table");
                } catch(e) {
                    Xmarks.LogWrite("Exception while creating nid_map table: " + e);
                    throw e;
                }
                return true;
            }
        } else {
            Xmarks.LogWrite("Failed to get xmarks db connection");
        }
        return false;
    },

    // Find IDs in XmarksDB that don't point to anything, and zap them.
    CleanXmarksDB: function() {
        if (!this.UsePrivateDB)
            return;

        var self = this;

        Xmarks.LogWrite("CleanXmarksDB begin");

        dbPlaces = this.GetPlacesDBConnection();
        dbXmarks = this.GetXmarksDBConnection();

        if (!dbPlaces || !dbXmarks) {
            Xmarks.LogWrite("DB connections unavailable");
            return;
        }

        var statement =
            dbPlaces.createStatement("SELECT id from moz_bookmarks");
        var xstatement = dbXmarks.createStatement(
            "SELECT item_id from nid_map");

        var all_ids = {};
        var to_remove = [];

        try {
            while (statement.executeStep()) {
                all_ids[statement.row.id] = true;
            }
            dbXmarks.beginTransaction();
            while (xstatement.executeStep()) {
                var id = xstatement.row.item_id;
                if (!all_ids.hasOwnProperty(id)) {
                    to_remove.push(id);
                }
            }
            dbXmarks.commitTransaction();
        }
        finally
        {
            statement.reset();
            xstatement.reset();
        }
        /*
        Xmarks.LogWrite("Removing unreferenced mapped ids: " + JSON.stringify(to_remove));
        this.RemoveItemsFromPrivateDB(to_remove);
        */
        Xmarks.LogWrite("CleanXmarksDB end");
    },


    // Migrate our nids out of Places and into our own private db
    // The GUID APIs are going away in FF14+
    MigrateXmarksDB: function() {
        Xmarks.LogWrite("MigrateXmarksDB begin");

        // move item_id to nid mapping from Places into our own database
        dbPlaces = this.GetPlacesDBConnection();
        dbXmarks = this.GetXmarksDBConnection();

        if (!dbPlaces) {
            Xmarks.LogWrite("MigrateXmarksDB: unable to get Places database connection");
        } else if (!dbXmarks) {
            Xmarks.LogWrite("MigrateXmarksDB: unable to get Xmarks database connection");
        } else {
            Xmarks.LogWrite("MigrateXmarksDB working...");
            // for each item id, create an entry in the Xmarks table
            statement = dbPlaces.createStatement("SELECT item_id,content from moz_items_annos WHERE moz_items_annos.anno_attribute_id IN (SELECT id FROM moz_anno_attributes WHERE name=\"placesInternal/GUID\")");
            dbXmarks.beginTransaction();
            while (statement.executeStep()) {
                dbXmarks.executeSimpleSQL("INSERT INTO nid_map VALUES("+statement.row.item_id+",\""+statement.row.content+"\")");
            }
            dbXmarks.commitTransaction();
            Xmarks.LogWrite("MigrateXmarksDB done.");
        }
    },

    GetItemIdForGUID: function(nid, checkstale) {
        if (this.UsePrivateDB) { // FF14+
            dbConn = this.GetXmarksDBConnection();
            if (dbConn) {
                stmt = dbConn.createStatement("SELECT item_id FROM nid_map WHERE nid=\""+nid+"\"");
                if (stmt.executeStep()) {
                    value = stmt.row.item_id;

                    checkstale = true;
                    if (checkstale === true) {
                        // make sure reference points to a real bookmark
                        try {
                            Call(this.bmsvc, this.bmsvc.getItemType, value);
                        } catch (e) {
                            return -1;
                        }
                    }

                    Xmarks.LogWrite("GetItemIdForGUID got itemId " + value + " for nid " + nid);
                    return value;
                } else {
                    Xmarks.LogWrite("GetItemIdForGUID unable to get itemId for nid=" + nid);
                    return -1;
                }
            } else {
                throw Error("Unable to get Xmarks db connection");
            }
        } else { // FF3-13
            return Call(this.bmsvc, this.bmsvc.getItemIdForGUID, nid);
        }
    },

    GetItemGUID: function(itemId) {
        if (this.UsePrivateDB) { // FF14+
            dbConn = this.GetXmarksDBConnection();
            if (dbConn) {
                stmt = dbConn.createStatement("SELECT nid FROM nid_map WHERE item_id=:itemId");
                stmt.params.itemId = itemId;
                if (stmt.executeStep()) {
                    value = stmt.row.nid;

                    //Xmarks.LogWrite("GetItemGUID got nid " + value + " for itemId " + itemId);
                    return value;
                } else {
                    value = this.GenerateNid();
                    //Xmarks.LogWrite("GetItemGUID generated nid " + value + " for itemId " + itemId);
                    this.SetItemGUID(itemId, value);
                    return value;
                }
            } else {
                throw Error("Unable to get Xmarks db connection");
            }
        } else { // FF3-13
            return Call(this.bmsvc, this.bmsvc.getItemGUID, itemId);
        }
    },

    SetItemGUID: function(itemId, nid) {
        if (this.UsePrivateDB) { // FF14
            dbConn = this.GetXmarksDBConnection();
            if (dbConn) {
                var stmt = [];
                stmt.push(dbConn.createStatement("REPLACE INTO nid_map VALUES(:itemId, :nid)"));
                stmt[0].params.itemId = itemId;
                stmt[0].params.nid = nid;
                dbConn.executeAsync(stmt, stmt.length);
                //Xmarks.LogWrite("SetItemGUID set itemId=" + itemId + " nid=" + nid);
                this.AddToMap(itemId, nid);
            } else {
                throw Error("Unable to get Xmarks db connection");
            }
        } else { // FF3-13
            Call(this.bmsvc, this.bmsvc.setItemGUID, itemId, nid);
        }
    },

    // Remove bookmark from Places and update our mapping db
    RemoveItem: function(itemId) {
        if (itemId == this.bmsvc.unfiledBookmarksFolder ||
            itemId == this.bmsvc.toolbarFolder ||
            itemId == this.bmsvc.bookmarksMenuFolder) {
            Xmarks.LogWrite("Skipping removal of root itemId " + itemId);
            return;
        }

        Call(this.bmsvc, this.bmsvc.removeItem, itemId);

        // keep our private database in sync
        this.RemoveItemsFromPrivateDB([itemId]);
    },

    RemoveItemsFromPrivateDB: function(itemlist) {
        if (this.UsePrivateDB) {
            dbConn = this.GetXmarksDBConnection();
            if (dbConn) {
                var stmt = dbConn.createStatement("DELETE FROM nid_map WHERE item_id=:itemId");
                var params = stmt.newBindingParamsArray();
                for (var i=0; i<itemlist.length; i++) {
                    var bp = params.newBindingParams();
                    bp.bindByName("itemId", itemlist[i]);
                    params.addParams(bp);
                }
                stmt.bindParameters(params);
                stmt.executeAsync();
            } else {
                throw Error("Unable to get Xmarks db connection");
            }

            // also remove the item from our local map
            for (var i=0; i<itemlist.length; i++) {
                var itemId = itemlist[i];
                nid = BookmarkDatasource._mapNativeToNid[itemId];
                if (nid) {
                    delete BookmarkDatasource._mapNidToNative[nid];
                    delete BookmarkDatasource._mapNativeToNid[itemId];
                }
            }
        }
    },

    MapNid: function(nid) {
        return BookmarkDatasource._mapNidToNative[nid] || this.GetItemIdForGUID(nid);
    },

    MapNative: function(itemId, silent, bypassCache) {

        // Try the map first.
        var nid;
        if (!bypassCache) {
            nid = BookmarkDatasource._mapNativeToNid[itemId];
            if (nid)
                return nid;
        }

        // Try to get a reasonable length GUID.
        try {
            nid = this.GetItemGUID(itemId);
        } catch(e) {
            if (!silent) {
                Xmarks.LogWrite("MapNative failed with itemId = " + itemId);
                Xmarks.LogWrite("Original error is " + e.toSource());
                Xmarks.LogWrite("Caller is " + this.MapNative.caller);
            }
            throw e;
        }
        if (nid.length < BookmarkDatasource.MAX_NID_LENGTH)
            return nid;

        // No? Make our own.
        nid = this.GenerateNid();
        this.SetItemGUID(itemId, nid);
        return nid;
    },

    AddToMap: function(itemId, nid) {
        BookmarkDatasource._mapNidToNative[nid] = itemId;
        BookmarkDatasource._mapNativeToNid[itemId] = nid;
        return nid;
    },

    GenerateNid: function() {
        return BookmarkDatasource.sessionId + "-" +
            (BookmarkDatasource.nidIndex++).toString(36);
    },


    //
    // LocationMaps
    //

    /* For the special folders (toolbar and unfiled), we maintain
       an annotation to persist those folders' location in the nodeset.
       The location is represented as a [pnid, bnid] combination.
       The annotation itself is just the toSource() representation of the
       LocationMap dict, which is keyed off the itemId.
     */

    _InitLocationMap: function() {
        try {
            var mapstr =
                Call(this.asvc, this.asvc.getItemAnnotation,
                        this.bmsvc.bookmarksMenuFolder,
                        BookmarkDatasource.LOCATION_MAP_ANNO_NAME);
            BookmarkDatasource._locationMap = JSON.parse(mapstr);
        } catch(e) {
            Xmarks.LogError("loading location map", e);
            BookmarkDatasource._locationMap = {};
            BookmarkDatasource._locationMap[this.bmsvc.toolbarFolder] = 
                [null, null];
            BookmarkDatasource._locationMap[this.bmsvc.unfiledBookmarksFolder] = 
                [null, null];
        }
    },

    _WriteLocationMap: function() {
        var lm = JSON.stringify(BookmarkDatasource._locationMap);
        Call(this.asvc, this.asvc.setItemAnnotation, 
            this.bmsvc.bookmarksMenuFolder,
            BookmarkDatasource.LOCATION_MAP_ANNO_NAME, lm, 0, 
            this.asvc.EXPIRES_NEVER);
    },

    _ModifyLocationMap: function(itemId, pnid, bnid) {
        var val = [pnid, bnid];
        if (!utils.equals(BookmarkDatasource._locationMap[itemId], val)) {
            Xmarks.LogWrite("Modifying locationmap for " + itemId + " from " +
                    BookmarkDatasource._locationMap[itemId].toSource() + " to " + 
                    val.toSource());
            BookmarkDatasource._locationMap[itemId] = val;
            this._WriteLocationMap();
        }
    },

    _ApplyLocationMap: function(ns, itemId) {
        // Move special node into the correct position
        var v = BookmarkDatasource._locationMap[itemId];
        if (!v)
            return;

        var nid = this.MapNative(itemId);
        var pnid = v[0];
        var bnid = v[1];

        if (!ns.Node(nid, false, true)) {
            return;
        }

        if (!pnid || !ns.Node(pnid, false, true)) {
            pnid = Xmarks.ns.NODE_ROOT;
            bnid = null;
        }

        if (bnid && (!ns.Node(pnid)["children"] ||
                ns.Node(pnid).children.indexOf(bnid) < 0)) {
            bnid = null;
        }

        ns.InsertInParent(nid, pnid, bnid);
    },

    //
    //
    //

    BaselineLoaded: function(baseline, callback) {
        // NYI
        callback(0);
        return;
    },

    NewURI: function(str) {
        var uri = null;
        try {
            uri = Cc["@mozilla.org/network/io-service;1"].
                getService(Ci.nsIIOService).
                newURI(str, "UTF-8", null);
        } catch(e) {}
        if (!uri) {
            Xmarks.LogWrite("Failed to produce uri for " + str);
        }
        return uri;
    },

    FixedURI: function(str) {
        var fixed = null;
        try {
            if (str != null && str.length > 0) {
                // createFixupURI doesn't like quotes around URLs, and will except
                str = str.replace(/^\"+/,"").replace(/\"+$/,"");

                // ok, now we can call the native function
                fixed = Call(this.fusvc, this.fusvc.createFixupURI, str, 0);
            } else {
                fixed = Call(this.fusvc, this.fusvc.createFixupURI, "about:blank", 0);
            }
        } catch (e) {
            fixed = Call(this.fusvc, this.fusvc.createFixupURI, "about:blank", 0);
        }
        return fixed;
    },

    NormalizeUrl: function(str) {
        return this.FixedURI(str).spec;
    },

    runBatched: function() {
        this._func.apply(this, this._args);
    },


    //
    // Functions for writing to the native store.
    //

    AcceptNodes: function(ns, callback) {
        if (collectTimingInfo)
            StartTimes("AcceptNodes");
        this._func = this._AcceptNodes;
        this._args = arguments;
        this.bmsvc.runInBatchMode(this, null);
        if (collectTimingInfo)
            ReportTimes();
    },

    _AcceptNodes: function(ns, callback) {
        /*

         Here's the strategy. Execute a query on the top-level of the
         bookmarks hierarchy. Push the result for that root onto the stack,
         along with the matching root of the nodeset.

         Pop the next pair off the stack. Compare direct properties, and make
         adjustments as necessary. If the nodes being compared are folders
         deal with their children as follows:

         (1) First, make sure that all of the children in the node exist
             on the Places side. This means creating entities that don't exist
             at all, and moving entities that exist in a different parent.
         (2) Delete any item that exists on the Places side but not at all
             on in the nodeset.
         (3) Iterate over the node's children, setting position indices in
             the Places children as appropriate.
         (4) Iterate over the node children again, pushing the appropriate
             pairs onto the stack.

         Dealing with toolbar: we're going to examine the tnid for the
         incoming nodeset and see if it's the same as the nid for the
         Places toolbarFolder. If it is different, we're
         going to change the nid on the toolbarFolder to match the new tnid.

         We'll also be looking at the location of the toolbar, and updating
         the location map if necessary to correspond to the toolbar folder's
         current location.

         Finally, we process the toolbar folder separately, dealing with it
         only as a root and not as a child (that is, if we see it come
         through as a child in the nodeset, we will ignore it).

         */

        var items = [];
        var fixupFolderQueries = [];
        var fixupTagQueries = []
        var self = this;
        var status = 0;

        var optimizeOK =  ns._cloneSource && ns._cloneSource.placesSource;

        var tnid = ns.Node(Xmarks.ns.NODE_ROOT).tnid;
        var unid = ns.Node(Xmarks.ns.NODE_ROOT).unid;

        var specialNids = [];

        if (!this.lmsvc) {
            Xmarks.LogWrite("Begin AcceptNodes async");

            var accept_gen = AcceptNodes_DoAsync(callback);
            var on_resolve = function(v) {
                // resolved a promise; send the result back to
                // the blocked routine.  it may send us back
                // a promise, so repeat...
                //
                // Also we need to runInBatchMode to start up a
                // new transaction or performance will suck.
                self.bmsvc.runInBatchMode({
                    runBatched: function() {
                        try {
                            var p = accept_gen.send(v);
                            p.then(on_resolve);
                        } catch (e) {
                            if (e != StopIteration) { throw e; }
                        }
                    }},
                    null);
            };

            // kick off the task...
            try {
                var p = accept_gen.next();
                p.then(on_resolve);
            } catch (e) {
                if (e != StopIteration) { throw e; }
            }

            return;
        }

        Xmarks.LogWrite("Begin AcceptNodes");
        AcceptNodes_DoSync(callback);
        return;

        function AcceptNodes_DoAsync(callback) {
            try {
                if (!self.initialized) {
                    Xmarks.LogWrite("Initialization failed, throw error 6");
                    throw 6;
                }

                AcceptNewRoot(self.bmsvc.toolbarFolder, tnid);
                AcceptNewRoot(self.bmsvc.unfiledBookmarksFolder, unid);

                self.PushRoot(self.bmsvc.bookmarksMenuFolder, items);
                self.PushRoot(self.bmsvc.toolbarFolder, items);
                self.PushRoot(self.bmsvc.unfiledBookmarksFolder, items);

                //Xmarks.LogWrite("Beginning accept nodes async...");
                for (i=0; i < items.length; i++) {
                    var item = items[i];

                    var place = item[0];
                    var itemId = place.itemId;
                    var nid = item[1];
                    var node = ns.Node(nid, false, true);

                    var args = { node: node, place: place, itemId: itemId,
                                 nid: nid };

                    //Xmarks.LogWrite("begin accept nid=" + nid + " itemId=" + itemId + " type=" + node.ntype + " name=" + node.name);

                    if (!node) {
                        // Node in question was deleted; sync children
                        // and be done.
                        var gen = SynchronizeChildrenAsync(args, true);
                        try {
                            gen.next();
                        }
                        catch (e) {
                            if (e != StopIteration) { throw e; }
                        }
                        continue;
                    }

                    if (node.ntype == 'query') {
                        if (MAP_NID_TO_NATIVE.test(node.url)) {
                            Xmarks.LogWrite("Found folder query to fix up: " + 
                                    node.url);
                            fixupFolderQueries.push(itemId);
                        }
                        if (MAP_TAG_TO_NATIVE.test(node.url)) {
                            Xmarks.LogWrite("Found tag query to fix up: " +
                                    node.url);
                            fixupTagQueries.push(itemId);
                        }
                    }

                    // some browsers may create a separator with no url
                    //   Xmarks doesn't like that
                    if (node.ntype != 'folder' && !("url" in node)) {
                        node.url = "";
                    } 

                    var uri = self.FixedURI(node.url);
                    args.uri = uri;
                    args.items = items;

                    if (!optimizeOK || ns._node[nid]) {
                        //Xmarks.LogWrite("begin synchronize nid=" + nid);
                        var gen = SynchronizeDirectPropertiesAsync(args);
                        try {
                            var p = gen.next();
                            // got a promise, yield it again outside the loop
                            // so that iteration stops.
                            var x = yield(p);

                            // now we've resumed, continue inside gen
                            gen.send(x);
                        } catch (e) {
                            if (e != StopIteration) { throw e; }
                        }

                        SynchronizeIconsAsync(args);
                        SynchronizeAnnotations(args);
                        SynchronizeTags(args);

                        // ditto all the above, block until promises are ready
                        // SynchronizeChildrenAsync may block multiple times
                        // (multiple children that are livemarks) so run in a loop.
                        var gen2 = SynchronizeChildrenAsync(args);
                        try {
                            var p = gen2.next();
                            while (true) {
                                // if we enter this loop, we got a promise.
                                var x = yield(p);
                                // gen2 may either exit (leaving the loop) or
                                // return another promise for us to yield...
                                p = gen2.send(x);
                            }
                        } catch (e) {
                            if (e != StopIteration) { throw e; }
                        }
                    }
                    AcceptNodes_DoAsync_continuation(args);

                }
                AcceptNodes_DoFixups();

                Xmarks.LogWrite("Completed AcceptNodes");
                callback(status);
            } catch(e) {
                Xmarks.LogError("Exception in AcceptNodes", e);
                status = typeof(e) == "number" ? e : 3;
            }
        }

        function AcceptNodes_DoAsync_continuation(args) {
            var node = args.node;
            var place = args.place;
            var nid = args.nid;
            var items = args.items;

            //Xmarks.LogWrite("in AcceptNodes_DoAsync_continuation() type=" + node.ntype + " itemId=" + place.itemId + " name=" + node.name);

            if (node.ntype == 'folder' &&
                    place instanceof Ci.nsINavHistoryContainerResultNode) {
                // HACK: in FF22+ we need to query the place again here, otherwise we don't get an updated childCount; once they fix this in FF we can remove the extra query
                place = GetPlaceForContainerId(place.itemId);

                place.containerOpen = true;
                //Xmarks.LogWrite(" push children: itemId=" + place.itemId + " childCount=" + place.childCount);
                for (var i = 0; i < place.childCount; ++i) {
                    var child = place.getChild(i);
                    items.push([child, self.MapNative(child.itemId), nid]);
                }
                place.containerOpen = false;
            }
        }

        function AcceptNodes_DoSync(callback) {
            try {
                if (!self.initialized) {
                    Xmarks.LogWrite("Initialization failed, throw error 6");
                    throw 6;
                }

                AcceptNewRoot(self.bmsvc.toolbarFolder, tnid);
                AcceptNewRoot(self.bmsvc.unfiledBookmarksFolder, unid);

                self.PushRoot(self.bmsvc.bookmarksMenuFolder, items);
                self.PushRoot(self.bmsvc.toolbarFolder, items);
                self.PushRoot(self.bmsvc.unfiledBookmarksFolder, items);

                Xmarks.LogWrite("Beginning accept nodes...");
                while (items.length) {
                    var item = items.shift();
                    var place = item[0];
                    var itemId = place.itemId;
                    var nid = item[1];
                    var node = ns.Node(nid, false, true);

                    var args = { node: node, place: place, itemId: itemId,
                                 nid: nid };

                    if (!node) {
                        // Node in question was deleted; sync children
                        // and be done.
                        SynchronizeChildren(args, true);
                        continue;
                    }

                    if (node.ntype == 'query') {
                        if (MAP_NID_TO_NATIVE.test(node.url)) {
                            Xmarks.LogWrite("Found folder query to fix up: " + 
                                    node.url);
                            fixupFolderQueries.push(itemId);
                        }
                        if (MAP_TAG_TO_NATIVE.test(node.url)) {
                            Xmarks.LogWrite("Found tag query to fix up: " +
                                    node.url);
                            fixupTagQueries.push(itemId);
                        }
                    }

                    // some browsers may create a separator with no url
                    //   Xmarks doesn't like that
                    if (node.ntype != 'folder' && !("url" in node)) {
                        node.url = "";
                    } 

                    var uri = self.FixedURI(node.url);
                    args.uri = uri;

                    if (!optimizeOK || ns._node[nid]) {
                        SynchronizeDirectProperties(args);
                        SynchronizeIcons(args);
                        SynchronizeAnnotations(args);
                        SynchronizeTags(args);
                        SynchronizeChildren(args, false);
                    }

                    if (node.ntype == 'folder' &&
                            place instanceof Ci.nsINavHistoryContainerResultNode) {
                        // did ff break sync API's in FF < 22?  re-query the place here so we can get a correct childCount
                        place = GetPlaceForContainerId(place.itemId);

                        if (place)  {
                            place.containerOpen = true;
                            for (var i = 0; i < place.childCount; ++i) {
                                var child = place.getChild(i);
                                items.push([child, self.MapNative(child.itemId), nid]);
                            }
                            place.containerOpen = false;
                        } else {
                            Xmarks.LogWrite("AcceptNodes could not re-query place for folder!");
                        }
                    }
                }

                AcceptNodes_DoFixups();
            } catch(e) {
                Xmarks.LogWrite("Exception in AcceptNodes: " + e);
                status = typeof(e) == "number" ? e : 3;
            }
            Xmarks.LogWrite("Completed AcceptNodes");
            callback(status);
        }

        function AcceptNodes_DoFixups() {
            Xmarks.LogWrite("Fixing up folder queries");
            fixupFolderQueries.forEach(function(itemId) {
                try {
                    var uri = Call(self.bmsvc, self.bmsvc.getBookmarkURI, 
                        itemId).spec;
                    var uri_orig = uri;
                    uri = uri.replace(MAP_NID_TO_NATIVE, function(x, y) {
                        return "folder=" + self.MapNid(y);
                    });
                    Xmarks.LogWrite("Changed URL from >" + uri_orig + "< to >" +
                        uri + "< itemId " + itemId);
                    Call(self.bmsvc, self.bmsvc.changeBookmarkURI, itemId, 
                        self.NewURI(uri));
                } catch(e) {
                    Xmarks.LogWrite(
                        "Warning: Couldn't map folder-nid to itemId " +
                        "for " + itemId + ". Error is " + e.toSource());
                }
            });

            Xmarks.LogWrite("Fixing up tag queries");
            if (fixupTagQueries.length) {
                // Build a hash that maps each tag to the itemId of its
                // tag folder. This is clearly expensive, but I'm not aware
                // of any other way to get at this information.
                var q = Call(self.hsvc, self.hsvc.getNewQuery);
                var o = Call(self.hsvc, self.hsvc.getNewQueryOptions);
                q.setFolders([self.bmsvc.tagsFolder], 1);
                var results = Call(self.hsvc, self.hsvc.executeQuery, q, o);
                var r = results.root;
                r.containerOpen = true;
                var tagMap = {}
                var childCount = r.childCount;
                for (var i = 0; i < childCount; ++i) {
                    var c = r.getChild(i);
                    tagMap[c.title] = c.itemId;
                }
                r.containerOpen = false;
            }


            fixupTagQueries.forEach(function(itemId) {
                try {
                    var uri = Call(self.bmsvc, self.bmsvc.getBookmarkURI,
                        itemId).spec;
                    var newUri = uri.replace(MAP_TAG_TO_NATIVE, function(x, y) {
                        var tagFolderId = tagMap[decodeURIComponent(y)];
                        if (!tagFolderId) {
                            Xmarks.LogWrite("Warning: couldn't map " + y);
                        }
                        return "folder=" + String(tagFolderId);
                    });
                    Xmarks.LogWrite("Mapped incoming uri from " + uri + " to " +
                            newUri);
                    Call(self.bmsvc, self.bmsvc.changeBookmarkURI, itemId,
                        self.NewURI(newUri));
                } catch (e) {
                    Xmarks.LogWrite("Warning: Couldn't map tagname for item " +
                        itemId + ". Error is " + e.toSource());
                }
            });
        }

        function AcceptNewRoot(itemId, nid) {
            var nidValid = nid && ns.Node(nid, false, true) != null;
            if (!nidValid || self.MapNative(itemId) != nid) {
                optimizeOK = false;     // Can't optimize write if root changes.

                var oldId = self.GetItemIdForGUID(nid);
                if (oldId >= 0) {
                    // If the folder that is the new root exists as an
                    // ordinary folder in places, make the old folder itself go
                    // away by giving it a new nid. (It will get deleted after 
                    // its children get moved into the new place.)
                    self.SetItemGUID(oldId, self.GenerateNid());
                }
                self.SetItemGUID(itemId, nidValid ? nid : self.GenerateNid());
            }

            if (nidValid) {
                self._ModifyLocationMap(itemId, ns.Node(nid).pnid,
                    NextSibling(nid));
            } else {
                self._ModifyLocationMap(itemId, null, null);
            }
            specialNids.push(nid);
        }

        function NextSibling(nid) {
            var siblings = ns.Node(ns.Node(nid).pnid).children;
            var index = siblings.indexOf(nid) + 1;
            while (specialNids.indexOf(siblings[index]) >= 0 &&
                    index < siblings.length) {
                index++;
            }
            return siblings[index];
        }

        /*
         * CreateNode returns either an itemId or a promise for an itemId.
         * If it's a promise, caller should yield it to the outermost scope, in
         * order to block execution until the promise is resolved.
         */
        function CreateNode(parentId, uri, node) {
            var itemId = null;

            //Xmarks.LogWrite("in CreateNode() parentId=" + parentId + " node.ntype=" + node.ntype);

            switch (node.ntype) {
            case "bookmark":
            case "microsummary":
            case "query":
                itemId = Call(self.bmsvc, self.bmsvc.insertBookmark, 
                    parentId, uri, -1, node.name || "");
                Xmarks.LogWrite("Bookmark created.");
                break;
            case "folder":
                itemId = Call(self.bmsvc, self.bmsvc.createFolder,
                    parentId, node.name || "", -1);
                Xmarks.LogWrite("Folder created.");
                break;
            case 'separator':
                itemId = Call(self.bmsvc, self.bmsvc.insertSeparator,
                    parentId, -1);
                Xmarks.LogWrite("Separator created");
                break;
            case 'feed':
                if (self.lmsvc) {
                    itemId = Call(self.lmsvc, self.lmsvc.createLivemark, 
                        parentId, node.name || "",
                        self.FixedURI(node.url),
                        self.FixedURI(node.feedurl), -1);
                } else if (self.mialm) {

                    var lmi = {
                        title: node.name,
                        parentId: parentId,
                        index: -1,
                        siteURI: self.FixedURI(node.url),
                        feedURI: self.FixedURI(node.feedurl)
                    };
                    var p = new XmPromise();
                    if (self.UseLMPromises) {
                        // convert moz promises to xmarks promises
                        var promise = self.mialm.addLivemark(lmi);
                        promise.then(function (x) { p.resolve(x.id); }, function (x) { p.resolve(null); });
                    } else {
                        self.mialm.addLivemark(lmi, {
                            onCompletion: function(aStatus, aLivemark) {
                                if (Components.isSuccessCode(aStatus)) {
                                    Xmarks.LogWrite("Feed created");
                                    p.resolve(aLivemark.id);
                                } else {
                                    Xmarks.LogWrite("Feed NOT created");
                                    p.resolve(null);
                                }
                            }
                        });
                    }
                    return p;
                }
                break;
            default:
                throw Error("Type mismatch for " + ns.NodeName(nid) +
                    "place.type = " + place.type + " node.ntype = " +
                    node.ntype);
            }
            return itemId;
        }

        /*
         * SynchronizeDirectPropertiesAsync is a generator -- it may block
         * waiting for newly created items to be completed and will yield
         * a promise in that case.  Caller should send() the value when ready.
         */
        function SynchronizeDirectPropertiesAsync(args) {
            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            //Xmarks.LogWrite("in SynchronizeDirectPropertiesAsync()");

            if (BookmarkDatasource.MAP_NTYPE_TO_PLACE_TYPE[args.node.ntype].
                    indexOf(place.type) < 0) {
                // Whoops! The type within places doesn't match our
                // ntype. Rather than throwing an error, resolve the
                // situation by removing the offending places item
                // and creating a new one that matches the specs of
                // the ntype as best it can.
                Xmarks.LogWrite("Dealing with type mismatch: ntype is " +
                        node.ntype + " place.type = " + place.type);
                var parentId = self.MapNid(node.pnid);
                if (parentId < 0) {
                    Xmarks.LogWrite("Parent " + node.pnid + " of " + node.nid + " is missing.");
                    return;
                }
                Xmarks.LogWrite("Nid is " + node.nid + " pnid is " + node.pnid);
                self.RemoveItem(itemId);

                var id = CreateNode(parentId, uri, node);

                    // block here if promise needs resolving.  caller will
                    // send() the value to us.
                    if (id instanceof XmPromise)
                        id = yield(id);

                    if (id) {
                        //Xmarks.LogWrite(" created itemId=" + id);

                        args.itemId = id;
                        args.place = GetPlaceForId(parentId, id);
                        if (args.place == null) {
                            throw Error("Didn't find item just created, nid=" +
                                   node.nid);
                        }

                        // Update the map.
                        self.AddToMap(id, node.nid);
                    }
            }
            SynchronizeDirectPropertiesAsync_continuation(args);
        }

        function GetPlaceForContainerId(id) {
            var o = Call(self.hsvc, self.hsvc.getNewQueryOptions);
            var q = Call(self.hsvc, self.hsvc.getNewQuery);
            q.setFolders([id], 1);
            var r = Call(self.hsvc, self.hsvc.executeQuery, q, o);
            if (r)
                return r.root;

            return null;
        }

        function GetPlaceForId(parentId, id) {
            // Now, get a place object for the item id
            // The available API's make this pretty difficult.
            var rootNode = GetPlaceForContainerId(parentId);
            var place, retval = null;
            var needclose = false;
            if (!rootNode.containerOpen) {
                rootNode.containerOpen = true;
                needclose = true;
            }
            for (var i = 0; i < rootNode.childCount; ++i) {
                place = rootNode.getChild(i);
                if (place.itemId == id)
                    retval = place;
            }
            if (needclose)
                rootNode.containerOpen = false;
            return retval;
        }

        function SynchronizeDirectPropertiesAsync_continuation(args) {
            //Xmarks.LogWrite("in SynchronizeDirectPropertiesAsync() continuation");

            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            if (node.ntype == 'bookmark' || node.ntype == 'query' ||
                    node.ntype == 'microsummary') {
                if (place.uri != node.url) {
                    // Firefox doesn't like urls with quotes
                    node.url = node.url.replace(/^\"+/,"").replace(/\"+$/,"");

                    Xmarks.LogWrite("Changed URL from [" +
                        place.uri + "] to [" +
                        node.url + "] itemId " + itemId);
                    Call(self.bmsvc, self.bmsvc.changeBookmarkURI, itemId, uri);
                    // Conversion to URI may alter exact text, so
                    // modify it in incoming node if it changed.
                    if (uri.spec != node.url) {
                        ns.Node(nid, true).url = uri.spec;
                    }
                }
            } else if (node.ntype == 'feed') {
                Call(self.asvc, self.asvc.setItemAnnotation, itemId, 
                    "livemark/siteURI", node.url || "", 0, 
                    self.asvc.EXPIRE_NEVER);
            } else if (node.ntype == 'separator') {
                if (node.name) {
                    delete node["name"];
                }
            }

            if (place.title != node.name) {
                Call(self.bmsvc, self.bmsvc.setItemTitle, itemId, 
                    node.name || "");
            }

            if (DatePlacesToNode(place.dateAdded) != (node.created || 0)) {
                Call(self.bmsvc, self.bmsvc.setItemDateAdded, itemId, 
                    DateNodeToPlaces(node.created));
            }

            if (DatePlacesToNode(place.lastModified) != (node.modified || 0)) {
                Call(self.bmsvc, self.bmsvc.setItemLastModified, itemId, 
                    DateNodeToPlaces(node.modified));
            }

            try {
                if (Call(self.bmsvc, self.bmsvc.getKeywordForBookmark, itemId) !=
                        node.shortcuturl) {
                    Call(self.bmsvc, self.bmsvc.setKeywordForBookmark, itemId, 
                        node.shortcuturl);
                }
            } catch(e) {
                Xmarks.LogWrite("Warning: getKeywordForBookmark exception, itemId=" + itemId);
            }

            delete ns.Node(nid, true)['hash'];
            Object.keys(node).forEach(function(k) {
                if (!BookmarkDatasource.KNOWN_ATTRS[k] && 
                        typeof node[k] != "function") {
                    Xmarks.LogWrite("Warning: deleting unknown attr " + k);
                    delete ns.Node(nid, true)[k];
                }
            });
        }

        function SynchronizeDirectProperties(args) {
            //Xmarks.LogWrite("in SynchronizeDirectProperties()");
            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            if (BookmarkDatasource.MAP_NTYPE_TO_PLACE_TYPE[node.ntype].
                    indexOf(place.type) < 0) {
                // Whoops! The type within places doesn't match our
                // ntype. Rather than throwing an error, resolve the
                // situation by removing the offending places item
                // and creating a new one that matches the specs of
                // the ntype as best it can.
                Xmarks.LogWrite("Dealing with type mismatch: ntype is " +
                        node.ntype + " place.type = " + place.type);
                var parentId = self.MapNid(node.pnid);
                if (parentId < 0) {
                    Xmarks.LogWrite("Parent " + node.pnid + " of " + node.nid + " is missing.");
                    return;
                }
                Xmarks.LogWrite("Nid is " + node.nid + " pnid is " + node.pnid);
                self.RemoveItem(itemId);

                var itemId = CreateNode(parentId, uri, node);
                if (itemId instanceof XmPromise) {
                    // this is sync code, shouldn't happen.
                    Xmarks.LogWrite("ERROR: synchronous Livemark service is not available");
                    itemId = null;
                }

                if (itemId)
                {
                    // Now, get a place object for the item we just created.
                    // The available API's make this pretty difficult.
                    var o = Call(self.hsvc, self.hsvc.getNewQueryOptions);
                    var q = Call(self.hsvc, self.hsvc.getNewQuery);
                    q.setFolders([parentId], 1)
                    var r = Call(self.hsvc, self.hsvc.executeQuery, q, o);
                    var rootNode = r.root;
                    rootNode.containerOpen = true;
                    for (var i = 0; i < rootNode.childCount; ++i) {
                        place = rootNode.getChild(i);
                        if (place.itemId == itemId)
                            break;
                    }
                    if (i >= rootNode.childCount) {
                        throw Error("Didn't find item just created, nid=" +
                               node.nid);
                    }

                    rootNode.containerOpen = false;

                    // Update the map.
                    self.AddToMap(itemId, node.nid);
                }
                
                // And fall through...
            }

            if (node.ntype == 'bookmark' || node.ntype == 'query' ||
                    node.ntype == 'microsummary') {
                if (place.uri != node.url) {
                    // Firefox doesn't like urls with quotes
                    node.url = node.url.replace(/^\"+/,"").replace(/\"+$/,"");

                    Xmarks.LogWrite("Changed URL from [" +
                        place.uri + "] to [" +
                        node.url + "] itemId " + itemId);
                    Call(self.bmsvc, self.bmsvc.changeBookmarkURI, itemId, uri);
                    // Conversion to URI may alter exact text, so
                    // modify it in incoming node if it changed.
                    if (uri.spec != node.url) {
                        ns.Node(nid, true).url = uri.spec;
                    }
                }
            } else if (node.ntype == 'feed') {
                Call(self.asvc, self.asvc.setItemAnnotation, itemId, 
                    "livemark/siteURI", node.url || "", 0, 
                    self.asvc.EXPIRE_NEVER);
            } else if (node.ntype == 'separator') {
                if (node.name) {
                    delete node["name"];
                }
            }

            if (place.title != node.name) {
                Call(self.bmsvc, self.bmsvc.setItemTitle, itemId, 
                    node.name || "");
            }

            if (DatePlacesToNode(place.dateAdded) != (node.created || 0)) {
                Call(self.bmsvc, self.bmsvc.setItemDateAdded, itemId, 
                    DateNodeToPlaces(node.created));
            }

            if (DatePlacesToNode(place.lastModified) != (node.modified || 0)) {
                Call(self.bmsvc, self.bmsvc.setItemLastModified, itemId, 
                    DateNodeToPlaces(node.modified));
            }

            try {
                if (Call(self.bmsvc, self.bmsvc.getKeywordForBookmark, itemId) !=
                        node.shortcuturl) {
                    Call(self.bmsvc, self.bmsvc.setKeywordForBookmark, itemId, 
                        node.shortcuturl);
                }
            } catch(e) {
                Xmarks.LogWrite("Warning: getKeywordForBookmark exception, itemId=" + itemId);
            }

            delete ns.Node(nid, true)['hash'];
            Object.keys(node).forEach(function(k) {
                if (!BookmarkDatasource.KNOWN_ATTRS[k] && 
                        typeof node[k] != "function") {
                    Xmarks.LogWrite("Warning: deleting unknown attr " + k);
                    delete ns.Node(nid, true)[k];
                }
            });
        }

        function SynchronizeIconsAsync(args) {
            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            //Xmarks.LogWrite("in SynchronizeIconsAsync() itemId=" + itemId);

            if (node.url && uri && node.ntype == 'bookmark' || 
                    node.ntype == 'microsummary') {
                var parsedIcon = node.icon ? 
                    ParseIconString(node.icon) : null;
                if (parsedIcon) {
                    //Xmarks.LogWrite(" got parsed icon");
                    // To store favicon data:
                    // (1) Compare it against what we've already got.
                    //     If it's unchanged, skip it.
                    // (2) Generate a new uri.
                    // (3) Store the data for that uri.
                    // (4) Set the favicon uri for the node url.

                    var iconUri = null;
                    var mimeType = {};
                    var iconData = null;

                    self.GetIconURLAsync(uri, function(iconUri) {
                        self.GetIconDataAsync(uri, function(iconData) {
                            if (!iconUri || mimeType != parsedIcon[0] ||
                                iconData != parsedIcon[1]) {

                                var newIconUri = 
                                    self.NewURI("http://icon.xmarks.com/" +
                                        self.GenerateNid());

                                if (self.SetIconData(newIconUri,
                                        parsedIcon[1], parsedIcon[0])) {
                                    self.SetIconURLForPage(uri, newIconUri, null);
                                }
                            }
                        });
                    });
                } else {
                    // Clear icon if it exists.
                    self.GetIconURLAsync(uri, function(iconUri) {
                        if (iconUri)
                            self.SetIconData(iconUri, null, null);

                        // Clear incoming icon if it existed and was invalid.
                        if (node.icon) {
                            ns.Node(nid, true).icon = null;
                        }
                    });
                }
            } 
        }

        function SynchronizeIcons(args) {
            //Xmarks.LogWrite("in SynchronizeIcons()");

            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            if (node.url && uri && node.ntype == 'bookmark' || 
                    node.ntype == 'microsummary') {
                var parsedIcon = node.icon ? 
                    ParseIconString(node.icon) : null;
                if (parsedIcon) {
                    // To store favicon data:
                    // (1) Compare it against what we've already got.
                    //     If it's unchanged, skip it.
                    // (2) Generate a new uri.
                    // (3) Store the data for that uri.
                    // (4) Set the favicon uri for the node url.

                    var iconUri = null;
                    var mimeType = {};
                    var iconData = null;
                    try {
                        if (uri != null && self.fisvc.getFaviconForPage) {
                            iconUri = Call(self.fisvc, self.fisvc.getFaviconForPage, uri);
                        }
                    } catch(e) {}
                    if (iconUri) {
                        try {
                            iconData = Call(self.fisvc, self.fisvc.getFaviconData, iconUri, mimeType, {});
                        } catch(e) {}
                    }

                    if (!iconUri || mimeType != parsedIcon[0] || iconData != 
                            parsedIcon[1]) {
                        var newIconUri = 
                            self.NewURI("http://icon.xmarks.com/" +
                                self.GenerateNid());
                        // don't fail if firefox can't set the favicon data
                        try {
                            Call(self.fisvc, self.fisvc.setFaviconData, newIconUri, 
                                parsedIcon[1], parsedIcon[1].length, parsedIcon[0],
                                Number.MAX_VALUE);
                            Call(self.fisvc, self.fisvc.setFaviconUrlForPage, uri, 
                                newIconUri);
                        } catch(e){
                            // intentionally blank
                        }
                    }
                } else {
                    // Clear icon if it exists.
                    var iconUri = null;
                    try {
                        if (uri != null && self.fisvc.getFaviconForPage) {
                            iconUri = Call(self.fisvc, self.fisvc.getFaviconForPage, uri);
                        }
                    } catch (e) {}
                    if (iconUri) {
                        // don't fail if firefox can't set the favicon data
                        try {
                            Call(self.fisvc, self.fisvc.setFaviconData, iconUri, 
                                null, 0, null, 0);
                        } catch(e){
                            // intentionally blank
                        }
                    }
                    // Clear incoming icon if it existed and was invalid.
                    if (node.icon) {
                        ns.Node(nid, true).icon = null;
                    }
                }
            }
        }

        function SynchronizeAnnotations(args) {
            //Xmarks.LogWrite("in SynchronizeAnnotations()");

            // Annotation stragegy:
            // (1) Get a list of all annotations for this place.
            // (2) Filter that list down to the annos we're interested in.
            // (3) Build a list of annotation-stored attributes set in the node.
            // (4) Sync the two lists: process changes, adds, deletes.

            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            var placeAnnos = Call(self.asvc, self.asvc.getItemAnnotationNames, 
                itemId, {});
            placeAnnos = placeAnnos.filter(function(x) { 
                return (x in BookmarkDatasource.MAP_ANNO_TO_NODE);
            });

            var nodeAnnos = [];
            Object.keys(BookmarkDatasource.MAP_NODE_TO_ANNO).forEach(function(x) {
                if (node[x]) {
                    nodeAnnos.push(x);
                }
            });

            // Exceptional case: if it's a feed, the url maps to
            // the livemark/siteURI annotation.
            if (node.ntype == 'feed' && node.url) {
                nodeAnnos.push('url');
            }

            nodeAnnos.forEach(function(attr) {
                try {
                    var anno = BookmarkDatasource.MAP_NODE_TO_ANNO[attr];
                    if (node.ntype == 'feed' && attr == 'url')
                        anno = "livemark/siteURI";  // Exception
                    if (placeAnnos.indexOf(anno) >= 0) {
                        placeAnnos.splice(placeAnnos.indexOf(anno), 1);
                        var value = Call(self.asvc,
                            self.asvc.getItemAnnotation, itemId, anno);
                        if (value == node[attr]) {
                            return;
                        }
                    }
                    Call(self.asvc, self.asvc.setItemAnnotation, itemId, anno, 
                        node[attr], 0, self.asvc.EXPIRE_NEVER);
                } catch (e) {
                    Xmarks.LogWrite("Warning: failed setting annos: " + e);
                    return;
                }
            });

            placeAnnos.forEach(function(anno) {
                Call(self.asvc, self.asvc.removeItemAnnotation, itemId, anno);
            });
        }

        function SynchronizeTags(args) {
            //Xmarks.LogWrite("in SynchronizeTags()");

            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            // Sync tags
            var tags = uri ? 
                    Call(self.tsvc, self.tsvc.getTagsForURI, uri, {}).slice() :
                    [];
            var ntags = node.tags || [];
            if (!utils.equals(tags, ntags)) {
                // Delete extraneous tags
                var extra = tags.filter(function(x) { 
                        return x && x.length && ntags.indexOf(x) < 0; } );
                if (extra.length) {
                    Call(self.tsvc, self.tsvc.untagURI, uri, extra);
                }

                // Add missing tags
                var missing = ntags.filter(function(x) {
                        return x.length && tags.indexOf(x) < 0; } );
                if (missing.length) {
                    Call(self.tsvc, self.tsvc.tagURI, uri, missing);
                }
            }
        }

        /*
         * SynchronizeChildrenAsync is a generator -- it may block waiting for
         * new node creation.  Caller should send the new node itemId when ready.
         */
        function SynchronizeChildrenAsync(args, isDeleted) {
            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;

            //Xmarks.LogWrite("in SynchronizeChildrenAsync() itemId=" + itemId + " name=" + node.name);

            if (isDeleted) {
                node = new Xmarks.ns.Node(nid, { ntype: "folder" } );
            }

            if (!(node.ntype == 'folder' &&
                    place instanceof Ci.nsINavHistoryContainerResultNode)) {
                return;
            }

            // Deal with children.
            place.containerOpen = true;

            var children = [];
            for (var i = 0; i < place.childCount; ++i) {
                var child = place.getChild(i);
                children.push(self.MapNative(child.itemId));
            }
            place.containerOpen = false;

            if (!node.children) {
                node.children = [];
            }

            // Filter "special" children.
            var nodeChildren = node.children.filter(function(x) {
                return x != tnid && x != unid;
            } );

            // Do inserts and moves.
            for (var i=0; i < nodeChildren.length; i++) {
                var child = nodeChildren[i];

                    if (children.indexOf(child) >= 0)
                        continue;

                    if (self.GetItemIdForGUID(child, true) >= 0) {
                        Xmarks.LogWrite("Moving item " + ns.NodeName(child) + " to " + ns.NodeName(self.MapNative(itemId)));
                        Call(self.bmsvc, self.bmsvc.moveItem, self.MapNid(child),
                             itemId, -1);
                        continue;
                    }
                    var cnode = ns.Node(child);
                    Xmarks.LogWrite("Creating " + cnode.ntype + " " + ns.NodeName(child) + " ...");
                    var uri = self.FixedURI(cnode.url);

                    var newItemId = CreateNode(itemId, uri, cnode);

                    // block here if promise needs resolving.  caller will
                    // send() the value to us.
                    if (newItemId instanceof XmPromise)
                        newItemId = yield(newItemId);

                    //Xmarks.LogWrite(" created itemId=" + newItemId + " place.childCount=" + place.childCount);
                    if (newItemId) {
                        self.SetItemGUID(newItemId, child);
                    }
            }

            do_deletes(place.itemId);

            // Do reorders.
            place = GetPlaceForContainerId(place.itemId);
            place.containerOpen = true;
            var extraIndex = nodeChildren.length;
            var reorders = [];
            for (var i = 0; i < place.childCount; ++i) {
                var childItemId = place.getChild(i).itemId;
                var index = nodeChildren.indexOf(self.MapNative(childItemId));
                if (index < 0) {
                    index = extraIndex++;
                }
                if (Call(self.bmsvc, self.bmsvc.getItemIndex, childItemId) != 
                        index) {
                    reorders.push([childItemId, index]);
                }
            }

            reorders.sort(function(a, b) { return a[1] - b[1]; });

            reorders.forEach(function(r) {
                Xmarks.LogWrite("Setting index for " + 
                    ns.NodeName(self.MapNative(r[0])) + " to " + r[1]);
                Call(self.bmsvc, self.bmsvc.setItemIndex, r[0], r[1]);
            } );

            //Xmarks.LogWrite(" itemId=" + itemId + " childCount=" + place.childCount);
                
            place.containerOpen = false;
        }

        function do_deletes(parentId)
        {
            // Do deletes.
            var items_to_delete = [];
            var item_indexes = [];

            place = GetPlaceForContainerId(parentId);
            place.containerOpen = true;
            for (var i = 0; i < place.childCount; ++i) {
                var childItemId = Call(place, place.getChild, i).itemId;

                // if we still have this node, don't remove it
                if (ns.Node(self.MapNative(childItemId), false, true)) {
                    continue;
                }
                items_to_delete.push(childItemId);
                item_indexes.push(i);
            }
            place.containerOpen = false;

            // we delete back to front so indexes don't change in FF 3 case.
            var delete_len = items_to_delete.length;
            for (var i = 0; i < delete_len; i++) {
                var index = item_indexes.pop();
                var childItemId = items_to_delete.pop();

                try {
                    Xmarks.LogWrite("Removing " + childItemId + " : " + 
                            ns.NodeName(self.MapNative(childItemId)));

                    if (self.bmsvc.removeChildAt) { // Fx3
                        Call(self.bmsvc, self.bmsvc.removeChildAt, parentId, index);
                    } else {    // Fx4
                        self.RemoveItem(childItemId);
                    }
                } catch(e) {
                    Xmarks.LogWrite("Warning: failed trying to remove " +
                        self.MapNative(childItemId));
                    Xmarks.LogWrite("Error was " + e.toSource());
                }
            }
        }

        function SynchronizeChildren(args, isDeleted) {
            var node = args.node;
            var place = args.place;
            var itemId = args.itemId;
            var nid = args.nid;
            var uri = args.uri;

            //Xmarks.LogWrite("in SynchronizeChildren() name=" + node.name);

            if (isDeleted) {
                node = new Xmarks.ns.Node(nid, { ntype: "folder" } );
            }

            if (!(node.ntype == 'folder' &&
                    place instanceof Ci.nsINavHistoryContainerResultNode))
                return;

            // Deal with children.
            place = GetPlaceForContainerId(place.itemId);
            place.containerOpen = true;

            var children = [];
            for (var i = 0; i < place.childCount; ++i) {
                var child = place.getChild(i);
                children.push(self.MapNative(child.itemId));
            }
            place.containerOpen = false;

            if (!node.children) {
                node.children = [];
            }

            // Filter "special" children.
            var nodeChildren = node.children.filter(function(x) {
                return x != tnid && x != unid;
            } );

            // Do inserts and moves.
            nodeChildren.forEach(function(child) {
                if (children.indexOf(child) >= 0) {
                    return;
                }
                if (self.GetItemIdForGUID(child, true) >= 0) {
                    Xmarks.LogWrite("Moving item " + ns.NodeName(child) + " to " + ns.NodeName(self.MapNative(itemId)));
                    Call(self.bmsvc, self.bmsvc.moveItem, self.MapNid(child),
                         itemId, -1);
                    return;
                }
                var cnode = ns.Node(child);
                Xmarks.LogWrite("Creating " + cnode.ntype + " " + ns.NodeName(child) + " ...");
                var uri = self.FixedURI(cnode.url);
                var newItemId = CreateNode(itemId, uri, cnode);

                if (newItemId instanceof XmPromise) {
                    // sync code...
                    Xmarks.LogWrite("ERROR: synchronous Livemark service is not available");
                    newItemId = null;
                }

                if (newItemId) {
                    self.SetItemGUID(newItemId, child);
                }
            });

            do_deletes(place.itemId);

            // Do reorders.
            place = GetPlaceForContainerId(place.itemId);
            place.containerOpen = true;
            var extraIndex = nodeChildren.length;
            var reorders = [];
            for (var i = 0; i < place.childCount; ++i) {
                var childItemId = place.getChild(i).itemId;
                var index = nodeChildren.indexOf(self.MapNative(childItemId));
                if (index < 0) {
                    index = extraIndex++;
                }
                if (Call(self.bmsvc, self.bmsvc.getItemIndex, childItemId) != 
                        index) {
                    reorders.push([childItemId, index]);
                }
            }
            place.containerOpen = false;

            reorders.sort(function(a, b) { return a[1] - b[1]; });

            reorders.forEach(function(r) {
                Xmarks.LogWrite("Setting index for " + 
                    ns.NodeName(self.MapNative(r[0])) + " to " + r[1]);
                Call(self.bmsvc, self.bmsvc.setItemIndex, r[0], r[1]);
            } );
                
            //Xmarks.LogWrite("in SynchronizeChildren() done, place.childCount=" + place.childCount);
        }
    },

    //
    // Functions for reading from the native store.
    //

    _OnTree: function() {
        var self = ot.self;
        var items = ot.items;
        var result;
        var s = Date.now();
        while (items.length > 0 && Date.now() - s < 100) {
            var next = items.shift();
            var item = next[0];
            var pnid = next[2];
            var children = null;

            if (self.IsContainer(item)) {
                children = self.PushChildren(item, items, ot.depthFirst);
            }

            try {
                result = ot.action.apply(ot.Caller, [item, pnid, children]);
            } catch (e) {
                Xmarks.LogWrite("OnTree error: " + e + " source: " + e.toSource());
                result = typeof(e) == "number" ? e : 3;
            }

            if (result)
                break;
        }

        try {
            if (items.length > 0 && !result) {
                ot.timer.initWithCallback(ot, 10, Ci.nsITimer.TYPE_ONE_SHOT);
            } else {
                ot.complete.apply(ot.Caller, [result]);
            }
        } catch (e) {
            Xmarks.LogWrite("OnTree error: " + e + " source: " + e.toSource());
            result = typeof(e) == "number" ? e : 3;
            ot.complete.apply(ot.Caller, [result]);
        }
    },

    IterateArrayAsync: function(array, func, complete, result) {
        var self = this;
        if (array.length > 0) {
            //Xmarks.LogWrite("in IterateArrayAsync() length=" + array.length);
            func(array.shift(), function(result) {
               //Xmarks.LogWrite("in IterateArrayAsync() item done");
               self.IterateArrayAsync(array, func, complete, result);
            });
        } else {
            //Xmarks.LogWrite("in IterateArrayAsync() calling complete()");
            ot.complete.apply(ot.Caller, [result]);
        }
    },

    GetIconURLAsync: function(uri, callback) {
        var self = this;

        if (uri != null && self.afisvc) {
            var exception = false;

            try {
                self.afisvc.getFaviconURLForPage(uri, {
                    onComplete: function(aURI, aDataLen, aData, aMimeType) {
                        //Xmarks.LogWrite("in GetIconURLAsync::onComplete");
                        callback(aURI);
                    }
                });
            } catch(e) {
                Xmarks.LogWrite(" exception in getFaviconURLForPage(): " + e);
                exception = true;
            }

            if (exception)
                callback();
        } else {
            callback();
        }
    },

    GetIconDataAsync: function(uri, callback) {
        var self = this;

        if (uri != null && self.afisvc) {
            var exception = false;

            try {
                self.afisvc.getFaviconDataForPage(uri, {
                    onComplete: function(aURI, aDataLen, aData, aMimeType) {

                        if (aData && aDataLen > 0) {
                            //Xmarks.LogWrite("in GetIconDataAsync::onComplete got data type=" + aMimeType + " length=" + aDataLen + " bytes");
                            var encoded = "data:" + aMimeType + ";base64," + b64.encode(aData, true);
                            callback(encoded);
                        } else {
                            callback();
                        }
                    }
                });
            } catch(e) {
                Xmarks.LogWrite(" exception in getFaviconDataForPage(): " + e);
                exception = true;
            }

            if (exception)
                callback();
        } else {
            callback();
        }
    },

    SetIconData: function(iconUri, iconData, mimeType) {
        var self = this;
        var retval = true;

        //Xmarks.LogWrite("in SetIconData() iconUrir=" + iconUri + " mimeType=" + mimeType + " iconData.length=" + (iconData ? iconData.length : 0) + " iconData=" + iconData);

        try {
            self.afisvc.replaceFaviconData(iconUri, iconData,
                            iconData ? iconData.length : 0, mimeType);
        } catch(e) {
            retval = false;
        }
        return retval;
    },

    SetIconURLForPage: function(uri, iconUri, callback) {
        var self = this;
        try {
            self.afisvc.setAndFetchFaviconForPage(uri, iconUri, false, Ci.nsIFaviconService.FAVICON_LOAD_NON_PRIVATE, callback);
        } catch(e) {
            // do nothing
            Xmarks.LogError("Error setting favicon", e);
        }
    },

    IsLivemark: function(id) {
        return (this.lmsvc && Call(this.lmsvc, this.lmsvc.isLivemark, id));
    },

    IsLivemarkAsync: function(id, callback) {
        var self = this;

        if (self.lmsvc) {
           callback(self.IsLivemark(id));
        } else if (self.mialm) {
            var error = false;

            try {
                var lmi = {
                    id: id
                };

                //Xmarks.LogWrite("in IsLivemarkAsync()  before getLivemark id=" + id);
                if (self.UseLMPromises) {
                    var promise = self.mialm.getLivemark(lmi);
                    promise.then(function(x) { callback(true); }, function(x) { callback(false); });
                } else {
                    self.mialm.getLivemark(lmi, {
                        onCompletion: function(aStatus, aLivemark) {
                            callback(Components.isSuccessCode(aStatus));
                        }
                    });
                }
            } catch (e) {
                error = true;
                //Xmarks.LogWrite("in IsLivemarkAsync() exception " + e);
            }

            if (error) {
                callback(false);
            }
        } else {
           Xmarks.LogWrite("in IsLivemarkAsync() fallthrough!  DANGER! DANGER!"); 
        }
    },

    IsFeedAsync: function(node, place, callback) {
        var self = this;
        //Xmarks.LogWrite("in IsFeedAsync() " + node.ntype);

        if (node.ntype != 'folder') {
            callback(false);
        } else {
            //Xmarks.LogWrite("in IsFeedAsync() calling IsLivemarkAsync for itemId=" + place.itemId);
            self.IsLivemarkAsync(place.itemId, callback);
        }
    },

    _OnTreeAsync: function() {
        var self = ot.self;
        var items = ot.items;
        var result;
        var s = Date.now();
        var iterationcomplete = ot.complete;

        //Xmarks.LogWrite("in _OnTreeAsync()");

        self.IterateArrayAsync(items, function(arrayitem, itemdonecallback)  {
            var item = arrayitem[0];
            var pnid = arrayitem[2];
            var children = null;

            //Xmarks.LogWrite("in _OnTreeAsync() got array item id=" + item.itemId);

            self.IsContainerAsync(item, function(iscontainer) {
                //Xmarks.LogWrite("in _OnTreeAsync() IsContainerAsync callback " + iscontainer);
                if (iscontainer) {
                    //Xmarks.LogWrite("in _OnTreeAsync() pushing children ");
                    children = self.PushChildren(item, items, ot.depthFirst);
                }
                
                try {
                    //Xmarks.LogWrite("in _OnTreeAsync() calling ot.action.apply()");
                    ot.action.apply(ot.Caller, [item, pnid, children, itemdonecallback]);
                } catch (e) {
                    Xmarks.LogWrite("OnTree error: " + e + " source: " + e.toSource());
                    result = typeof(e) == "number" ? e : 3;
                }

                if (result)
                    itemdonecallback();
            });

        }, iterationcomplete);
    },

    OnTree: function(Caller, is_async, action, complete) {
        ot = {};
        ot.self = this;
        ot.Caller = Caller;
        ot.action = action;
        ot.complete = complete;
        ot.depthfirst = false;
        ot.items = [];
        ot.notify = function () {
            var self = ot.self;
            self._func = (is_async) ? self._OnTreeAsync : self._OnTree;
            self._args = null;
            self.bmsvc.runInBatchMode(self, null);
        };

        this.PushRoot(this.bmsvc.bookmarksMenuFolder, ot.items);
        this.PushRoot(this.bmsvc.toolbarFolder, ot.items);
        this.PushRoot(this.bmsvc.unfiledBookmarksFolder, ot.items);

        ot.timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        ot.timer.initWithCallback(ot, 10, Ci.nsITimer.TYPE_ONE_SHOT);

        return;
    },

    Repair: function() {
        var self = this;
        var roots =
            [[ this.bmsvc.bookmarksMenuFolder, "Bookmarks Menu" ],
             [ this.bmsvc.unfiledBookmarksFolder, "Unsorted Bookmarks" ],
             [ this.bmsvc.toolbarFolder, "Bookmarks Toolbar" ]];

        if (!this.initialized) {
            throw 6;
        }

        function HasRoot(id) {
            var has_root = true;
            var DBConn = Cc["@mozilla.org/browser/nav-history-service;1"]
                .getService(Ci.nsPIPlacesDatabase).DBConnection;

            var stmt = DBConn.createStatement(
                "SELECT COUNT(*) FROM moz_bookmarks where id=:id");

            stmt.params["id"] = id;
            try {
                stmt.executeStep();
                has_root = stmt.getInt32(0) != 0;
            }
            finally {
                stmt.reset();
            }
            return has_root;
        }

        // make sure required native bookmarks exist... this is
        // pure evil, but if we're here, stuff is hosed anyway.
        function CreateRoot(id, name) {
            Xmarks.LogWrite("Missing root: " + name + "(" + id + ")");
            var DBConn = Cc["@mozilla.org/browser/nav-history-service;1"]
                .getService(Ci.nsPIPlacesDatabase).DBConnection;

            var stmt = DBConn.createStatement(
                "INSERT INTO moz_bookmarks " +
                "   (id, type, fk, parent, position, title, guid) values " + 
                "   (:id, 2, NULL, :parent, :pos, :title, :guid)");

            stmt.params["id"] = id;
            stmt.params["parent"] = self.bmsvc.placesRoot;
            stmt.params["pos"] = id - 1;
            stmt.params["title"] = name;
            stmt.params["guid"] = self.GenerateNid();

            stmt.execute();
            Xmarks.LogWrite("Recreated " + id + " as " + stmt.params["guid"]);
        }

        for (var i=0; i < roots.length; i++) {
            var id = roots[i][0];
            var name = roots[i][1];
            try {
                if (!HasRoot(id))
                    CreateRoot(id, name);
            } catch (e) {
                Xmarks.LogWrite("Error creating root: " + e);
            }
        }

        this.CleanXmarksDB();
    },

    PushRoot: function(itemId, list) {
        var nid = null;
        try {
            nid = this.MapNative(itemId);
        } catch(e) {
            Xmarks.LogWrite("Error: PushRoot couldn't find root for " + itemId);
            throw 1006;
        }

        var options = Call(this.hsvc, this.hsvc.getNewQueryOptions);
        var query = Call(this.hsvc, this.hsvc.getNewQuery);
        query.setFolders([itemId], 1);
        var result = Call(this.hsvc, this.hsvc.executeQuery, query, options);
        list.push([result.root, nid, null]);
        return true;
    },

    IsContainer: function(item) {
        //Xmarks.LogWrite("in IsContainer() item.type=" + item.type);
        return (BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE[item.type] == 
                'folder' && !this.IsLivemark(item.itemId));
    },

    IsContainerAsync: function(item, callback) {
        var self = this;

        //Xmarks.LogWrite("in IsContainerAsync() item.type=" + item.type);

        if (BookmarkDatasource.MAP_PLACE_TYPE_TO_NTYPE[item.type] != 'folder') {
            callback(false);
            return;
        }

        //Xmarks.LogWrite("in IsContainerAsync() calling IsLivemarkAsync");

        self.IsLivemarkAsync(item.itemId, function(islivemark) {
            //Xmarks.LogWrite("in IsContainerAsync() before callback islivemark=" + islivemark);
            callback(!islivemark);
        });
    },

    ProvideNodes: function(Caller, AddNode, Complete) {
        if (collectTimingInfo)
            StartTimes("ProvideNodes");
        this.pn = {}
        this.pn.Caller = Caller;
        this.pn.AddNode = AddNode;
        this.pn.Complete = Complete;
        if (!this.initialized) {
            Complete.apply(Caller, [6]);
            return;
        }
        Xmarks.LogWrite("ProvideNodes() begin");
        try {
            if (this.lmsvc) {
                this.OnTree(this, false,
                    BookmarkDatasource.MapPlacesToNode, 
                    BookmarkDatasource.ProvideNodesDone);
            } else {
                this.OnTree(this, true,
                    BookmarkDatasource.MapPlacesToNodeAsync, 
                    BookmarkDatasource.ProvideNodesDone);
            }
        } catch (e) {
            Xmarks.LogWrite("exception in BookmarkDatasource.ProvideNodes()");
            Complete.apply(Caller, [e]);
        }
        return;
    },

    // Enumerate the children of item and push them
    // onto the provided list, according to depthFirst ordering.
    // Returns the list of child nids.

    PushChildren: function(item, list, depthFirst) {
        if (!(item instanceof Ci.nsINavHistoryContainerResultNode)) {
            throw Error("Expected a folder but got a non-container");
        }

        item.containerOpen = true;
        try {
            var pnid = this.MapNative(item.itemId);
        } catch (e) {
            Xmarks.LogWrite("PushChildren skipping bad parent");
            return [];
        }
        var cnids = [];

        for (var i = 0; i < item.childCount; ++i) {
            child = item.getChild(i);
            try {
                var cnid = this.MapNative(child.itemId)
            } catch(e) {
                Xmarks.LogWrite("PushChildren skipping bad child");
                continue;
            }
            cnids.push(cnid);
            if (depthFirst) {
                list.splice(i, 0, [child, cnid, pnid]);
            } else {
                list.push([child, cnid, pnid]);
            }
        }
        item.containerOpen = false;
        return cnids;
    },

    //
    // Observer functions.
    //

    WatchForChanges: function() {
        var watcher = new BookmarkWatcher(this);
        // start observing
        Call(this.bmsvc, this.bmsvc.addObserver, watcher, false);

        return watcher;
    },


    DeleteNid: function(nid) {
      var self = this;
      var itemId = self.MapNid(nid);
      if(itemId!=-1 && itemId!=this.bmsvc.bookmarksMenuFolder && itemId!=this.bmsvc.toolbarFolder && itemId!=this.bmsvc.unfiledBookmarksFolder){
        try{ self.RemoveItem(itemId); }catch(e){}
        delete BookmarkDatasource._mapNidToNative[nid];
        delete BookmarkDatasource._mapNativeToNid[itemId];
        BookmarkDatasource.dirty = true;
      }
    },

    // Mark the datasource dirty and send the UI notification
    MarkDirty: function(lm) {
        if (!lm) {
            // Output Javascript milliseconds since 1970.
            lm = Date.now();
        }
        if (!this.lastModified || lm > this.lastModified) {
            this.lastModified = lm;
            var os = Cc["@mozilla.org/observer-service;1"]
                .getService(Ci.nsIObserverService);
            os.notifyObservers(null, "foxmarks-datasourcechanged",
                lm + ";bookmarks");
            BookmarkDatasource.dirty = true;
        }
    },

    ReloadIcon: function(url, icon_url) {

        var self = this;
        if (!self.afisvc) {
            callback(0);
            return;
        }

        var uri = self.NewURI(url);
        var iconUri = self.NewURI(icon_url);

        Xmarks.LogWrite("A Fetching url: " + url + " icon: " + icon_url);
        if (!uri || !iconUri) {
            callback(0);
            return;
        }

        Xmarks.LogWrite("B Fetching url: " + url + " icon: " + icon_url);
        self.SetIconURLForPage(uri, iconUri, null);
    }
};

function BookmarkWatcher(datasource)
{
    this.datasource = datasource;
    try {
      this.mssvc = Cc["@mozilla.org/microsummary/service;1"].
          getService(Ci.nsIMicrosummaryService);
    } catch (e) {
      this.mssvc = null;
    }
}

BookmarkWatcher.prototype = {

    datasource : null,
    itemIdsToDelete : [],
    batchInProgress : false,
    timer : null,

    NotifyObservers: function(reason) {
        this.datasource.MarkDirty();
    },

    ////////////////////////////////////////////////////////////////////////////
    //
    // nsINavBookmarkObserver

    onBeginUpdateBatch: function() {
        //Xmarks.LogWrite("onBeginUpdateBatch()");

        this.batchInProgress = true;
    },

    onEndUpdateBatch: function() {
        //Xmarks.LogWrite("onEndUpdateBatch()");

        this.batchInProgress = false;

        this.deletePendingItems();
    },

    deletePendingItems: function() {
        if (this.itemIdsToDelete.length > 0) {
           //Xmarks.LogWrite("deletePendingItems()  deleting " + this.itemIdsToDelete.length + " items");
           this.datasource.RemoveItemsFromPrivateDB(this.itemIdsToDelete);
           this.itemIdsToDelete = [];
        }
    },

    setTimer: function() {
        var self = this;
        if (self.timer == null) {
            //Xmarks.LogWrite("setTimer()");
            self.timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
            self.timer.initWithCallback({
                notify: function(t) {
                    self.deletePendingItems();
                    self.timer = null;
                }
            }, 1000, Ci.nsITimer.TYPE_ONE_SHOT);
        }
    },

    onItemAdded: function(itemId, folderId) {
        //Xmarks.LogWrite("onItemAdded()  itemId=" + itemId);
        var self = this;
        if (self.datasource.IsLivemarkAsync) {
            self.datasource.IsLivemarkAsync(folderId, function(islivemark) {
                if (!islivemark) {
                    self.NotifyObservers("Added");
                }
            });
        } else {
            Xmarks.LogWrite("IsLivemarkAsync: function not found");
        }
    },

    onItemRemoved: function(itemId, folderId) {
        var self = this;
        if (self.datasource.IsLivemarkAsync) {
            self.datasource.IsLivemarkAsync(folderId, function(islivemark) {
                //Xmarks.LogWrite("onItemRemoved()  itemId=" + itemId + " islivemark=" + islivemark);
                if (!islivemark) {
                    self.itemIdsToDelete.push(itemId);
                    if (!self.batchInProgress) {
                        self.setTimer();
                    }
                    self.NotifyObservers("Removed");
                }
            });
        } else {
            Xmarks.LogWrite("IsLivemarkAsync: function not found");
        }
    },

    onItemChanged: function(itemId, property) { 
        //Xmarks.LogWrite("onItemChanged()  itemId=" + itemId);
        // Skip title change for Microsummaries
        if (this.mssvc && this.mssvc.hasMicrosummary(itemId) && property == 'title')
            return;

        if (BookmarkDatasource.INTERESTING_PROPERTIES[property] ||
            BookmarkDatasource.MAP_ANNO_TO_NODE[property]) {
            this.NotifyObservers("Changed") 
        }
    },

    onItemMoved: function() { 
        this.NotifyObservers("Moved") 
    },

    onBeforeItemRemoved: function() {},
    onItemVisited: function() {},
    onBeginUpdateBatch: function() {
        if (this.datasource.UsePrivateDB) {
            this.datasource.GetXmarksDBConnection().beginTransaction();
        }
    },
    onEndUpdateBatch: function() {
        if (this.datasource.UsePrivateDB) {
            this.datasource.GetXmarksDBConnection().commitTransaction();
        }
    },

    QueryInterface: function(iid) {
        if (iid.equals(Ci.nsINavHistoryBatchCallback) ||
            iid.equals(Ci.nsINavBookmarkObserver))
            return this;
        throw Components.result.NS_ERROR_NO_INTERFACE;
    }
};

exports.BookmarkDatasource = BookmarkDatasource;
exports.BookmarkWatcher = BookmarkWatcher;
