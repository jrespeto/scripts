const { Cc, Ci } = require("chrome");

var loader = Cc["@mozilla.org/moz/jssubscript-loader;1"].
    getService(Ci.mozIJSSubScriptLoader);

loader.loadSubScript("chrome://foxmarks/content/shared/Base64.js", null);

exports.Base64 = Base64;
