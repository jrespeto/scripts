/*
 * Base64 encoding/decoding routines.
 * (c) 2014 Marvasol, Inc.
 */
(function() {

    var map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

    /*
     * Given a javascript string, return an array of byte values
     * representing their utf-8 ordinals.  E.g.:
     *
     * héllo => [104, 195, 41, 108, 108, 111 ].
     *
     * Can convert to a normal string via String.fromCharCode.apply(null, array).
     */
    function utf8_encode_bytes(str)
    {
        var byte_vals = [];
        for (var i=0; i < str.length; i++) {
            var cp = str.charCodeAt(i);

            if (cp <= 127) {
                byte_vals.push(cp);
            } else if (cp < (1 << 11)) {
                byte_vals.push(0xc0 | (cp >>> 6));
                byte_vals.push(0x80 | (cp & 0x3f));
            } else if (cp < (1 << 16)) {
                byte_vals.push(0xe0 | (cp >>> 12));
                byte_vals.push(0x80 | (cp & 0xfff) >>> 6);
                byte_vals.push(0x80 | (cp & 0x3f));
            } else if (cp < (1 << 21)) {
                byte_vals.push(0xf0 | (cp >>> 18));
                byte_vals.push(0x80 | (cp & 0x3ffff) >>> 12);
                byte_vals.push(0x80 | (cp & 0xfff) >>> 6);
                byte_vals.push(0x80 | (cp & 0x3f));
            }
        }
        return byte_vals;
    }

    /*
     * Test for continuation of encoded byte.
     * Return true if the value starts with binary b10xxxxxx
     */
    function is_cont_char(val)
    {
        return (val & 0xc0) == 0x80;
    }

    /*
     * Given an array of utf-8 byte values, return the unicode string
     * representing that array.
     *
     * E.g. [232, 164, 160, 120, 121, 122] => 褠xyz
     */
    function utf8_decode_bytes(ord_array)
    {
        var chars = [];
        var broken = String.fromCharCode(0xfffd);

        for (var i=0; i < ord_array.length; i++) {
            var val = ord_array[i];
            var cont_count = 0;
            var cp = 0;

            if (val <= 127) {
                cp = val;
            }
            else if ((val & 0xe0) == 0xc0) {
                cp = val & ~0xc0;
                cont_count = 1;
            }
            else if ((val & 0xf0) == 0xe0) {
                cp = val & ~0xe0;
                cont_count = 2;
            }
            else if ((val & 0xf8) == 0xf0) {
                cp = val & ~0xf0;
                cont_count = 3;
            }
            else {
                chars.push(broken);
                continue;
            }

            /* not enough continuation chars? */
            if (ord_array.length - i < cont_count) {
                chars.push(broken);
                continue;
            }

            /* invalid continuation chars? */
            for (var j = 0; j < cont_count; j++) {
                if (!is_cont_char(ord_array[i + j + 1])) {
                    chars.push(broken);
                    continue;
                }
            }

            /* chars ok, go ahead and add */
            for (var j = 0; j < cont_count; j++) {
                var ch = ord_array[i + j + 1];
                cp = cp << 6 | (ch & 0x3f);
            }
            chars.push(String.fromCharCode(cp));
            i += cont_count;
        }
        return chars.join("");
    }

    /*
     * Given an array of byte values, encode it into a base64 string.
     */
    function b64_encode_bytes(bytes)
    {
        var working = bytes;
        var chars = [];

        var padlen = 0;
        var last_block_len = working.length % 3;
        if (last_block_len) {
            padlen = 3 - last_block_len;
            for (var i = 0; i < padlen; i++)
                working.push(0);
        }

        for (var i=0; i < working.length; i += 3) {
            chars.push(map.charAt(working[i] >>> 2));
            chars.push(map.charAt(((working[i] & 0x3) << 4) | (working[i+1] >>> 4)));
            chars.push(map.charAt(((working[i+1] & 0xf) << 2) | (working[i+2] >>> 6)));
            chars.push(map.charAt(working[i+2] & 0x3f));
        }

        for (var i=0; i < padlen; i++)
            chars[chars.length - i - 1] = "=";

        return chars.join("");
    }

    /*
     * Given a base64 string, decode it into an array of bytes.
     */
    function b64_decode_bytes(strval)
    {
        /* drop any invalid characters */
        var str = strval.replace(/[^A-Za-z0-9+/=]/g, "");
        var bytes = [];

        /* make sure we are padded out to multiple of 4 */
        if ((str.length & 3) != 0) {
            var padlen = 4 - (str.length & 3);
            while (padlen--) {
                str += "=";
            }
        }

        /* now extract 8 byte values from 4 groups of 6 bits */
        for (var i=0; i < str.length; i += 4)
        {
            var bits1 = map.indexOf(str.charAt(i));
            var bits2 = map.indexOf(str.charAt(i+1));
            var bits3 = map.indexOf(str.charAt(i+2));
            var bits4 = map.indexOf(str.charAt(i+3));

            bytes.push((bits1 << 2) | (bits2 >> 4));

            /* only append last 2 characters if not padding */
            if (bits3 != 64)
                bytes.push(((bits2 & 0xf) << 4) | (bits3 >> 2));

            if (bits4 != 64)
                bytes.push(((bits3 & 0x3) << 6) | bits4);
        }
        return bytes;
    }

    /*
     * Given a unicode string, produce a base64 encoded string.
     */
    function b64_encode(str)
    {
        return b64_encode_bytes(utf8_encode_bytes(str));
    }

    /*
     * Given a base64 encoded string, produce a unicode string.
     */
    function b64_decode(str)
    {
        return utf8_decode_bytes(b64_decode_bytes(str));
    }

    Base64 = {
        encode: function(input, isBinaryData) {
            if (isBinaryData)
                return b64_encode_bytes(input);

            return b64_encode(input);
        },

        decode: function(input, isBinaryData) {
            if (isBinaryData)
                return b64_decode_bytes(input);

            return b64_decode(input);
        }
    };

    if (typeof(exports) != "undefined") {
        exports.Base64 = Base64;
        exports.utf8_encode_bytes = utf8_encode_bytes;
        exports.utf8_decode_bytes = utf8_decode_bytes;
        exports.b64_encode = b64_encode;
        exports.b64_decode = b64_decode;
        exports.b64_encode_bytes = b64_encode_bytes;
        exports.b64_decode_bytes = b64_decode_bytes;
    }

    if (typeof(window) != 'undefined' && window.Foxmarks) {
        Foxmarks.provide('Foxmarks.ThirdParty.Base64');
        Foxmarks.ThirdParty.Base64 = Base64;
    }
})();
