/*
 Copyright 2005-2010 Xmarks Inc.

 foxmarks-ownserverdlg.js: Implements a use own server dialog

 */

var gOwnServerParams;
function ownServerLoad(){
    gOwnServerParams = window.arguments[0];

    setval("url", "url");
    setval("passwordurl", "purl");
    setval("username", "username");
    setval("password", "password");
    document.getElementById("remember").checked = gOwnServerParams.remember;
}

function val(id) {
    return document.getElementById(id).value;
}

function setval(id, attr) {
    document.getElementById(id).value = gOwnServerParams[attr] || "";
}

function ownServerOK(){
    var url = val("url");
    var purl = val("passwordurl");
    var username = val("username");
    var password = val("password");
    var remember = document.getElementById("remember").checked;

    if(url.length && url != purl &&
        (!gOwnServerParams.psync || purl.length)){
        gOwnServerParams.url = url;
        gOwnServerParams.purl = purl;
        gOwnServerParams.username = username;
        gOwnServerParams.password = password;
        gOwnServerParams.remember = remember;
        gOwnServerParams.result = true;
    } else {
        Xmarks.Alert(Xmarks.Bundle().
            GetStringFromName("error.ownserveremptyurl"));
        return false;
    }

    return true;
}

function ownServerCancel(){
    gOwnServerParams.result = false;
}
