function xmarks_support_choose_file(source)
{
    var nsIFilePicker = Components.interfaces.nsIFilePicker;
    var fp = Components.classes["@mozilla.org/filepicker;1"].createInstance(nsIFilePicker);
    fp.init(window, "Select a File", nsIFilePicker.modeOpen);
    var res = fp.show();
    if (res != nsIFilePicker.returnCancel) {
        var thefile = fp.file;
        document.getElementById("replay-" + source).value = thefile.path;
    }
}

function xs_load_bookmarks(fullpath)
{
    var ns = new Xmarks.ns.Nodeset(new BookmarkDatasource());
    ns.LoadFromFile(fullpath);
    return ns;
}

function xs_do_sync(baseline, remote, local)
{
    var bns = xs_load_bookmarks(baseline);
    var sns = xs_load_bookmarks(remote);
    var lns = xs_load_bookmarks(local);

    Xmarks.LogWrite("uploading baseline to server...");
    bns.FlushToNative(function() {
        Xmarks.fms.server.upload(function() {

            Xmarks.LogWrite("reloading baseline to get new revision...");
            bns.LoadFromFile();

            Xmarks.LogWrite("putchanges (server - baseline)...");
            sns.FlushToNative(function() {
                Xmarks.fms.server.sync(function() {

                    Xmarks.LogWrite("install local nodes...");
                    lns.FlushToNative(function() {
                        Xmarks.LogWrite("resync with old baseline...");
                        Xmarks.fms.server._baseline = bns;
                        Xmarks.fms.server.sync(function() {
                            Xmarks.LogWrite("done!");
                        });
                    });
                });
            });
        });
    });


/*
    // update lns on disk
    // sync

    Xmarks.fms.synchronize(automatic, dirtyOnly) {

    // run base.Compare() to generate lcs and scs
    bns_copy.Compare(lns, function(status, lcs) {

        bns_copy = bns.Copy();
        var scs = bns_copy.Compare(sns, function(status, scs) {

            // run Synchronize to do conflict resolution, generating lcs', scs'
            Xmarks.core.Synchronize(bns, lcs, scs, lns, sns, function(new_lcs, new_scs) {
                Xmarks.LogWrite("new lcs: " + JSON.stringify(new_lcs));
                Xmarks.LogWrite("new scs: " + JSON.stringify(new_scs));

                lns.Execute(new_scs);
            });
        });
    });
    */
}

function xmarks_support_do_replay()
{
    Xmarks.bmds = Xmarks.require("./foxmarks-places.js");
    BookmarkDatasource = Xmarks.bmds.BookmarkDatasource;
    BookmarkWatcher = Xmarks.bmds.BookmarkWatcher;
    Xmarks.cs = Xmarks.require("./foxmarks-command.js");
    Xmarks.ns = Xmarks.require("./foxmarks-nodes.js");
    Xmarks.core = Xmarks.require("./foxmarks-core.js");
    Xmarks.jsparse = Xmarks.require("./jsparse.js");

    var baseline = document.getElementById("replay-baseline").value;
    var local = document.getElementById("replay-local").value;
    var server = document.getElementById("replay-server").value;

    xs_do_sync(baseline, server, local);
}
