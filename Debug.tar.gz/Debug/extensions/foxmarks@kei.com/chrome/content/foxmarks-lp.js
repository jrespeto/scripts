
var settingsdoc = null;
function onloadLastPass(){
  if(typeof(window.arguments)!='undefined' && window.arguments.length>0)
    settingsdoc = window.arguments[0];
}

function Go(){

  window.close();
}


function Wait(){
  settingsdoc.getElementById('password-section1').setAttribute("hidden", "false");
  settingsdoc.getElementById('password-section2').setAttribute("hidden", "false");
  window.close();
}
