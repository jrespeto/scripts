/*
 Copyright 2010 Xmarks Inc.

 */

// Real settings object now located in modules/settings.jsm.

var Xmarks;
if (Xmarks === undefined) {
    Xmarks = {};
    Components.utils['import']("resource://xmarks/settings.jsm", Xmarks);
    Components.utils['import']("resource://xmarks/service.jsm", Xmarks);
}
