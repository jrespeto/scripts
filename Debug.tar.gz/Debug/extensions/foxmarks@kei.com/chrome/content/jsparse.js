/*
 * Tokenize (simplified) javascript
 */

exports.xmarks_js_tokenize = xmarks_js_tokenize;
exports.xmarks_load_baseline = xmarks_load_baseline;
exports.nodedict_to_tree = nodedict_to_tree;
exports.tree_to_nodedict = tree_to_nodedict;
exports.load_json_file = load_json_file;

function xmarks_js_tokenize(js_str)
{
    var tokenlist = [];

    for (var i=0; i < js_str.length; )
    {
        var ch = js_str[i];
        switch (ch) {
            // whitespace is skipped
            case ' ':
            case '\n':
            case '\r':
                i++;
                break;

            // these tokens copied verbatim
            case ':':
            case '=':
            case '[':
            case ']':
            case ';':
            case ',':
            case '(':
            case ')':
            case '{':
            case '}':
                tokenlist.push(ch);
                i++;
                break;

            // capture quoted string, starting from the next character
            case '"':
            case "'":
                var quot = ch;
                var str = "";
                for (++i; i < js_str.length; i++) {
                    if (js_str[i] == '\\' && (i < js_str.length - 1)) {
                        switch (js_str[++i]) {
                            case 'b':
                                str += "\b";
                                break;
                            case 'f':
                                str += "\f";
                                break;
                            case 'n':
                                str += "\n";
                                break;
                            case 'r':
                                str += "\r";
                                break;
                            case 't':
                                str += "\t";
                                break;
                            case 'v':
                                str += "\v";
                                break;
                            case 'x':
                                /* 'x' + 2 chars left? */
                                if (i + 1 < js_str.length - 2) {
                                    i++;
                                    var hex = parseInt(js_str.substr(i, 2), 16);
                                    /* advance counting increment after loop */
                                    i += 2 - 1;
                                    str += String.fromCharCode(hex);
                                }
                                break;
                            case 'u':
                                /* 'u' + 4 chars left? */
                                if (i + 1 < js_str.length - 4) {
                                    i++;
                                    var hex = parseInt(js_str.substr(i, 4), 16);
                                    /* advance counting increment after loop */
                                    i += 4 - 1;
                                    str += String.fromCharCode(hex);
                                }
                                break;
                            default:
                                str += js_str[i];
                                break;
                        }
                    }
                    else if (js_str[i] == quot) {
                        i++;
                        break;
                    } else {
                        str += js_str[i];
                    }
                }
                tokenlist.push({"str": str});
                break;

            // assume anything else is an identifier
            default:
                var id = "";
                for (; i < js_str.length; i++) {
                    if (js_str[i].match(/[A-Za-z0-9_]/) == null)
                        break;
                    id += js_str[i];
                }
                tokenlist.push({"id": id});
                break;
        }
    }
    return tokenlist;
}

function js_val(token)
{
    if (typeof(token) == "string") {
        return token;
    }

    if (typeof(token.id) != "undefined") {
        return token.id;
    }

    if (typeof(token.str) != "undefined") {
        return token.str;
    }
}

function js_parse_prop(tokens, start, end)
{
    if (!tokens)
        throw Error("Expected property token at " + start);

    var propname;
    var value;

    if (typeof(tokens[start]) != 'object' ||
        tokens[start + 1] != ':')
        throw Error("Expected property list at " + start);

    propname = js_val(tokens[start]);

    start += 2;

    var result = js_parse_exp(tokens, start, end);

    value = result[0];
    tokens = result[1];
    start = result[2];
    end = result[3];

    return [{'id': propname, 'value': value}, tokens, start, end];
}

function js_parse_prop_list(tokens, start, end)
{
    var proplist = [];
    for (var i=start; i < end; ) {
        var result = js_parse_prop(tokens, i, end);
        var tok = result[0];
        tokens = result[1];
        i = result[2];
        end = result[3];

        if (!tok)
            throw Error("Expected property at " + start);

        proplist.push(tok);

        if (tokens && tokens[i] == ',')
            i++;
    }
    return [proplist, tokens, i, end];
}

function js_parse_obj_exp(tokens, start, end)
{
    if (tokens[start] != '{')
        throw Error("Unexpected token '" + tokens[start] + "', expected '{' at " + start);

    // find closing brace
    var openct = 1;
    for (var i = start + 1; i < end; i++) {
        if (tokens[i] == '{')
            openct++;

        if (tokens[i] == '}')
            openct--;

        if (openct == 0)
            break;
    }

    var ret = js_parse_prop_list(tokens, start + 1, i);
    var props = ret[0];
    var endtok = i;

    var obj = {};
    for (var i = 0; i < props.length; i++) {
        obj[props[i].id] = props[i].value;
    }

    return [obj, tokens, endtok + 1, end];
}

function js_parse_instance(tokens, start, end)
{
    if (tokens[start].id != "new" ||
        typeof(tokens[start + 1]) != "object" ||
        tokens[start + 2] != "(")
        throw Error("Invalid instance at " + start);

    var objname = js_val(tokens[start + 1]);

    result = js_parse_paren_exp(tokens, start + 2, end);
    var argslist = result[0];
    tokens = result[1];
    start = result[2];
    end = result[3];

    return [{'newobj': objname, 'args': argslist}, tokens, start, end];
}

function js_parse_exp_list(tokens, start, end)
{
    var explist = [];
    for (var i = start; i < end; ) {
        var result = js_parse_exp(tokens, i, end);
        var tok = result[0];
        tokens = result[1];
        i = result[2];
        end = result[3];

        if (!tok)
            return [null, tokens];

        explist.push(tok)

        if (i < end && tokens[i] == ',')
            i += 1;
    }
    return [explist, tokens, i, end];
}

function js_parse_exp(tokens, start, end)
{
    if (!tokens)
        throw Error("Expected token at offset " + start);

    if (typeof(tokens[start]) == "string") {
        switch(tokens[start]) {
            case '(':
                return js_parse_paren_exp(tokens, start, end);
            case '{':
                return js_parse_obj_exp(tokens, start, end);
            case '[':
                return js_parse_array_exp(tokens, start, end);
        }
    }
    else if (tokens[start].hasOwnProperty('str')) {
        return [tokens[start].str, tokens, start + 1, end];
    }
    else if (tokens[start].hasOwnProperty('id')) {
        if (tokens[start].id == "new") {
            return js_parse_instance(tokens, start, end);
        }
        if (/^[0-9]+$/.test(tokens[start].id)) {
            return [parseInt(tokens[start].id), tokens, start + 1, end];
        }
        if (tokens[start].id == "null") {
            return [null, tokens, start + 1, end];
        }
        // something else.
        return [tokens[start].id, tokens, start + 1, end];
    }
}

function js_parse_array_exp(tokens, start, end)
{
    if (tokens[start] != '[')
        throw Error("Unexpected token '" + tokens[start] + "', expected '[' at " + start);

    // find closing paren
    var openct = 1;
    for (var i = start + 1; i < end; i++) {
        if (tokens[i] == '[')
            openct++;

        if (tokens[i] == ']')
            openct--;

        if (openct == 0)
            break;
    }
    var ret = js_parse_exp_list(tokens, start + 1, i);
    return [{"array" : ret[0]}, tokens, i+1, end];
}

function js_parse_paren_exp(tokens, start, end)
{
    if (tokens[start] != '(')
        throw Error("Unexpected token '" + tokens[start] + "', expected '(' at " + start);

    // find closing paren
    var openct = 1;
    for (var i = start + 1; i < end; i++) {
        if (tokens[i] == '(')
            openct++;

        if (tokens[i] == ')')
            openct--;

        if (openct == 0)
            break;
    }

    var ret = js_parse_exp_list(tokens, start + 1, i);
    return [{"tuple" : ret[0]}, tokens, i+1, end];
}

function xmarks_js_parse(js_str)
{
    var tokens = xmarks_js_tokenize(js_str);
    return js_parse_exp(tokens, 0, tokens.length);
}

function convert_oldstyle_node(nodeobj)
{
    if (nodeobj.newobj !== 'Node')
        return null;

    var nid = nodeobj.args.tuple[0];
    var props = nodeobj.args.tuple[1].tuple[0];

    var obj = {
        nid: nid,
    };

    for (var k in props) {
        if (props.hasOwnProperty(k)) {
            if (props[k] && props[k].array) {
                obj[k] = props[k].array;
            } else {
                obj[k] = props[k];
            }
        }
    }
    return obj;
}

function convert_oldstyle_nodeset(js_dict)
{
    var nodes = {};

    for (var k in js_dict) {
        if (js_dict.hasOwnProperty(k)) {
            nodes[k] = convert_oldstyle_node(js_dict[k]);
        }
    }
    return nodes;
}

/*
 * Enhance a node dictionary with children pointers so that we can walk
 * it starting at the root.
 */
function nodedict_to_tree(nodes)
{
    if (!nodes['ROOT']) {
        nodes['ROOT'] = {
            'ntype': 'folder'
        };
    }

    // add pos, nid to children array, and sort later
    // this works even if there are duplicate indexes
    for (var nid in nodes) {
        if (!nodes.hasOwnProperty(nid))
            continue;

        var node = nodes[nid];

        // drop any existing array
        delete nodes['children'];

        if (node['ntype'] == 'folder') {
            node['chsort'] = node['chsort'] || [];
        }

        var pnid = node['pnid'];
        if (!pnid)
            continue;

        var pnode = nodes[pnid];
        if (!pnode)
            continue;

        var pos = node['position'] || 0;
        var children = pnode['chsort'] || [];
        children.push([pos, nid]);
        pnode['chsort'] = children;
    }

    for (var nid in nodes) {
        if (!nodes.hasOwnProperty(nid))
            continue;

        var node = nodes[nid];

        delete node['position'];

        if (node['ntype'] != 'folder') {
            delete node['children'];
            continue;
        }

        // generate sorted array based on tuples in 'chsort' elements;
        // sort on position values.
        var chsort = node['chsort'] || [];
        chsort.sort(function(a, b) { return a[0] - b[0] });

        // write just nids into node['children']
        node['children'] = chsort.map(function(x) { return x[1]; });
        delete node['chsort'];
    }
}

/*
 * Drop children arrays from nodedict/tree.
 * Positional attributes are updated to reflect the children arrays, if
 * present.
 */
function tree_to_nodedict(nodes)
{
    for (var nid in nodes) {
        if (!nodes.hasOwnProperty(nid))
            continue;

        var node = nodes[nid];
        var children = node['children'] || [];
        delete node['children'];

        for (var i = 0; i < children.length; i++) {
            var cnid = children[i];

            var child = nodes[cnid];
            if (child['pnid'] == nid) {
                child['position'] = i;
            }
        }
    }
}

function xmarks_oldstyle_js_to_json_dict(js_str)
{
    var result = xmarks_js_parse(js_str);

    if (!result[0] || !result[0].tuple)
        return null;

    // FIXME: some versions are lacking the toplevel tuple...
    var obj = result[0].tuple[0];
    var nodeset = convert_oldstyle_nodeset(obj._node);
    tree_to_nodedict(nodeset);

    var xmarks_json = {
        "format": "xmarks_nodes",
        "version": "1.0",
        "toprev": obj.currentRevision,
        "plugin": "ff",
        "plugin_version": obj.version,
        "nodes": nodeset
    };
    return xmarks_json;
}

function xmarks_load_baseline(js_str)
{
    if (js_str[0] == '(') {
        return xmarks_oldstyle_js_to_json_dict(js_str);
    }
    return JSON.parse(js_str);
}

function read_file(filename)
{
    var PERMS_FILE    = parseInt("0644", 8); // EC5 hates octal literals like 0644;
    var MODE_RDONLY   = 0x01;

    var FileUtils = Cu.import("resource://gre/modules/FileUtils.jsm").FileUtils;
    var file = new FileUtils.File(filename);

    var fstream = Cc["@mozilla.org/network/file-input-stream;1"]
        .createInstance(Ci.nsIFileInputStream);
    fstream.init(file, MODE_RDONLY, PERMS_FILE, 0);
    var cstream = Cc["@mozilla.org/intl/converter-input-stream;1"]
        .createInstance(Ci.nsIConverterInputStream);
    cstream.init(fstream, "UTF-8", 32768, 0xFFFD);
    var str = {};

    var contents = "";

    while (cstream.readString(32768, str) != 0) {
        contents += str.value;
    }
    fstream.close();
    cstream.close();
    return contents;
}

function load_json_file(filename)
{
    var s = read_file(filename);
    var bookmarks = JSON.parse(s);
    nodedict_to_tree(bookmarks.nodes);
    return bookmarks;
}
