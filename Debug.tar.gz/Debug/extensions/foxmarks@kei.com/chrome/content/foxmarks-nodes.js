/*
 Copyright 2007-2008 Foxmarks Inc.

 foxmarks-nodes.js: implements class Node and Nodeset, encapsulating
 our datamodel for the bookmarks.

 */

// To do:
// * Add integrity checking to commands
// * We're currently filtering out modified- and visited-only updates
//   in the Compare algorithm. This is okay for modified but probably
//   inappropriate for visited: visited will only get updated when some
//   other attribute of the node changes, which may never happen. On the
//   other hand, we don't want to sync every change to last visited. We
//   may want to do something like a standard sync and a thorough sync;
//   do a thorough sync either once a week or randomly 1 in 10 times. The
//   thorough sync is when we'd perpetuate the last-visit updates.
// * In merge algorithm, special treatment for toolbar folders.

const { Cc, Ci, Cr, Cu } = require("chrome");

// Module-wide constants
var NODE_ROOT     = "ROOT";
var PERMS_FILE    = parseInt("0644", 8); // EC5 hates octal literals like 0644;
var MODE_RDONLY   = 0x01;
var MODE_WRONLY   = 0x02;
var MODE_CREATE   = 0x08;
var MODE_APPEND   = 0x10;
var MODE_TRUNCATE = 0x20;

if (typeof(exports.plugin) == "undefined") {
    // when running from test cases...
    var Xmarks = {};
    Xmarks.cs = require("./foxmarks-command.js");
    Xmarks.jsparse = require("./jsparse.js");
    Xmarks.LogWrite = function(x) { console.log(x); }
    Xmarks.LogError = function(x, e) { console.log(x + " " + e); }
} else {
    Xmarks = exports.plugin;
}

function encode_utf8(s)
{
    return unescape(encodeURIComponent(s));
}

function decode_utf8(s)
{
    return decodeURIComponent(escape(s));
}

var Commandset = Xmarks.cs.Commandset;
var Command = Xmarks.cs.Command;

// class Node

function Node(nid, attrs) {
    this.nid = nid;
    for (var a in attrs) {
        if (attrs.hasOwnProperty(a)) this[a] = attrs[a];
    }
    // TODO: remove all the assumptions that ntype will be a bookmark
    if (!this.ntype)
        this.ntype = "bookmark";
    //if (!this.ntype)
    //    throw("Node.ntype now required");
}

Node.prototype = {
    constructor: Node,

    toSource: function() {
        if (!this.ntype)
            throw("Node.ntype now required");
        return 'new Node("' + this.nid + '",' + 
            this.GetSafeAttrs(true).toSource() + ')';
    },

    realToSource: function() {
        return Object.prototype.toSource.apply(this);
    },

    GetSafeAttrs: function(withChildren) {
        var attrs = {};

        for (var attr in this) {
            if (this.hasOwnProperty(attr) && attr != 'nid' &&
                attr != 'private' &&
                (attr != 'children' || withChildren)) {
                    attrs[attr] = this[attr];
            }
        }

        return attrs;
    },

    FindChild: function(nid) {
        if (this["children"]) {
            return this.children.indexOf(nid);
        } else {
            return -1;
        }
    },

    // Merge the contents of another node into this node.
    // Ignore structural attributes (like nid, pnid, children)
    // and pay special attention to tags, giving consideration
    // to individual tags within each tag list.
    Merge: function(other) {
        var attrs = other.GetSafeAttrs();
        var self = this;
        for (var attr in attrs) {
            if (!attrs.hasOwnProperty(attr)) {
               continue;
            }
            if (attr == 'tags' && self.tags) {
                var modified = false;
                other.tags.forEach(function(t) {
                    if (self.tags.indexOf(t) < 0) {
                        self.tags.push(t);
                        modified = true;
                    }
                });
                if (modified) {
                    self.tags.sort();
                }
            } else {
                if (!self[attr]) {
                    self[attr] = other[attr];
                }
            }
        }
    },

    // Hash this node, with the property that any attributes that
    // we are interested in syncing, and all child hashes, are
    // covered by the digest.  We only compute one level; it is assumed
    // this is called in leaves-up manner via a post-order DFS.
    ComputeHash: function(nodeset, hash_attrs) {

        elements = [];
        for (var i = 0; i < hash_attrs.length; i++) {
            attr = hash_attrs[i];
            elements.push(encode_utf8(this[attr] || ""));
        }

        var hashstr = elements.join(",");

        children = this.children || [];

        for (var i = 0; i < children.length; i++) {
            cnid = children[i];
            hashstr += "_" + nodeset.Node(cnid).hash;
        }

        this.hash = Xmarks.hex_md5(hashstr);
    }
}

// class Nodeset

function Nodeset(datasource, cloneSource) {
    if(datasource === undefined || datasource instanceof Nodeset)
        throw("Nodeset() -- datasource is required");

    this.hash = null;
    this._datasource = datasource;
    this._cloneSource = cloneSource;
    this._node = {};
    this._callback = null;
    this._length = cloneSource ? cloneSource.length : 0;
}



Nodeset.FetchAdd = function(node) {
    this.AddNode(node);
}

Nodeset.FetchComplete = function(status) {
    this._children = null;
    this.callback(this.corrupt ? 1006 : status);
}

var ct = {}
Nodeset.Continue = {
    notify: function(timer) {
        var set = ct.self;
        var nids = ct.nids;
        var result;
        var s = Date.now();
        while (nids.length > 0 && Date.now() - s < 100) {
            var next = nids.shift();
            var nid = next[0];
            var pnid = next[1];

            if (!set.Node(nid, false, true)) {
                Xmarks.LogWrite("Warning: OnTree() was about to reference " +
                    nid + " which doesn't exist");
                break;
            }

            try {
                // for post-order traversal, we skip the first time we
                // see this nid; subsequently we'll push it along with our
                // children.  Once children are processed, we'll see it again
                // and then we process it, and can remove it from the visit
                // list.
                if (!ct.postorder || ct.visited[nid])
                    result = ct.action.apply(ct.Caller, [nid, pnid]);
            } catch (e) {
                if(typeof e == "number"){
                    result = e;
                } else {
                    Xmarks.LogWrite("OnTree error " + e + " source: " + e.toSource());
                    Xmarks.LogWrite("Node was " + nid);
                    result = 3;
                }
            }

            if (result)
                break;

            // if action above deleted nid...
            if (set.Node(nid, false, true) == null)
                continue;

            if (ct.postorder && ct.visited[nid])
            {
                delete ct.visited[nid];
                continue;
            }
            var ix = 0;
            if (set.Node(nid).ntype == "folder") {
                var children = set.Node(nid).children;

                for (var child in children) {
                    if (!children.hasOwnProperty(child))
                        continue;
                    if (ct.depthfirst) {
                        nids.splice(ix++, 0, [children[child], nid]);
                    } else {
                        nids.push([children[child], nid]);
                    }
                }
            }
            if (ct.postorder)
            {
                // add back this nid so we process it after children
                ct.visited[nid] = true;
                if (ct.depthfirst)
                    nids.splice(ix, 0, [nid, pnid]);
                else
                    nids.push([nid, pnid]);
            }
        }

        if (nids.length > 0 && !result) {
            timer.initWithCallback(Nodeset.Continue, 10,
                Ci.nsITimer.TYPE_ONE_SHOT);
        } else {
            ct.complete.apply(ct.Caller, [result]);
        }
    }
}

Nodeset.prototype = {
    constructor: Nodeset,

    get length() {
        return this._length;
    },

    NodeName: function(nid) {
        var node = this.Node(nid, false, true);

        if (node && node.name) {
            return node.name + "(" + nid + ")";
        } else {
            return nid;
        }
    },
    realToSource: function(nid) {
        var n = this.Node(nid, false, true);
        return n ? Object.prototype.toSource.apply(n) : "<null>";
    },

    handleNidConflict: function(lnode, snode, conflicts){
        return this._datasource.handleNidConflict(lnode, snode, conflicts);
    },

    AddNode: function(node) {
        if (this._children && node.children) {
            var self = this;
            for (var index = 0; index < node.children.length; index++) {
                var cnid = node.children[index];
                if (self._children[cnid] != undefined) {
                    node.children.splice(index--, 1);
                    Xmarks.LogWrite("Warning: Filtering " + self.NodeName(cnid) + 
                            " as a corrupted duplicate in parent " +
                            node["name"] + " (" + node.nid + ")");
                } else {
                    self._children[cnid] = true;
                }
            }
        }   
            
        if (this._node[node.nid]) { // Oh oh! Node already exists.
            Xmarks.LogWrite("Warning: Node " + this.NodeName(node.nid) +
                    " in folder " + this.NodeName(node.pnid) + 
                    " already exists in folder " +
                    this.NodeName(this._node[node.nid].pnid));
            // Log error only; don't prevent sync as cleanup happened above
            // this.corrupt = true;
            return;
        }
        this._node[node.nid] = node;
        this._length++;
    },

    FetchFromNative: function(callback) {
        this._children = {}
        // this.source = new NativeDatasource();
        this.callback = callback;
        this._datasource.ProvideNodes(this, Nodeset.FetchAdd, Nodeset.FetchComplete);
    },

    BaselineLoaded: function(baseline, callback) {
        return this._datasource.BaselineLoaded(baseline, callback);
    },
    FlushToNative: function(callback) {
        // var source = new NativeDatasource();
        this._datasource.AcceptNodes(this, callback);
        return;
    },

    ProvideCommandset: function(callback) {
        var self = this;
        var cs = new Commandset();

        this.OnTree(Add, Done);
        return;
            
        function Add(nid, pnid) {
            var attrs = self._datasource.GetSafeInsertAttrs ?
                self._datasource.GetSafeInsertAttrs(self.Node(nid)) :
                self.Node(nid).GetSafeAttrs();
            cs.append(new Command("insert", nid, attrs));
            return 0;
        }

        function Done(status) {
            callback(status, cs);
        }
    },

    ProvideHashes: function(callback) {
        var self = this;
        var hashes = [];

        this.OnTree(Add, Done);
        return;

        function Add(nid, pnid) {
            // the only attrs we need to pass back:
            //   - hash
            //   - nid (key)
            //   - pnid
            //   - children
            node = self.Node(nid);
            hashes.push({ "nid" : nid,
                          "pnid" : node.pnid || '',
                          "children" : node.children || [],
                          "hash" : node.hash });
            return 0;
        }

        function Done(status) {
            callback(status, hashes);
        }
    },

    _GetFile: function() {
        var file = Cc['@mozilla.org/file/directory_service;1']
            .getService(Ci.nsIProperties)
            .get('ProfD', Ci.nsIFile);

        file.append(this._datasource.getBaselineName());
        return file;
    },

    SaveToFile: function(callback, userfile) {

        var self = this;
        var first = true;

        var file = userfile || this._GetFile();

        var nodeset = {};

        this.OnTree(WriteNode, WriteDone);
        return;

        function WriteNode(nid, pnid) {
            var node = self._datasource.GetSafeInsertAttrs ?
                    new Node(nid,
                        self._datasource.GetSafeInsertAttrs(self.Node(nid), true)) :
                    self.Node(nid);

            var js_node = {};
            for (var prop in node) {
                if (node.hasOwnProperty(prop) && prop != 'nid') {
                    js_node[prop] = node[prop];
                }
            }
            nodeset[node.nid] = js_node;
            return 0;
        }

        function WriteDone(status) {

            Xmarks.jsparse.tree_to_nodedict(nodeset);
            var xmarks_json = {
                "format": "xmarks_nodes",
                "version": "1.0",
                "toprev": self.currentRevision,
                "plugin": "ff",
                "plugin_version": Xmarks.FoxmarksVersion,
                "nodes": nodeset
            };
            var jsonstr = JSON.stringify(xmarks_json);

            var fstream = Cc["@mozilla.org/network/safe-file-output-stream;1"]
                .createInstance(Ci.nsIFileOutputStream);
            fstream.init(file, (MODE_WRONLY | MODE_TRUNCATE | MODE_CREATE),
                PERMS_FILE, 0);
            var cstream = Cc["@mozilla.org/intl/converter-output-stream;1"]
                .createInstance(Ci.nsIConverterOutputStream);
            cstream.init(fstream, "UTF-8", 0, 0x0000);

            if (!status) {
                cstream.writeString(jsonstr);
                // Flush the character converter, then finish the file stream,
                // guaranteeing that an existing file isn't overwritten unless
                // the whole thing succeeds.
                cstream.flush();
                try {
                    fstream.QueryInterface(Ci.nsISafeOutputStream).finish();
                } catch (e) {
                    fstream.close();
                    Xmarks.LogWrite("Error in Writing: " + e.message);
                    status = 1009;
                }
            }
            callback(status);
        }
    },


    LoadFromFile: function(filename) {
        Xmarks.LogWrite("Loading baseline...");

        var file;
        if (!filename) {
            file = this._GetFile();
        } else {
            var FileUtils = Cu.import("resource://gre/modules/FileUtils.jsm").FileUtils;
            file = new FileUtils.File(filename);
        }

        var fstream = Cc["@mozilla.org/network/file-input-stream;1"]
            .createInstance(Ci.nsIFileInputStream);
        fstream.init(file, MODE_RDONLY, PERMS_FILE, 0);
        var cstream = Cc["@mozilla.org/intl/converter-input-stream;1"]
            .createInstance(Ci.nsIConverterInputStream);
        cstream.init(fstream, "UTF-8", 32768, 0xFFFD);
        var str = {}; 
        
        var contents = "";

        while (cstream.readString(32768, str) != 0) {
            contents += str.value;
        }
        fstream.close();
        cstream.close();

        Xmarks.LogWrite("Parsing baseline...");
        var result = Xmarks.jsparse.xmarks_load_baseline(contents);

        Xmarks.LogWrite("Creating internal objects...");
        // convert from parsed JSON object into internal representation
        var internal_nodes = {};
        Xmarks.jsparse.nodedict_to_tree(result.nodes);
        for (var nid in result.nodes) {
            if (!result.nodes.hasOwnProperty(nid))
                continue;

            var props = result.nodes[nid];
            internal_nodes[nid] = new Node(nid, props);
        }
        this._node = internal_nodes;
        this.currentRevision = result.toprev;
        this.version = result.plugin_version;
        Xmarks.LogWrite("Loaded baseline: " + Object.keys(this._node).length + " entries");

        var self = this;
        self._length = 0;
        var ispw = this._datasource.syncType == 'passwords';
        Object.keys(this._node).forEach(function(k) {
            var n = self._node[k];
            if (ispw && !n.data) {
                self._node = {};
                self._length = 0;
                throw { name: "BAD_PW_BASELINE" };
            } else {
                self._length++; 
            } 
        });
    },

    Declone: function(callback) {
        // If we are cloned from some other nodeset, copy any references
        // we currently hold from the clonesource into ourselves and
        // break the clonesource relationship.
        // This must be done before serializing a nodeset to disk.

        var self = this;

        if (!this._cloneSource) {
            callback(0);
        } else {
            this.OnTree(CopyNode, Done);
        }
        return;

        function CopyNode(nid, pnid) {
            if (self._node[nid] === undefined) {
                self._node[nid] = self._cloneSource.Node(nid);
            }
            return 0;
        }

        function Done(status) {
            Xmarks.LogWrite("Removing empty nodes");
            if (!status) {
                self._cloneSource = null;
                Object.keys(self._node).forEach(
                    function(k) {
                        var v = self._node[k];
                        if (!v) {
                            delete self._node[k];
                            self._length--;
                        }
                    }
                );
            }
            Xmarks.LogWrite("Done declone");
            callback(status);
        }
    },

    CloneNode: function(obj) {
        var objectClone = new obj.constructor();
        for (var property in obj) {
            if (!obj.hasOwnProperty(property))
                continue;
            if (typeof obj[property] == 'object' && obj[property]) {
                objectClone[property] = this.CloneNode(obj[property]);
            } else {
                objectClone[property] = obj[property];
            }
        }
        return objectClone;
    },

    // Node returns the node with the given nid.
    // If you intend to modify the returned node,
    // set "write" true; this will do a "copy on write"
    // from the clone source if one has been set.
    // If node specified is not found, throws an exception
    // unless "nullOkay" is true, in which case it returns null.
    Node: function(nid, write, nullOkay) {
        if (nid in this._node) {
            return this._node[nid];
        } else if (this._cloneSource) {
            var node = this._cloneSource.Node(nid, false, nullOkay);
            if (!node || !write) {
                return node;
            } else {
                var newNode = this.CloneNode(node);
                if(newNode['private'])
                    delete newNode['private'];
                this.AddNode(newNode);
                return newNode;
            }
        } else {
            if (nullOkay)
                return null;
            else
                throw Error("Node not found: " + nid);
        }
    },

    HasAncestor: function(nid, pnid) {
        while (nid) {
            var node = this.Node(nid, false, true);
            if (!node) {
                Xmarks.LogWrite("Whoops! HasAncestor tried to reference " + nid +
                        " which doesn't exist");
                throw Error("HasAncestor bad nid " + nid);
            }
            nid = node.pnid;
            if (nid == pnid)
                return true;
        }
        return false;
    },

    // Find next sibling in this folder that also exists in other's folder
    NextSibling: function(nid, other) {
        var pnid = this.Node(nid).pnid;
        var oursibs = this.Node(pnid).children;
        var othersibs = other.Node(pnid).children;

        for (var i = oursibs.indexOf(nid) + 1; i < oursibs.length; ++i) {
            var sib = oursibs[i];
            if (othersibs.indexOf(sib) >= 0) {
                return sib;
            }
        }

        return null;
    },

    InsertInParent: function(nid, pnid, bnid) {
        if (nid == NODE_ROOT && (pnid == null || pnid == "")) {
            return; // Fail silently.
        }

        if (!nid)
            throw Error("bad nid");

        if (!pnid)
            throw Error("bad pnid for nid " + nid);

        var parent = this.Node(pnid, true);
        if (typeof parent["children"] == "undefined") {
            parent.children = [];
        }
        if (parent.children.indexOf(nid) >= 0) {
            throw Error("child " + nid + " already exists in parent " + pnid);
        }
        if (bnid) {
            var i = parent.children.indexOf(bnid);
            if (i >= 0) {
                parent.children.splice(i, 0, nid);
            } else {
                throw Error("didn't find child " + bnid + " in parent " + pnid);
            }
        } else {
            parent.children.push(nid);
        }
        this.Node(nid, true).pnid = pnid;
    },            

    RemoveFromParent: function(nid) {
        var node = this.Node(nid, true);
        if (!node.pnid) {
            Xmarks.LogWrite("node.pnid is undefined for " + node.name);
        }
        var parent = this.Node(node.pnid, true);
        var i = parent.FindChild(nid);

        if (i >= 0) {
            parent.children.splice(i, 1);
        } else {
            throw Error("didn't find child " + nid + " in parent " + pnid);
        }
        node.pnid = null;
    },

    Do_insert: function(nid, args /* pnid, bnid, ntype, etc. */) {
//        Xmarks.LogWrite("inserting " + nid + " " + args.toSource());
        if (this.Node(nid, false, true) != null) {
            var nargs = this._datasource.GetSafeInsertAttrs ?
                this._datasource.GetSafeInsertAttrs(this.Node(nid)) :
                this.Node(nid).GetSafeAttrs();
            var conflict = false;
            Object.keys(args).forEach(function(attr) {
                var value = args[attr];
                if (nargs[attr] && value != nargs[attr]) {
                    conflict = true;
                }
            } );
            if (conflict) {
                throw Error("Tried to insert a node that already exists");
            } else {
                return; // In the interests of being accomodating, we're going
                        // to let this one slide by. But make sure it doesn't
                        // happen again, mkay?
            }
        }
        var node = new Node(nid);

        for (var attr in args) {
            if (args.hasOwnProperty(attr) && 
                    attr != 'pnid' && attr != 'bnid' && attr != 'children') {
                node[attr] = args[attr];
            }
        }

        this.AddNode(node);
        this.InsertInParent(nid, args.pnid, args.bnid);
    },

    Do_delete: function(nid) {
        var self = this;
//        Xmarks.LogWrite("deleting " + this.NodeName(nid));

        // Be careful here: only the top-level node has to be
        // removed from its parent. That node and its descendants
        // need to be nulled out.

        function NukeNode(nid) {
            var node = self.Node(nid);
            if (node.children) {
                for (var n = 0; n < node.children.length; ++n)
                    NukeNode(node.children[n]);
            }
            if (self._cloneSource) {
                self._node[nid] = null; // If cloned, shadow deletion.
            } else {
                delete self._node[nid]; // Otherwise, delete it outright.
            }
            self._length--;
        }

        self.RemoveFromParent(nid);
        NukeNode(nid);
    },

    Do_move: function(nid, args /* pnid, bnid */) {
//        Xmarks.LogWrite("moving " + this.NodeName(nid));

        this.RemoveFromParent(nid);
        this.InsertInParent(nid, args.pnid, args.bnid);
    },

    Do_reorder: function(nid, args /* bnid */) {
//        Xmarks.LogWrite("reordering " + this.NodeName(nid) + " before " + 
//                this.NodeName(args.bnid));
        var pnid = this.Node(nid).pnid;
        this.RemoveFromParent(nid);
        this.InsertInParent(nid, pnid, args.bnid);
    },

    Do_update: function(nid, args /* attrs */) {
//        Xmarks.LogWrite("updating " + this.NodeName(nid));
        var node = this.Node(nid, true);

        Object.keys(args).forEach(function(attr) {
            var value = args[attr];
            if (value) {
                node[attr] = value;
            } else {
                delete node[attr];
            }
        } );
    },

    // Pass either a single command or a Commandset.
    Execute: function(command) {
        if (command.set) {
            var self = this;
            command.set.forEach(function(c) {
                self.Execute(c);
            } );
            return;
        }

        var method = this["Do_" + command.action];
        try {
            method.apply(this, [command.nid, command.args]);
        } catch (e) {
            if(typeof e == "number") {
                throw e;
            } else {
                Cu.reportError(e);
                throw Error("Failed executing command " + command.toSource() + 
                        "; error is " + e.toSource());
            }
        }
    },
    OrderIsImportant: function(){
        return this._datasource.orderIsImportant;
    },

    // traverses this's bookmarks hierarchy starting with
    // startnode, calling action(node) for each node in the tree,
    // then calling complete() when traversal is done.
    // enforces rules about maximum run times to prevent hanging the UI
    // when traversing large trees or when running on slow CPU's.
    // action() should return 0 to continue, non-zero status to abort.
    // complete() is called with status, non-zero if aborted.
    // depthfirst determines tree traversal order
    // use postorder to visit leaves before parents

    OnTree: function(action, complete, startnid, depthfirst, postorder) {
        ct = {}
        ct.self = this;
        ct.Caller = this;
        ct.action = action;
        ct.complete = complete;
        ct.startnid = startnid || NODE_ROOT;
        ct.depthfirst = depthfirst;
        ct.postorder = postorder;
        ct.visited = {};
        ct.nids = [[ct.startnid, null]];
        ct.timer = Cc["@mozilla.org/timer;1"].createInstance(Ci.nsITimer);
        ct.timer.initWithCallback(Nodeset.Continue, 10, 
            Ci.nsITimer.TYPE_ONE_SHOT);
        return;
    },

    IGNORABLE: { created: true, visited: true, modified: true },

    // Compare this nodeset with another, returning a canonical list
    // of commands that transforms this nodeset into the specified one.
    // Note that at the successful conclusion of this routine, this
    // nodeset will be transformed to match the specified nodeset.
    Compare: function(other, callback) {
        var self = this;
        var commandset = new Commandset();
        var inserted = [];
        var _hashmap = [];
        var _inserts = [];
        var _addednids = [];


        Step1();
        return;

        function Step1() {
            self.OnTree(FindReordersInsertsMoves, Step1point5);
        }

        function Step1point5(status){
            if (status) {
                callback(status);
            } else {

              if(inserted.length==0){
                Step2(0);
                return;
              }


              for(var i = 0; i < inserted.length; i++){
                var nid = inserted[i];
                var path = HashFullPaths(nid, other.Node(nid).pnid, other, true);
                _inserts[_inserts.length] = path;
                _addednids[nid] = 1;
              }

              self.OnTree(HashFullPaths, CheckDups);
            }
        }

        function CheckDups(){
          var done = [];
          for(var i = 0; i < _inserts.length; i++){
            var path = _inserts[i];
            if(typeof(_hashmap[path])!='undefined' && typeof(other._datasource.DeleteNid)=='function'){
              //duplicate found!
              var nid = _hashmap[path];
              if(typeof(done[nid])=='undefined'){
                Xmarks.LogWrite("FOUND DUPLICATE! " + nid);
                other._datasource.DeleteNid(nid);
                done[nid] = 1;
              }
            }
          }

          Step2(0);
        }

        function Step2(status) {
            if (status) {
                callback(status);
            } else {
                self.OnTree(FindDeletes, Step4);
            }
        }

        // There IS no step 3.

        function Step4(status) {
            if (status) {
                callback(status);
            } else {
                // Make sure we compare root nodes for changes.
                try {
                    var sroot = self.Node(NODE_ROOT);
                    var oroot = other.Node(NODE_ROOT);
                    var attrs = {};
                    if (self._datasource.compareNodes(sroot, oroot, attrs)) {
                        var command = new Command("update", NODE_ROOT, attrs);
                        commandset.append(command);
                        self.Execute(command);
                    }
                } catch (e) {
                   Xmarks.LogWrite("Error comparing roots: " + e.toSource());
                }
                self.OnTree(FindUpdates, Step5);
            }
        }

        function Step5(status) {
            if (status) {
                callback(status);
            } else {
                callback(0, commandset);
            }
        }

        function FindReordersInsertsMoves(nid, pid) {
            if (self.Node(nid).ntype != "folder")
                return 0;

            var snode = self.Node(nid);
            var onode = other.Node(nid, false, true);
            if (!onode) // Deleted; don't worry about children.
                return 0;

            var us = snode.children ? snode.children.slice() : [];
            var them = onode.children ? onode.children.slice() : [];

            // Reduce us and them to intersections
            us = us.filter(function(x) { return them.indexOf(x) >= 0; } );
            them = them.filter(function(x) { return us.indexOf(x) >= 0; } );

            if (us.length != them.length) {
                Xmarks.LogWrite("Error: intersections of unequal length for " +
                        self.NodeName(nid));
                Xmarks.LogWrite("us   = " + us);
                Xmarks.LogWrite("them = " + them);
                throw Error("Intersections of unequal length");
            }

            // Reorder us according to them
            if(self._datasource.orderIsImportant){
                for (var i = 0; i < us.length; ++i) {
                    if (us[i] != them[i]) {
                        var command = new Command("reorder", them[i], 
                            { bnid: us[i] });
                        commandset.append(command);
                        self.Execute(command);
                        // Simulate reorder in our intersected list
                        us.splice(us.indexOf(them[i]), 1);
                        us.splice(i, 0, them[i]);
                    }
                }
            }


            // Walk through them to find inserts and moves
            var sc = self.Node(nid).children || [];     // (May have changed)
            var oc = onode.children || [];
            oc.forEach(function(child, index) {
                if (sc.indexOf(child) < 0) {    // ... missing from us
                    if (self.Node(child, false, true)) {    // ... but exists in set
                        var command = new Command("move", child, 
                            { pnid: nid, bnid: FindBnid(index + 1) } );
                        commandset.append(command);
                        self.Execute(command);
                    } else {                                // ... missing entirely
                        var attrs = self._datasource.GetSafeInsertAttrs ?
                            self._datasource.GetSafeInsertAttrs(
                                other.Node(child)) : 
                            other.Node(child).GetSafeAttrs(false, true);
                        attrs.bnid = FindBnid(index + 1);
                        var command = new Command("insert", child, attrs);
                        commandset.append(command);
                        self.Execute(command);
                        inserted[inserted.length] = other.Node(child).nid;
                    }
                }

                function FindBnid(index) {
                    var oc = onode.children;
                    var len = oc.length;
                    while (index < len && us.indexOf(oc[index]) < 0) {
                        ++index;
                    }
                    return index < len ? oc[index] : null;
                }
            } );

            return 0;
        }

        function HashFullPaths(nid, pnid, ns, ret){
          if(!ns) ns = self;
          var key = "";
          var foldernid = pnid;
          //Walk up the tree and construct the full path
          while(foldernid!=null && foldernid!=""){
            key = ns.Node(foldernid).name + "/" + key;
            foldernid = ns.Node(foldernid).pnid;
          }
          var n = ns.Node(nid);
          key += n.name + (n.ntype=="folder" ? "" : n.url);
          if(!ret){
            if(typeof(_addednids[nid])=="undefined")
              _hashmap[key] = nid;
          }else{
             return key;
          }
        }

        function FindDeletes(nid, pnid) {
            if (!other.Node(nid, false, true)) {
                Xmarks.LogWrite("Deleting " + nid + " which exists in baseline but not in local database");
                var command = new Command("delete", nid);
                commandset.append(command);
                self.Execute(command);
            }
            return 0;
        }

        function FindUpdates(nid, pnid) {
            var result = 0;
            try {
                var snode = self.Node(nid);
                var onode = other.Node(nid);
                var attrs = {};
                if (self._datasource.compareNodes(snode, onode, attrs)) {
                    if ("ntype" in attrs) {
                        Xmarks.LogWrite("Whoa! Node " + nid + 
                                " changed type to " + attrs["ntype"]);
                        var del = new Command("delete", nid);
                        var ins = new Command("insert", nid, 
                            (self._datasource.GetSafeInsertAttrs ?  
                                self._datasource.GetSafeInsertAttrs(onode) : 
                                onode.GetSafeAttrs()));
                        commandset.append(del);
                        commandset.append(ins);
                        self.Execute(del);
                        self.Execute(ins);
                    } else {
                        var command = new Command("update", nid, attrs);
                        commandset.append(command);
                        self.Execute(command);
                    }
                }
            } catch (e){
                if(typeof e != "number"){
                    Cu.reportError(e);
                    result = 4;
                } else {
                    result = e;
                }
            }
            return result;
        }


    },

    // Hash every node in the current tree for full sync.
    HashTree: function(hash_attrs, callback) {
        function HashNode(nid, pnid) {
            this.Node(nid).ComputeHash(this, hash_attrs);
        }

        function Done(status) {
            callback(status || 0);
        }

        this.OnTree(HashNode, Done, NODE_ROOT, true, true);
    },

    // We are given a set of nodes that need updates in the local
    // store; take these and generate commands to execute.  The
    // commands are in leaf-first order
    ProcessHashUpdates: function(updates) {
        var self = this;

        // attributes we will update
        var mutable_attrs = {
            'name': true,
            'description': true,
            'url': true,
            'icon': true
        };

        function IsAttrChange(node, orig_node, attr) {
            if (!mutable_attrs[attr])
                return false;

            if (!node.hasOwnProperty(attr) && !orig_node.hasOwnProperty(attr))
                return false;

            // ignore icon updates to the hash string since we didn't
            // fill them in from cassandra.
            if (attr == 'icon' &&
                node[attr] != undefined &&
                node[attr].lastIndexOf("md5#:", 0) == 0)
                return false;

            return node[attr] != orig_node[attr];
        }

        // given a parent nid and a list of child nids, check that
        // the pnid/bnid position matches that in the nodeset; if not,
        // add a reorder or move command to the commandset.  We do these
        // back-to-front so the 'bnid' is in the proper place before the
        // node that relies on it
        function LinkChildren(pnid, orig_children, children, cs) {

            for (var i = children.length-1; i >= 0; i--) {
                var cnid = children[i];
                var bnid = (i == children.length - 1) ? null : children[i + 1];
                var node = self.Node(cnid);

                if (node.pnid != pnid) {
                    Xmarks.LogWrite("moving " + cnid + " to " + pnid + "," + i);
                    cs.append(new Command("move", cnid,
                        { "pnid": pnid, "bnid": bnid }));
                }
                else if (cnid != orig_children[i]) {
                    cs.append(new Command("reorder", cnid, { "bnid": bnid }));
                    Xmarks.LogWrite("Repair reorder " + cnid + " to " + i);
                }
            }
        }

        function ReinsertNode(nid, reinsert_cs, delete_set) {
            var insertNode = self.Node(nid)
            var attrs = self._datasource.GetSafeInsertAttrs ?
                self._datasource.GetSafeInsertAttrs(insertNode) :
                insertNode.GetSafeAttrs();
            var command = new Command("insert", nid, attrs);
            reinsert_cs.append(command);

            var children = insertNode.children || [];
            for (var i = 0; i < children.length; i++) {
                if (delete_set[nid] != false)
                    ReinsertNode(children[i], reinsert_cs, delete_set);
            }
        }

        var cs = new Commandset();
        var reinsert_cs = new Commandset();

        // delete set holds true if we think a nid should be deleted,
        // false if we know it should be kept
        var delete_set = {};

        for (var i = 0; i < updates.length; i++) {
            var node = updates[i];
            var nid = node.nid;
            var orig_node = self.Node(nid, false, true);

            // this node must be in use
            delete_set[nid] = false;

            if (!orig_node) {
                // this is a new node; we just insert it as an orphan
                // then link it up with the correct parent node later.
                var insertNode = new Node(nid, node);
                var attrs = self._datasource.GetSafeInsertAttrs ?
                    self._datasource.GetSafeInsertAttrs(insertNode) :
                    insertNode.GetSafeAttrs();

                // dump it in root for now
                attrs.pnid = 'ROOT';

                var command = new Command("insert", nid, attrs);
                cs.append(command);
                self.Execute(command);
                Xmarks.LogWrite("Repair inserted nid: " + nid);

                // if we had any children, we need to make sure they are
                // now linked up with this parent
                var children = node.children || [];
                LinkChildren(nid, [], children, cs);

                // and none of them should be purged (e.g. may have moved
                // from another parent)
                for (var j=0; j < children.length; j++)
                    delete_set[children[j]] = false;

                continue;
            }

            // this is a node that already exists, check if there are
            // any children from the old list missing in the new child
            // list; if so add them to the delete set.  First just assume
            // we delete them all.
            orig_children = orig_node.children || [];
            new_children = node.children || [];
            for (var j=0; j < orig_children.length; j++) {
                cnid = orig_children[j];
                if (delete_set[cnid] == undefined) {
                    delete_set[cnid] = true;
                }
            }
            // keep any that are still in use
            for (var j=0; j < new_children.length; j++)
                delete_set[new_children[j]] = false;

            // link up and/or reorder children
            LinkChildren(nid, orig_children, new_children, cs);

            // now make sure that all attribute values match
            new_attrs = {}
            var doupdate = false;

            for (var attr in mutable_attrs) {
                if (IsAttrChange(node, orig_node, attr)) {
                    Xmarks.LogWrite("Repair attr changed (" + nid + "): " +
                        attr + " " + orig_node[attr] + " -> " + node[attr]);

                    doupdate = true;
                    new_attrs[attr] = node[attr] || null;
                }
            }
            if (doupdate)
                cs.append(new Command("update", nid, new_attrs));
        }

        // any nids still in delete don't exist on server side.
        // delete them for now, then we will add them back in a separate
        // transaction
        Object.keys(delete_set).forEach(function(nid) {
            var v = delete_set[nid];
            if (v) {
                cs.append(new Command("delete", nid, {}));
                Xmarks.LogWrite("Repair delete: " + nid);

                // Construct commands to reinsert this node.
                //
                // The nodes deleted here must have an existing parent
                // since only the topmost removed node is added to the delete
                // set.  Thus we can get away with just recursively adding
                // back this and all child nodes that aren't moved elsewhere
                // (i.e. if delete_set[nid] is true or undefined).
                ReinsertNode(nid, reinsert_cs, delete_set);
            }
        });

        return [cs, reinsert_cs];
    },

    Merge: function(source){
        this._datasource.merge(this, source);
    },

    Copy: function() {
        var new_ns = new Nodeset(this._datasource);
        for (var nid in this._node) {
            var node = this.CloneNode(this.Node(nid));
            new_ns._node[nid] = node;
            new_ns._length++;
        }
        return new_ns;
    },

    UpdateIcons: function(callback) {

        function Fetch(nid, pnid) {
            node = this.Node(nid);
            if (node.ntype != "bookmark" || !node.url)
                return 0;

            if (!node.url.startsWith("http"))
                return 0;

            if (to_fetch[node.url])
                return 0;

            to_fetch[node.url] = true;

            queue.push(node.url);
            return 0;
        }

        function Done(status) {
            // now go through queue and update them
            outstanding = queue.length;
            Xmarks.LogWrite("Processing icon queue: " + queue.length + " items");
            for (var i=0; i < queue.length; i++) {

                var node_url = queue[i];
                var icon_url = queue[i];
                var re = /^(http(s)?:\/\/[^/]*)\/.*/;
                icon_url = icon_url.replace(re, "$1/favicon.ico");

                this._datasource.ReloadIcon(node_url, icon_url);
            }

            // we can't actually wait for these to finish because
            // nsIFaviconDataCallback only happens on success, so there's
            // no way to know the queue has been processed.
            // So just callback now.
            callback(0);
        }

        var to_fetch = {};
        var queue = [];
        var outstanding = 0;

        if (!this._datasource.ReloadIcon) {
            callback(0);
            return;
        }
        this.OnTree(Fetch, Done);
    }
};

exports.Node = Node;
exports.Nodeset = Nodeset;
exports.NODE_ROOT = NODE_ROOT;
