/*
 Copyright 2005-2010 Xmarks Inc.

 foxmarks-service.js: component that implements the "service" interface to
 the core synchronization code.

 */

var Cc = Components.classes;
var Ci = Components.interfaces;
var Cu = Components.utils;
var Xmarks;

if (Xmarks === undefined) {
    Xmarks = {};
}

Cu['import']("resource://gre/modules/XPCOMUtils.jsm");
var CID = Components.ID("{49ace257-6111-48b2-a988-f9eb38b0fa58}");
var contractID = "@foxcloud.com/extensions/foxmarks;1";
var className = "XmarksService";

function XmarksServiceComponent() {
}

XmarksServiceComponent.prototype = {
    classID: CID,
    classDescription: "XmarksService",
    contractID: contractID,

    _xpcom_categories: [{
        category: "profile-after-change"
    }],

    QueryInterface: XPCOMUtils.generateQI([Ci.nsIObserver, 
        Ci.nsISupportsWeakReference]),

    observe: function(subject, topic, data)  { // called at startup
        Cu['import']("resource://xmarks/service.jsm", Xmarks);
        Xmarks.fms.Init();
    }
};

if (XPCOMUtils.generateNSGetFactory) {
    var NSGetFactory = 
        XPCOMUtils.generateNSGetFactory([XmarksServiceComponent]);
} else {
    var NSGetModule = 
        XPCOMUtils.generateNSGetModule([XmarksServiceComponent]);
}
