/*
 Copyright 2006-2010 Xmarks Inc.

 prefs.js: contains default preferences for extension.

 */

pref("extensions.foxmarks@kei.com.description", 
    "chrome://foxmarks/locale/foxmarks.properties");
pref("extensions.xmarks.enableLogging", true);
pref("extensions.xmarks.securityLevel", 1);
pref("extensions.xmarks.synchOnTimer", true);
pref("extensions.xmarks.shortcut.SyncNow", "s");
pref("extensions.xmarks.shortcut.OpenSettings", "o");
pref("extensions.xmarks.shortcut.OpenTabs", "y");
pref("extensions.xmarks.shortcut.SiteInfo", "n");
pref("extensions.xmarks.enableSimSite", false);
pref("extensions.xmarks.enableSERP", false);
pref("extensions.xmarks.enableTagSuggestions", false);
pref("extensions.xmarks.useView", true);
