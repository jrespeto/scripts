pref("extensions.alexancarlproject_obsrev.description", "chrome://osbrev/locale/osb.properties");
