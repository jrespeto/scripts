initInstall("Organize Status Bar", "/y5/osb", "0.6.4");
alert("Sorry, this extension package is designed for Mozilla Firefox 0.9 and higher.");
cancelInstall();