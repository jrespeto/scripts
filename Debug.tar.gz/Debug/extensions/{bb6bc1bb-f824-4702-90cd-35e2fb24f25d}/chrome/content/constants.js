const	EMAIL = "737570706f72742e636f6f6b6965732d6d616e616765722d706c75732e756e6971756531733534616a32766f744076616e6f2e6f7267", //don't want leave email as open text
			HOMEPAGE = "https://addons.mozilla.org/addon/cookies-manager-plus/",
			_SUPPORTSITE = "https://github.com/vanowm/FirefoxCookiesManagerPlus/",
			SUPPORTSITE = _SUPPORTSITE + "issues",
			SUPPORTSITEQUERY = "?q=is%3Aissue+is%3Aopen+sort%3Aupdated-desc",
			ISSUESSITE = SUPPORTSITE + "/",
			SOURCESITE = _SUPPORTSITE + "commit/",
			ADDONDOMAIN = "cookiesmanagerplus";
