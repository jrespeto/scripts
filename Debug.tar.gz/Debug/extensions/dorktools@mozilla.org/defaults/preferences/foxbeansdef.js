pref("extensions.dorktools@mozilla.org.description", "chrome://dorktools/locale/description.properties");  

